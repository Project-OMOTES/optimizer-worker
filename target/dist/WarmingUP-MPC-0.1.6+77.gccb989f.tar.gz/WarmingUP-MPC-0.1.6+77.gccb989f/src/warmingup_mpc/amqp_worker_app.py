import functools
import importlib
import json
import logging
import threading
from pathlib import Path

import pika

from warmingup_mpc.amqp_base import AMQPBase


logger = logging.getLogger("warmingup-mpc")


class AMQPWorker(AMQPBase):
    def __init__(self):
        # Set up exchange and channels
        super().__init__()

        self.channel.basic_consume(queue=self.COMMAND_QUEUE, on_message_callback=self.on_request)

        self._threads = []

    def on_request(self, channel, method, props, body):
        # See https://github.com/pika/pika/blob/0.12.0/examples/basic_consumer_threaded.py
        thread = threading.Thread(
            target=self._do_work, args=(channel, props, method.delivery_tag, body)
        )
        thread.start()
        self._threads.append(thread)

    def _do_work(self, ch, props, delivery_tag, body):
        command = json.loads(body.decode("utf-8"))

        err = None
        result_b64_file_contents = None

        if command["version"] != 1:
            err = f"Received command with wrong version number.\n{command}"

        if command["command"] != "run_runinfo_workflow":
            err = f"Received unknown command '{command['command']}'"

        try:
            arguments = command["arguments"]

            workflow_name = arguments["workflow"]

            tmp_dir = self._deserialize_runinfo(arguments["file_contents"])
            tmp_dir_path = Path(tmp_dir.name)

            runinfo_path = tmp_dir_path / arguments["runinfo"]

            # Run the workflow
            module = importlib.import_module(f"warmingup_mpc.{workflow_name}")
            module.main(runinfo_path, arguments["log_level"], run_remote=False)

            # Serialize results, including the "to_cf"  and "model" folder
            # that contain additional results.
            result_b64_file_contents = self._serialize_runinfo(
                runinfo_path, runinfo_path.parent / "to_cf", runinfo_path.parent / "model"
            )

            # Clean up the temporary working directory, as we serialized all results.
            tmp_dir.cleanup()
        except Exception:
            import traceback

            err = traceback.format_exc()

        if err is None:
            cb = functools.partial(
                self._publish_response, ch, props, delivery_tag, result_b64_file_contents
            )
        else:
            cb = functools.partial(self._publish_error, ch, props, delivery_tag, err)
        self.connection.add_callback_threadsafe(cb)

    @staticmethod
    def _publish_response(ch, props, delivery_tag, results):
        ch.basic_publish(
            exchange="",
            routing_key=props.reply_to,
            properties=pika.BasicProperties(correlation_id=props.correlation_id),
            body=json.dumps({"error": "", "version": 1, "result": results}),
        )
        ch.basic_ack(delivery_tag)

    @staticmethod
    def _publish_error(ch, props, delivery_tag, error):
        logger.warning(f"Returning error '{error}'")
        ch.basic_publish(
            exchange="",
            routing_key=props.reply_to,
            properties=pika.BasicProperties(correlation_id=props.correlation_id),
            body=json.dumps({"error": error, "version": 1}),
        )
        ch.basic_ack(delivery_tag)

    def shutdown(self):
        for thread in self._threads:
            thread.join()


def main():
    worker = AMQPWorker()

    try:
        worker.channel.start_consuming()
    except KeyboardInterrupt:
        worker.channel.stop_consuming()

    worker.shutdown()


if __name__ == "__main__":
    main()
