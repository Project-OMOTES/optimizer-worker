from rtctools.optimization.single_pass_goal_programming_mixin import Goal

from warmingup_mpc.minimize_opex_goal import get_variable_opex_costs


class MinimizeOPEXDaily(Goal):
    order = 1

    def __init__(self, priority=None):
        self.priority = priority

    def function(self, optimization_problem, ensemble_member):
        obj = 0

        for source in optimization_problem.heat_network_components.get("source", []):
            asset = optimization_problem.get_asset_from_asset_name(source)
            # if asset.asset_type == "HeatProducer":
            opex_costs = get_variable_opex_costs(asset)
            state_name = f"{source}.Heat_source"
            opt_var = optimization_problem.state(state_name)
            # TODO: add variable timestep size
            obj += opex_costs * opt_var / 1.0e6

        return obj
