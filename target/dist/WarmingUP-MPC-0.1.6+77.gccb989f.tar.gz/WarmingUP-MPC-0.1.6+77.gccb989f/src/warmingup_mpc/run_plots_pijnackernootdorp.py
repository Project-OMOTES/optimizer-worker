import json

import matplotlib.lines
import numpy as np

import matplotlib.pyplot as plt
from esdl import esdl
from rtctools_heat_network.esdl.esdl_mixin import _esdl_to_assets
from pathlib import Path
import os
from datetime import datetime

import pandas as pd

# workdir = Path(r"C:\Users\rojerj\Documents\Git\RTC-tools\PijnackerNootdorp\model")
workdir = Path(r"C:\Users\jimro\Documents\GIT\HeatNetworks\pijnackernootdorp\model\updated_basis\results\basis")
workdir2 = Path(r"C:\Users\jimro\Documents\GIT\HeatNetworks\pijnackernootdorp\model\updated_basis")


esdl_assets, profiles = _esdl_to_assets(None, os.path.join(workdir2, 'Rondom Ypenburg scenario basis met HTO D2_single pipes _KPI_double_checked.esdl'))
ipnut_path = os.path.join(workdir, "results.json")
with open(ipnut_path) as file:
    results = json.load(file)
ipnut_path = os.path.join(workdir, "parameters.json")
with open(ipnut_path) as file:
    parameters = json.load(file)
ipnut_path = os.path.join(workdir, "bounds.json")
with open(ipnut_path) as file:
    bounds = json.load(file)

# timesteps = profiles[list(profiles.keys())[0]].index.tz_convert(None).to_pydatetime()
day_steps = parameters["time_step_days"]
max_day = int(parameters["peak_day_index"] * day_steps)
nr_of_days = 365
new_date_times = list()

new_date_times = [datetime.fromtimestamp(x) for x in parameters["times"]]
__indx_max_peak = int(parameters["peak_day_index"])
timesteps = np.asarray([])
for i in range(1,len(new_date_times)):
    timesteps = np.append(timesteps, new_date_times[i].timestamp() - new_date_times[i-1].timestamp())

peak_day_total_demand = None
year_total_demand = None
data_peak = {}
data_year = {}

data_sizing_optimized = {}
data_sizing_static = {}
data_sizing_optimized_capex = {}
data_sizing_static_capex = {}
data_sizing_utilization_static = {}
data_sizing_utilization_optimized = {}
data_sizing_utilization_static_Nootdorp = {}
data_sizing_utilization_optimized_Nootdorp = {}
data_opex = {}
data_energy = {}
demands = []

for id, asset in esdl_assets.items():
    if asset.asset_type == "HeatingDemand":
        if not "Heatloss" in asset.name and all(np.asarray(results[f"{asset.name}.Heat_demand"]) > 1.0):
            demands.append(asset.name)
        if year_total_demand is None:
            year_total_demand = np.asarray(results[f"{asset.name}.Heat_demand"])
        else:
            year_total_demand += np.asarray(results[f"{asset.name}.Heat_demand"])
        if peak_day_total_demand is None:
            peak_day_total_demand = np.asarray(results[f"{asset.name}.Heat_demand"][__indx_max_peak:__indx_max_peak+24])
        else:
            peak_day_total_demand += np.asarray(results[f"{asset.name}.Heat_demand"][__indx_max_peak:__indx_max_peak+24])
    elif asset.asset_type in ["HeatProducer", "GenericProducer", "GeothermalSource", "GasHeater", "ResidualHeatSource"]:
        type = asset.asset_type
        if type not in data_year.keys():
            data_year[type] = np.asarray(results[f"{asset.name}.Heat_source"])
            data_energy[type] = np.sum(np.asarray(results[f"{asset.name}.Heat_source"][1:]) * timesteps)
            data_opex[type] = results[f"{asset.name}__fixed_operational_cost"] + results[f"{asset.name}__variable_operational_cost"]

            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] = results[f"{asset.name}__max_size"]
                data_sizing_utilization_optimized[type] = bounds[f"{asset.name}.Heat_source"][1]
                data_sizing_static_capex[type] = 0.
                data_sizing_static[type] = 0.
                data_sizing_utilization_static[type] = 0.
                data_sizing_utilization_static_Nootdorp[type] = 0.
                data_sizing_utilization_optimized_Nootdorp[type] = 0.
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_optimized_Nootdorp[type] = results[f"{asset.name}__max_size"]
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_optimized_capex[type] = 0.
                data_sizing_optimized[type] = 0.
                data_sizing_utilization_optimized[type] = 0.
                data_sizing_static_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_static[type] = bounds[f"{asset.name}.Heat_source"][1]
                data_sizing_utilization_static[type] = results[f"{asset.name}__max_size"]
                data_sizing_utilization_static_Nootdorp[type] = 0.
                data_sizing_utilization_optimized_Nootdorp[type] = 0.
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_static_Nootdorp[type] = results[f"{asset.name}__max_size"]
        else:
            data_year[type] += np.asarray(results[f"{asset.name}.Heat_source"])
            data_energy[type] += np.sum(np.asarray(results[f"{asset.name}.Heat_source"][1:]) * timesteps)
            data_opex[type] += results[f"{asset.name}__fixed_operational_cost"] + results[f"{asset.name}__variable_operational_cost"]
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] += (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] += results[f"{asset.name}__max_size"]
                data_sizing_utilization_optimized[type] += bounds[f"{asset.name}.Heat_source"][1]
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_optimized_Nootdorp[type] += results[f"{asset.name}__max_size"]
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_static_capex[type] += (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_static[type] += bounds[f"{asset.name}.Heat_source"][1]
                data_sizing_utilization_static[type] += results[f"{asset.name}__max_size"]
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_static_Nootdorp[type] += results[f"{asset.name}__max_size"]
        if type not in data_peak.keys():
            data_peak[type] = np.asarray(results[f"{asset.name}.Heat_source"][__indx_max_peak:__indx_max_peak+24])
        else:
            data_peak[type] += np.asarray(results[f"{asset.name}.Heat_source"][__indx_max_peak:__indx_max_peak+24])
    elif asset.asset_type in ["ATES"]:
        type = asset.asset_type
        if type not in data_year.keys():
            data_year[type] = np.asarray(results[f"{asset.name}.Heat_ates"])
            data_energy[type] = np.sum(np.clip(np.asarray(results[f"{asset.name}.Heat_ates"][1:]),0.,np.inf) * timesteps)
            data_opex[type] = results[f"{asset.name}__fixed_operational_cost"] + results[f"{asset.name}__variable_operational_cost"]
            if round(parameters[f"{asset.name}.state"]) == 2:
                data_sizing_optimized_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] = results[f"{asset.name}__max_size"]
                data_sizing_utilization_optimized[type] = bounds[f"{asset.name}.Heat_ates"][1]
                data_sizing_static_capex[type] = 0.
                data_sizing_static[type] = 0.
                data_sizing_utilization_static[type] = 0.
                data_sizing_utilization_static_Nootdorp[type] = 0.
                data_sizing_utilization_optimized_Nootdorp[type] = 0.
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_optimized_Nootdorp[type] = results[f"{asset.name}__max_size"]
            elif round(parameters[f"{asset.name}.state"]) == 1:
                data_sizing_static_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_static[type] = bounds[f"{asset.name}.Heat_ates"][1]
                data_sizing_utilization_static[type] = results[f"{asset.name}__max_size"]
                data_sizing_optimized_capex[type] = 0.
                data_sizing_optimized[type] = 0.
                data_sizing_utilization_optimized[type] = 0.
                data_sizing_utilization_static_Nootdorp[type] = 0.
                data_sizing_utilization_optimized_Nootdorp[type] = 0.
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_static_Nootdorp[type] = results[f"{asset.name}__max_size"]
        else:
            data_year[type] += np.asarray(results[f"{asset.name}.Heat_ates"])
            data_energy[type] += np.sum(
                np.clip(np.asarray(results[f"{asset.name}.Heat_ates"])[1:], 0., np.inf) * timesteps)
            data_opex[type] += results[f"{asset.name}__fixed_operational_cost"] + results[
                f"{asset.name}__variable_operational_cost"]
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] += (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] += results[f"{asset.name}__max_size"]
                data_sizing_utilization_optimized[type] += bounds[f"{asset.name}.Heat_ates"][1]
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_optimized_Nootdorp[type] += results[f"{asset.name}__max_size"]
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_static_capex[type] += (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_static[type] += bounds[f"{asset.name}.Heat_ates"][1]
                data_sizing_utilization_static[type] += results[f"{asset.name}__max_size"]
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_static_Nootdorp[type] += results[f"{asset.name}__max_size"]
        if type not in data_peak.keys():
            data_peak[type] = np.asarray(
                results[f"{asset.name}.Heat_ates"][__indx_max_peak:__indx_max_peak + 24])
        else:
            data_peak[type] += np.asarray(
                results[f"{asset.name}.Heat_ates"][__indx_max_peak:__indx_max_peak + 24])
    elif asset.asset_type in ["HeatStorage"]:
        type = asset.asset_type
        data_opex[type] = 0.
        if type not in data_year.keys():
            data_year[type] = np.asarray(results[f"{asset.name}.Heat_buffer"])
        else:
            data_year[type] += np.asarray(results[f"{asset.name}.Heat_buffer"])
        if type not in data_peak.keys():
            data_peak[type] = np.asarray(
                results[f"{asset.name}.Heat_buffer"][__indx_max_peak:__indx_max_peak + 24])
            if round(parameters[f"{asset.name}.state"]) == 2:
                data_sizing_optimized_capex[type] = (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] = max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
                data_sizing_utilization_optimized[type] = bounds[f"{asset.name}.Heat_buffer"][1]
                data_sizing_static_capex[type] = 0.
                data_sizing_static[type] = 0.
                data_sizing_utilization_static[type] = 0.
                data_sizing_utilization_static_Nootdorp[type] = 0.
                data_sizing_utilization_optimized_Nootdorp[type] = 0.
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_optimized_Nootdorp[type] = max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
            elif round(parameters[f"{asset.name}.state"]) == 1:
                data_sizing_static_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_static[type] = bounds[f"{asset.name}.Heat_buffer"][1]
                data_sizing_utilization_static[type] = max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
                data_sizing_optimized_capex[type] = 0.
                data_sizing_optimized[type] = 0.
                data_sizing_utilization_optimized[type] = 0.
                data_sizing_utilization_static_Nootdorp[type] = 0.
                data_sizing_utilization_optimized_Nootdorp[type] = 0.
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_static_Nootdorp[type] = max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
        else:
            data_peak[type] += np.asarray(
                results[f"{asset.name}.Heat_buffer"][__indx_max_peak:__indx_max_peak + 24])
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] += (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] += max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
                data_sizing_utilization_optimized[type] += bounds[f"{asset.name}.Heat_buffer"][1]
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_optimized_Nootdorp[type] = max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_static_capex[type] += (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_static[type] += bounds[f"{asset.name}.Heat_buffer"][1]
                data_sizing_utilization_static[type] += max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
                if asset.attributes["geometry"].lat > 52.03:
                    data_sizing_utilization_static_Nootdorp[type] = max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
    elif asset.asset_type in ["Pipe"]:
        type = asset.asset_type
        if "_ret" in asset.name:
            continue
        else:
            pipe_name = asset.name

        if type not in data_opex.keys():
            data_opex[type] = 0.
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] = (
                            results[f"{pipe_name}__investment_cost"] + results[
                        f"{pipe_name}__installation_cost"])
                data_sizing_static_capex[type] = 0.
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_optimized_capex[type] = 0.
                data_sizing_static_capex[type] = (
                            results[f"{pipe_name}__investment_cost"] + results[
                        f"{pipe_name}__installation_cost"])
        else:
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] += (
                            results[f"{pipe_name}__investment_cost"] + results[
                        f"{pipe_name}__installation_cost"])
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_static_capex[type] += (
                            results[f"{pipe_name}__investment_cost"] + results[
                        f"{pipe_name}__installation_cost"])





def plot_year_timeseries(date_times, max_indx, demand, source_data, path):
    new_date_times = np.hstack((date_times[:max_indx + 1], date_times[max_indx + 24:]))
    new_demand = np.hstack((demand[:max_indx], np.mean(demand[max_indx:max_indx+24]), demand[max_indx+24:]))
    plt.figure().set_size_inches(10, 6)
    plt.title("Year")
    plt.plot(new_date_times, new_demand / 1.e6, label="realized demand")
    for key, data in source_data.items():
        new_data = np.hstack((data[:max_indx], np.mean(data[max_indx:max_indx+24]), data[max_indx+24:]))
        plt.plot(new_date_times, new_data / 1.e6, label=key)
    plt.legend()
    plt.ylabel("Power [MW]")
    plt.savefig(path)

total_demand = np.asarray([0.]*(len(timesteps)+1))
for d in demands:
    realized_demand = results[f"{d}.Heat_demand"]
    total_demand += np.asarray(realized_demand)
    target = parameters[f"{d}.target_heat_demand"]
    delta_energy = np.sum((np.asarray(realized_demand) - np.asarray(target))[1:] * timesteps / 1.0e9)
    mismatch = delta_energy / np.sum(np.asarray(target)[1:] * timesteps / 1.0e9) * 100.
    if abs(delta_energy) >= 1.0:
        print(f"For demand {d} the target is not matched by {mismatch} %")

results_path = os.path.join(workdir, "year.svg")
plot_year_timeseries(new_date_times, __indx_max_peak, year_total_demand, data_year, results_path)

# plot flow through knip leiding
plt.figure().set_size_inches(10, 6)
plt.title("knip leiding")
knip_pipe_name = "Pipe31"
data = np.asarray(results[f"{knip_pipe_name}.HeatIn.Heat"])
dt = np.hstack((new_date_times[:__indx_max_peak + 1], new_date_times[__indx_max_peak + 24:]))
new_data = np.hstack((data[:__indx_max_peak], np.mean(data[__indx_max_peak:__indx_max_peak+24]), data[__indx_max_peak+24:]))
plt.plot(dt, new_data / 1.e6, label="MWth")
plt.legend()
plt.ylabel("Power [MW]")
plt.savefig(os.path.join(workdir, "knipPipe.svg"))

# plot production capacity nootdorp vs. pijnacker
# data_sizing_utilization_optimized_Nootdorp: dict containing the sizes of the aggregated optimized assets above lat 52.03
# data_sizing_utilization_static_Nootdorp: dict containing the sizes of the aggregated static assets above lat 52.03


def draw_pie(ax, ratios, xpos, ypos, size, colors):
    cumsum = np.cumsum(ratios)
    cumsum = cumsum / cumsum[-1]
    pie = [0] + cumsum.tolist()

    for i, (r1, r2) in enumerate(zip(pie[:-1], pie[1:])):
        angles = np.linspace(2 * np.pi * (-r1 + 0.25), 2 * np.pi * (-r2 + 0.25))
        x = [0] + np.cos(angles).tolist()
        y = [0] + np.sin(angles).tolist()

        xy = np.column_stack([x, y])
        ax.scatter([xpos], [ypos], marker=xy, s=size, color=colors[i])


AGGREGATED_DEMANDS = {
    "RotterdamZuid": ["RD_Pendrecht", "RD_MaasstadMC", "RD_Carnisse", "RD_KopVanZuid"],
    "RotterdamNoord": ["RD_WSG", "RD_ErasmusMC", "RD_Schiehaven", "RD_Bleekerstraat",
                "RD_Mariniersweg"],
    "DenHaag": ["DH_CRplein", "DH_DenHaag_Z"]
}

def get_joint_asset_coords(demand_name, esdl_assets):

    if demand_name in AGGREGATED_DEMANDS:
        xpos = float(np.mean(
            [[a for a in esdl_assets.values() if a.name == "Joint_" + cluster_name][0]
             .attributes["geometry"].lon for cluster_name in AGGREGATED_DEMANDS[demand_name]]
        ))
        ypos = float(np.mean(
            [[a for a in esdl_assets.values() if a.name == "Joint_" + cluster_name][0]
             .attributes["geometry"].lat for cluster_name in AGGREGATED_DEMANDS[demand_name]]
        ))
    else:
        xpos = [a for a in esdl_assets.values() if a.name == "Joint_" + demand_name][0]\
            .attributes["geometry"].lon
        ypos = [a for a in esdl_assets.values() if a.name == "Joint_" + demand_name][0] \
            .attributes["geometry"].lat
    return xpos, ypos

EXTENT = (4.04297, 4.63898, 51.82432, 52.18235)
RATIO = 1 / np.cos((EXTENT[-1] + EXTENT[-2]) / 2 / 360 * 2 * np.pi)

def plot_pie_charts(energy, total_energy, plot_demands, esdl_assets, background_image, path):
    fig, ax = plt.subplots()
    fig.set_size_inches(10 * RATIO, 10)
    im = plt.imread(background_image)
    plt.imshow(im, extent=EXTENT)
    colors = ["red", "blue", "green", "yellow"]
    max_demand = sorted(total_energy.values())[-4]

    for idx, plot_demand in enumerate(plot_demands):
        data = [energy["HEX"][idx], energy["GEO"][idx], energy["Peakprod"][idx], energy["Residual"][idx]]
        total_demand = total_energy[plot_demand]

        xpos, ypos = get_joint_asset_coords(plot_demand, esdl_assets)
        size = min(total_demand / max_demand * 2000, 2000)
        draw_pie(ax, ratios=data, xpos=xpos, ypos=ypos, size=size, colors=colors)

    plt.gca().set_aspect(RATIO)
    lines = [
        matplotlib.lines.Line2D([0], [0], color="red"),
        matplotlib.lines.Line2D([0], [0], color="blue"),
        matplotlib.lines.Line2D([0], [0], color="green"),
        matplotlib.lines.Line2D([0], [0], color="yellow"),
    ]
    plt.legend(lines, ["Regionaal", "Geo", "Peak", "Restwarmte"])
    ax.set_xticks([])
    ax.set_yticks([])
    plt.savefig(path)

def plot_peak_timeseries(demand, source_data, path):
    plt.figure().set_size_inches(10, 6)
    plt.title("Peak")
    plt.plot(demand / 1.e6, label="realized demand")
    for key, data in source_data.items():
        plt.plot(data / 1.e6, label=key)
    plt.legend()
    plt.ylabel("Power [MW]")
    plt.savefig(path)
results_path = os.path.join(workdir, "peak.svg")
plot_peak_timeseries(peak_day_total_demand, data_peak, results_path)

a = 1

names = list(data_sizing_static.keys())
plt.figure().set_size_inches(10,6)
plt.title("Asset Sizes")
plt.bar(np.arange(len(data_sizing_utilization_optimized)),
                    np.asarray(list(data_sizing_utilization_optimized.values()))/1.e6,
                    color="g", tick_label=names, width=0.25, label = "Optimization upper bound")
plt.bar(np.arange(len(data_sizing_optimized)), np.asarray(list(data_sizing_optimized.values()))/1.e6, color="b", alpha=.5, hatch='/', tick_label=names, width=0.25, label="Optimized")
plt.bar(np.arange(len(data_sizing_static))+ 0.25, np.asarray(list(data_sizing_static.values()))/1.e6, color="g", tick_label=names, width=0.25, label="Existing capacity")
plt.bar(np.arange(len(data_sizing_utilization_static)) + 0.25,
        np.asarray(list(data_sizing_utilization_static.values()))/1.e6,
        color="r", tick_label=names, alpha=.5, hatch='/', width=0.25, label="Power utilized")
plt.legend()
plt.ylabel("Size [MW]")
results_path = os.path.join(workdir, "sizes.svg")
plt.savefig(results_path)

names = list(data_opex.keys())
plt.figure().set_size_inches(10,6)
plt.title("Asset OPEX")
plt.bar(np.arange(len(data_opex)),
        np.asarray(list(data_opex.values()))/1.e6,
        color="b", tick_label=names, width=0.25)
plt.legend()
plt.ylabel("OPEX [M€]")
results_path = os.path.join(workdir, "opex.svg")
plt.savefig(results_path)

names = list(data_energy.keys())
plt.figure().set_size_inches(10,6)
plt.title("Asset energy")
plt.bar(np.arange(len(data_energy)),
        np.asarray(list(data_energy.values()))/1.e15,
        color="b", tick_label=names, width=0.25)
plt.legend()
plt.ylabel("Energy [PJ]")
results_path = os.path.join(workdir, "energy.svg")
plt.savefig(results_path)

names = list(data_sizing_static_capex.keys())
plt.figure().set_size_inches(10,6)
plt.title("Asset CAPEX")
plt.bar(np.arange(len(data_sizing_optimized_capex)), np.asarray(list(data_sizing_optimized_capex.values()))/1.e6,
        color="b", tick_label=names, width=0.25, label="Optimized")
plt.bar(np.arange(len(data_sizing_static_capex)) + 0.25, np.asarray(list(data_sizing_static_capex.values()))/1.e6,
        color="g", tick_label=names, width=0.25, label="existing")
plt.legend()
plt.ylabel("CAPEX [M€]")
results_path = os.path.join(workdir, "capex.svg")
plt.savefig(results_path)

TCO = 0.
energy = 0.
years = parameters["number_of_years"]
for key, value in data_energy.items():
    if key != "ATES":
        energy += value / 1.e9 * years
for key, value in data_opex.items():
    TCO += value * years
for key, value in data_sizing_static_capex.items():
    TCO += value
for key, value in data_sizing_optimized_capex.items():
    TCO += value
# for key, value in insu_cost.items():
#     TCO += value[0]

LCOE = TCO / energy


plt.figure().set_size_inches(10, 6)
plt.title("TCO breakdown")
names = list(data_opex.keys())
plt.bar(np.arange(len(data_opex)),
        np.fromiter(data_opex.values(), dtype=float) * years / 1.e6,
        color="b", tick_label=names, width=0.25, label="opex")
plt.bar(np.arange(len(data_sizing_static_capex)) + 0.25,
        list((np.fromiter(data_sizing_static_capex.values(), dtype=float) + np.fromiter(
            data_sizing_optimized_capex.values(), dtype=float)) / 1.e6),
        color="g", tick_label=names, width=0.25, label="capex")
max_value = max(np.max(np.fromiter(data_sizing_static_capex.values(), dtype=float) + np.fromiter(
    data_sizing_optimized_capex.values(), dtype=float)) / 1.e6, np.max(np.fromiter(data_opex.values(), dtype=float)/ 1.e6) )
plt.text(0.65 * len(data_opex), 0.85 * max_value, f"LCOE [€/GJ]: {round(LCOE, 2)}", fontsize=14,
         verticalalignment='top')
plt.legend()
plt.ylabel("M€")
results_path = os.path.join(workdir, "tco.svg")
plt.savefig(results_path)


