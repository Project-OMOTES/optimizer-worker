"""WarmingUP MPC scripts

Scripts to run model-predictive control cases for WarmingUP using the
RTC-Tools Heat Network library.
"""

import sys

from setuptools import find_packages, setup

import versioneer

DOCLINES = __doc__.split("\n")

CLASSIFIERS = """\
Development Status :: 4 - Beta
Intended Audience :: Science/Research
Intended Audience :: Information Technology
License :: OSI Approved :: GNU Lesser General Public License v3 (LGPLv3)
Programming Language :: Other
Topic :: Scientific/Engineering :: GIS
Topic :: Scientific/Engineering :: Mathematics
Topic :: Scientific/Engineering :: Physics
Operating System :: Microsoft :: Windows
Operating System :: POSIX
Operating System :: Unix
Operating System :: MacOS
"""

if sys.version_info < (3, 8):
    sys.exit("Sorry, Python 3.8 or newer is required.")

setup(
    name="WarmingUP-MPC",
    version=versioneer.get_version(),
    description=DOCLINES[0],
    classifiers=[_f for _f in CLASSIFIERS.split("\n") if _f],
    url="https://www.warmingup.info",
    author="Teresa Piovesan",
    author_email="teresa.piovesan@deltares.nl",
    maintainer="Teresa Piovesan",
    license="LGPLv3",
    keywords="warmingup heat network optimization rtc tools",
    platforms=["Windows", "Linux", "Mac OS-X", "Unix"],
    packages=find_packages("src"),
    package_dir={"": "src"},
    install_requires=[
        "jinja2 >= 2.11.0",
        "pandas",
        "pika",
        "pyesdl >= 21.11.0",
        "rtc-tools-heat-network >= 0.1.7",
        "flask"
    ],
    tests_require=["pytest", "pytest-runner"],
    include_package_data=True,
    python_requires=">=3.8",
    cmdclass=versioneer.get_cmdclass(),
)
