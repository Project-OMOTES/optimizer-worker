import json
import logging
import shutil
import uuid
from pathlib import Path

import pika

from warmingup_mpc.amqp_base import AMQPBase

logger = logging.getLogger("warmingup-mpc")


class AMQPClient(AMQPBase):
    def __init__(self):
        # Set up exchange and channels
        super().__init__()

        self._response = None
        self._corr_id = None

        # TODO: Remove when we go to threading?
        result = self.channel.queue_declare(queue="", exclusive=True)
        self.callback_queue = result.method.queue

        self.channel.basic_consume(
            queue=self.callback_queue, on_message_callback=self.on_response, auto_ack=True
        )

    def on_response(self, _ch, _method, props, body):
        if self._corr_id == props.correlation_id:
            self._response = body

    def _call(self, command):
        self._response = None
        self._corr_id = str(uuid.uuid4())
        self.channel.basic_publish(
            exchange=self.EXCHANGE,
            routing_key=self.COMMAND_QUEUE,
            properties=pika.BasicProperties(
                reply_to=self.callback_queue,
                correlation_id=self._corr_id,
            ),
            body=json.dumps(command),
        )

        while self._response is None:
            self.connection.process_data_events()

        return json.loads(self._response.decode("utf-8"))

    def run_runinfo_workflow(self, workflow_name: str, runinfo_path: Path, log_level):
        b64_file_contents = self._serialize_runinfo(runinfo_path)

        command = {
            "version": 1,
            "command": "run_runinfo_workflow",
            "arguments": {
                "workflow": workflow_name,
                "runinfo": runinfo_path.name,
                "log_level": log_level,
                "file_contents": b64_file_contents,
            },
        }

        response = self._call(command)

        if response["error"]:
            logger.exception(f"Remote procedure call returned with error:\n{response['error']}")
            return

        result_b64_file_contents = response["result"]
        tmp_dir = self._deserialize_runinfo(result_b64_file_contents)

        # Copy output and model folder, both of which contain results.
        tmp_dir_path = Path(tmp_dir.name)
        base_path = runinfo_path.parent

        for folder in ["model", "to_cf"]:
            shutil.copytree(tmp_dir_path / folder, base_path / folder, dirs_exist_ok=True)

        # Cleanup
        tmp_dir.cleanup()
