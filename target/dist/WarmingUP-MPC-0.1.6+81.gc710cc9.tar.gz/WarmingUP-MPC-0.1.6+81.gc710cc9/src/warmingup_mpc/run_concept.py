import logging
import math
from abc import ABC

import numpy as np

from rtctools.optimization.collocated_integrated_optimization_problem import (
    CollocatedIntegratedOptimizationProblem,
)
from rtctools.optimization.goal_programming_mixin import Goal, GoalProgrammingMixin
from rtctools.optimization.goal_programming_mixin_base import _GoalProgrammingMixinBase
from rtctools.optimization.homotopy_mixin import HomotopyMixin
from rtctools.optimization.linearized_order_goal_programming_mixin import (
    LinearizedOrderGoalProgrammingMixin,
)
from rtctools.optimization.timeseries import Timeseries

from rtctools_heat_network.base_component_type_mixin import BaseComponentTypeMixin
from rtctools_heat_network.esdl.esdl_mixin import ESDLMixin
from rtctools_heat_network.heat_mixin import HeatMixin
from rtctools_heat_network.qth_mixin import QTHMixin
from rtctools_heat_network.util import run_heat_network_optimization

from warmingup_mpc._helpers import _main_decorator


logger = logging.getLogger("WarmingUP-MPC")
logger.setLevel(logging.INFO)


class TargetHeatGoal(Goal):
    priority = 1

    order = 2

    def __init__(self, state, target):
        self.state = state

        self.target_min = target
        self.target_max = target
        self.function_range = (0.0, 2.0 * max(target.values))
        self.function_nominal = np.median(target.values)

    def function(self, optimization_problem, ensemble_member):
        return optimization_problem.state(self.state)


class ConstantGeothermalSource(Goal):
    priority = 2

    order = 2

    def __init__(self, optimization_problem, source, target, lower_fac=0.9, upper_fac=1.1):
        self.target_min = lower_fac * target
        self.target_max = upper_fac * target
        self.function_range = (0.0, 2.0 * target)
        self.state = f"{source}.Q"
        self.function_nominal = optimization_problem.variable_nominal(self.state)

    def function(self, optimization_problem, ensemble_member):
        return optimization_problem.state(self.state)


class MinimizeSource(Goal):
    priority = 3

    order = 1

    function_nominal = 1.0

    def __init__(self, state, price, nominal, bias=0.0):
        self.state = state
        self.price = price
        self._nominal = nominal
        self._bias = bias

    def function(self, optimization_problem, ensemble_member):
        return (optimization_problem.state(self.state) * self.price - self._bias) / self._nominal


class _GoalsAndOptions(BaseComponentTypeMixin, _GoalProgrammingMixinBase, ABC):
    """
    Priority 1: Match target demands (order 2, nominal differs per demand)
    Priority 2: Meet target flow rate of geothermal source
    Priority 3: Minimize total production of sources (order 1)
    """

    def __init__(self, *args, esdl_run_info_path=None, **kwargs):
        self.esdl_run_info_path = esdl_run_info_path
        super().__init__(*args, **kwargs)

    def pre(self):
        super().pre()

        # Make sure that all demands have a Timeseries set
        for demand in self.heat_network_components["demand"]:
            try:
                _ = self.get_timeseries(f"{demand}.target_heat_demand")
            except KeyError:
                raise KeyError(f"Could not find a Timeseries for '{demand}.Heat_demand'")

    def read(self):
        super().read()

        # Workaround for CF not always forcing the system time (=forecast
        # datetime) to be within the start - end datetime range.
        datetimes = self.io.datetimes
        ref_datetime = self.io.reference_datetime

        if ref_datetime < datetimes[0]:
            logger.info(
                f"Reference datetime '{ref_datetime}' before earliest data point '{datetimes[0]}'. "
                f"Setting reference datetime to '{datetimes[0]}'."
            )
            self.io.reference_datetime = datetimes[0]
            self._ESDLMixin__timeseries_import.forecast_datetime = datetimes[0]

    def path_goals(self):
        goals = super().path_goals().copy()

        total_demand = None
        times = self.times()
        parameters = self.parameters(0)

        for demand in self.heat_network_components["demand"]:
            target = self.get_timeseries(f"{demand}.target_heat_demand")
            state = f"{demand}.Heat_demand"

            goals.append(TargetHeatGoal(state, target))

        for source in self.heat_network_components["source"]:
            try:
                target = self.get_timeseries(f"{source}.target_heat_source")
                state = f"{source}.Heat_source"

                goals.append(TargetHeatGoal(state, target, priority=1))
            except KeyError:
                pass

            interp_demand = self.interpolate(times, target.times, target.values)
            if total_demand is None:
                total_demand = interp_demand
            else:
                total_demand = np.sum([total_demand, interp_demand], axis=0)

        # If there are any geothermal sources with a target flow rate set, try
        # to stay close to this target.
        for s in self.heat_network_components["source"]:
            try:
                target_flow_rate = parameters[f"{s}.target_flow_rate"]
                goals.append(ConstantGeothermalSource(self, s, target_flow_rate))
            except KeyError:
                pass

        # We assume we are minimizing about 10% of the total demand as a nominal value
        total_source_nominal = 0.1 * np.median(
            [
                self.variable_nominal(f"{s}.Heat_source") * parameters[f"{s}.price"]
                for s in self.heat_network_components["source"]
            ]
        )
        median_total_demand = np.median(total_demand)

        for s in self.heat_network_components["source"]:
            price = parameters[f"{s}.price"]
            goals.append(
                MinimizeSource(f"{s}.Heat_source", price, total_source_nominal, median_total_demand)
            )

        return goals


class HeatProblem(
    _GoalsAndOptions,
    HeatMixin,
    LinearizedOrderGoalProgrammingMixin,
    GoalProgrammingMixin,
    ESDLMixin,
    CollocatedIntegratedOptimizationProblem,
):
    def heat_network_options(self):
        options = super().heat_network_options()
        options["maximum_temperature_der"] = np.nan
        return options

    def write(self):
        # We do not want to write anything out in the Heat problem
        pass

    def solver_options(self):
        options = super().solver_options()

        cbc_options = options["cbc"] = {}
        cbc_options["seconds"] = 20

        return options

    def solver_success(self, solver_stats, log_solver_failure_as_error):
        success, log_level = super().solver_success(solver_stats, log_solver_failure_as_error)

        # Allow time-outs for CPLEX and CBC
        if (
            solver_stats["return_status"] == "time limit exceeded"
            or solver_stats["return_status"] == "stopped - on maxnodes, maxsols, maxtime"
        ):
            if self.objective_value > 1e10:
                # Quick check on the objective value. If no solution was
                # found, this is typically something like 1E50.
                return success, log_level

            return True, logging.INFO
        else:
            return success, log_level


class QTHProblem(
    _GoalsAndOptions,
    QTHMixin,
    HomotopyMixin,
    GoalProgrammingMixin,
    ESDLMixin,
    CollocatedIntegratedOptimizationProblem,
):
    def heat_network_options(self):
        options = super().heat_network_options()
        options["maximum_temperature_der"] = np.nan
        return options

    def post(self):
        # Calculate some additional results required/wanted by the CF
        times = self.times()

        for ensemble_member in range(self.ensemble_size):
            results = self.extract_results(ensemble_member)
            parameters = self.parameters(ensemble_member)

            # dH for demand and sources
            for demand in self.heat_network_components["demand"]:
                dh = results[f"{demand}.QTHOut.H"] - results[f"{demand}.QTHIn.H"]
                self.set_timeseries(f"{demand}.dH", Timeseries(times, dh), ensemble_member)

            for source in self.heat_network_components["source"]:
                dh = results[f"{source}.QTHOut.H"] - results[f"{source}.QTHIn.H"]
                self.set_timeseries(f"{source}.dH", Timeseries(times, dh), ensemble_member)

            # velocity in pipes
            for pipe in self.heat_network_components["pipe"]:
                diameter = parameters[f"{pipe}.diameter"]
                area = math.pi * diameter**2 / 4

                q = results[f"{pipe}.Q"]
                self.set_timeseries(
                    f"{pipe}.velocity", Timeseries(times, q / area), ensemble_member
                )
            for buffer in self.heat_network_components.get("buffer", []):
                q = results[f"{buffer}.Q_hot_pipe"]
                rho = parameters[f"{buffer}.rho"]
                cp = parameters[f"{buffer}.cp"]
                delta_temperature = results[f"{buffer}.QTHIn.T"] - results[f"{buffer}.QTHOut.T"]
                self.set_timeseries(
                    f"{buffer}.Heat_buffer",
                    Timeseries(times, q * rho * cp * delta_temperature),
                    ensemble_member,
                )

            sum_all = 0.0

            for pipe in self.heat_network_components["pipe"]:
                q = results[f"{pipe}.Q"]
                rho = parameters[f"{pipe}.rho"]
                cp = parameters[f"{pipe}.cp"]
                delta_temperature = results[f"{pipe}.QTHIn.T"] - results[f"{pipe}.QTHOut.T"]
                self.set_timeseries(
                    f"{pipe}.Heat_loss",
                    Timeseries(times, q * rho * cp * delta_temperature),
                    ensemble_member,
                )

                sum_all += q * rho * cp * delta_temperature

        super().post()


@_main_decorator
def main(runinfo_path, log_level):
    heat_problem, qth_problem = run_heat_network_optimization(
        HeatProblem, QTHProblem, esdl_run_info_path=runinfo_path, log_level=log_level
    )


if __name__ == "__main__":
    main()
