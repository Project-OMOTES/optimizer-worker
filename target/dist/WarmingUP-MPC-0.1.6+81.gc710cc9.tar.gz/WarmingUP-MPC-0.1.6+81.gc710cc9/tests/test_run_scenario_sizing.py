import sys

from pathlib import Path
from unittest import TestCase

import numpy as np

from rtctools.util import run_optimization_problem

class TestRunScenarioSizing(TestCase):
    def test_run_scenario_sizing(self):
        import models.test_case_small_network_with_ates.src.run_small_network_with_ates as run_ates
        from warmingup_mpc.run_scenario_sizing_v2 import (
            HeatProblemStaged,
        )

        base_folder = Path(run_ates.__file__).resolve().parent.parent

        solution = run_optimization_problem(
            HeatProblemStaged,
            stage=2,
            priorities_output=None,
            base_folder=base_folder,
        )

        results = solution.extract_results()

        # test if the expected costs are as expected
        # test if the objective function value is as expected
        expected_obj = 0.
        for s in [*solution.heat_network_components.get("source", []),
                  *solution.heat_network_components.get("demand", []),
                  *solution.heat_network_components.get("buffer", []),
                  *solution.heat_network_components.get("ates", []),
                  *solution.heat_network_components.get("pipe", [])]:
            expected_obj += results[f"{s}__investment_cost"]

        for s in solution.heat_network_components.get("source", []):
            expected_obj += results[f"{s}__variable_operational_cost"]

        np.testing.assert_allclose(solution.objective_value, expected_obj/1.e6)

        # test if behaviour with ates is as expected
        hp_1 = results["HeatProducer_1.Heat_source"]
        hp_2 = results["HeatProducer_2.Heat_source"]
        ates = results["ATES_033c.Heat_ates"]
        heat_demand = results["HeatingDemand_1.Heat_demand"]
        heat_demand += results["HeatingDemand_2.Heat_demand"]
        heat_demand += results["HeatingDemand_3.Heat_demand"]

        # Check if expensive source is indeed not used
        np.testing.assert_array_less(np.sum(hp_1[1:]), 4.e6) # note some slack to avoid issues with mipgap at 0.01%
        # Check for energy balance, should be fine
        np.testing.assert_array_less(heat_demand, hp_1 + hp_2 + ates) # note all less due to heat losses
        # Check if ates loses energy
        np.testing.assert_array_less(np.sum(heat_demand),
                                     np.sum(hp_2 + np.abs(np.clip(ates, -np.inf, 0.))))

    def test_run_scenario_sizing_optional_assets(self):
        import \
            models.test_case_small_network_with_ates_optional_assets.src.run_small_network_with_ates_optional_assets as run_ates
        from warmingup_mpc.run_scenario_sizing_v2 import (
            HeatProblemStaged,
        )

        base_folder = Path(run_ates.__file__).resolve().parent.parent

        solution = run_optimization_problem(
            HeatProblemStaged,
            stage=2,
            priorities_output=None,
            base_folder=base_folder,
        )

        results = solution.extract_results()
        parameters = solution.parameters(0)

        expected_obj = 0.
        for s in [*solution.heat_network_components.get("source", []),
                  *solution.heat_network_components.get("buffer", []),
                  *solution.heat_network_components.get("ates", []),
                  *solution.heat_network_components.get("pipe", [])]:
            expected_obj += results[f"{s}__investment_cost"]
            expected_obj += parameters[f"{s}.installation_cost"]

        for s in solution.heat_network_components.get("source", []):
            expected_obj += results[f"{s}__variable_operational_cost"]

        for s in [*solution.heat_network_components.get("source", []),
                  *solution.heat_network_components.get("buffer", []),
                  *solution.heat_network_components.get("ates", [])]:
            expected_obj += results[f"{s}__fixed_operational_cost"]

        np.testing.assert_allclose(solution.objective_value, expected_obj / 1.e6)
        # Check that both sources are placed to fulfull the peak day demand
        np.testing.assert_allclose(results["HeatProducer_1__placed"], 1.)
        np.testing.assert_allclose(results["HeatProducer_2__placed"], 1.)

