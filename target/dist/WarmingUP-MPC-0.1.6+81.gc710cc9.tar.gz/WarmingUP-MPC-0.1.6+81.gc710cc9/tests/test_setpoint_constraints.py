from rtctools.util import run_optimization_problem

from pathlib import Path
from unittest import TestCase
import numpy as np


class TestRunSmallAtes(TestCase):
    def test_run_small_ates_timed_setpoints(self):
        """
        Run the small the small network with ATES and check that the setpoint changes as specified.
        The heat source for producer_1 changes 8 times (consecutively) when no timed_setpoints are
        specified. The 1 year heat demand profiles contains demand values: hourly (peak day), weekly
        (every 5days/120hours/432000s) and 1 time step of 4days (96hours/345600s, step before the
        start of the peak day). Now check that the time_setpoints can limit the setpoint changes to:
            - 2 change/year
            - 0 change/year
            - 1 change every 119 hours (less than 5 days), resulting in 8 setpoint changes/year
            - 1 change every 120 hours (every 5 days), resulting in 8 setpoint changes/year
            - 1 change every 121 hours (more than 5 days), resulting in 4 setpoint changes/year
        """
        from models.test_case_small_network_with_ates.src import (
            run_small_network_with_ates as small_network_with_ates,
        )
        from warmingup_mpc.run_scenario_sizing_v2 import HeatProblemCBC

        base_folder = Path(small_network_with_ates.__file__).resolve().parent.parent
        # ------------------------------------------------------------------------------------------
        # Check that solution has 2 changes for the year
        solution_1 = run_optimization_problem(
            HeatProblemCBC,
            base_folder=base_folder,
            **{"timed_setpoints": {"HeatProducer_1": (24 * 365, 2)}},
        )
        results_1 = solution_1.extract_results()
        check_1 = abs(
            results_1["HeatProducer_1.Heat_source"][2:]
            - results_1["HeatProducer_1.Heat_source"][1:-1]
        )
        np.testing.assert_array_equal((check_1 >= 1.0).sum(), 2)
        # ------------------------------------------------------------------------------------------
        # Check that solution has no setpoint change for the year
        solution_2 = run_optimization_problem(
            HeatProblemCBC,
            base_folder=base_folder,
            **{"timed_setpoints": {"HeatProducer_1": (24 * 365, 0)}},  # not change at all - works
        )
        results_2 = solution_2.extract_results()
        check_2 = abs(
            results_2["HeatProducer_1.Heat_source"][2:]
            - results_2["HeatProducer_1.Heat_source"][1:-1]
        )
        np.testing.assert_array_less(check_2, 1.0e-6)
        # ------------------------------------------------------------------------------------------
        # Check that solution setpoint changes 1 time for every 119, 120 and 121 hours
        for ihrs in range(119, 122):
            solution_3 = run_optimization_problem(
                HeatProblemCBC,
                base_folder=base_folder,
                **{"timed_setpoints": {"HeatProducer_1": (ihrs, 1)}},
            )
            results_3 = solution_3.extract_results()
            diff = (
                results_3["HeatProducer_1.Heat_source"][2:]
                - results_3["HeatProducer_1.Heat_source"][1:-1]
            )
            ires = [idx + 2 for idx, val in enumerate(diff) if abs(val) > 1e-6]
            for ii in ires:
                check_3 = (
                    solution_3.get_timeseries("HeatingDemand_1.target_heat_demand", 0).times[ii]
                    - solution_3.get_timeseries("HeatingDemand_1.target_heat_demand", 0).times[
                        ii - 1
                    ]
                )
                # The follwing checks should be true becasue the changes setpoint changes occur at
                # the during 120hr time intervals
                if ihrs == 119:
                    np.testing.assert_array_less(ihrs * 3600, check_3)
                    np.testing.assert_array_equal(len(ires) - 1, 8)
                elif ihrs == 120:
                    np.testing.assert_equal(ihrs * 3600, check_3)
                    np.testing.assert_array_equal(len(ires) - 1, 8)
                elif ihrs == 121:
                    np.testing.assert_equal((ihrs - 1) * 3600, check_3)
                    np.testing.assert_array_less(np.array(ires[1:]) - np.array(ires[:-1]), 4)
                    np.testing.assert_array_equal(len(ires) - 1, 3)
                else:
                    exit("ii out of range")
        # ------------------------------------------------------------------------------------------


if __name__ == "__main__":
    import time

    start_time = time.time()

    abc = TestRunSmallAtes()
    abc.test_run_small_ates_timed_setpoints()

    print("Execution time: " + time.strftime("%M:%S", time.gmtime(time.time() - start_time)))
