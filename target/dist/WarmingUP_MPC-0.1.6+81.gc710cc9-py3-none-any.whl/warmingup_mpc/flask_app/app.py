import base64
import os

from flask import Flask, request, session, abort, Response
from pathlib import Path

from rtctools.util import run_optimization_problem
from warmingup_mpc.run_scenario_sizing_v2 import HeatProblemCBC


def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY='dev'
    )

    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile('config.py', silent=True)
    else:
        # load the test config if passed in
        app.config.from_mapping(test_config)

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    # a simple page that says hello
    @app.route('/hello')
    def hello():
        return 'Hello, World!'

    @app.route('/ESDL/input', methods=['GET', 'POST'])
    def esdl_input():
        if request.method == 'POST':
            esdl_string = request.args.get('ESDL_string', None)
            if esdl_string is not None:
                session['esdl_input_str'] = esdl_string
                return "ESDL updated"
            else:
                response = Response('Missing argument ESDL_string', status=400)
                abort(response)
        else:
            esdl_string = session.get('esdl_input_str', None)
            if esdl_string is not None:
                return esdl_string
            else:
                abort(404)

    @app.route('/ESDL/output', methods=['GET'])
    def esdl_output():
        esdl_string = session.get('esdl_output_str', None)
        if esdl_string is not None:
            return esdl_string
        else:
            abort(404)

    @app.route('/ESDL/run', methods=['GET', 'POST'])
    def run_workflow():
        if request.method == 'POST':
            action = request.args.get('action', None)
            if action is None:
                response = Response('Missing action parameter', status=400)
                abort(response)
            elif action != 'run':
                response = Response('Invalid action, expected action "run"', status=400)
                abort(response)
            elif session.get('is_running', False):
                response = Response('Server already running another optimization', status=503)
                abort(response)
            else:
                session['is_running'] = True
                esdl_string = session.get('esdl_input_str', None)
                if esdl_string is None:
                    response = Response('Server doesn\'t have an input ESDL string', status=400)
                    abort(response)

                base_folder = Path(__file__).resolve().parent.parent

                try:
                    solution = run_optimization_problem(HeatProblemCBC, base_folder=base_folder,
                                                    esdl_string=esdl_string)
                except Exception as e:
                    response = Response(
                        f'Something went wrong while optimizing, caught exception {e}',
                        status=500
                    )
                    abort(response)
                else:
                    session['esdl_output_str'] = base64.b64encode(solution.optimized_esdl_string.encode('utf-8'))
                session['is_running'] = False
                return "Optimization done"
        elif session.get('is_running', False):
            return 'workflow is busy'
        else:
            return 'workflow is done'

    return app