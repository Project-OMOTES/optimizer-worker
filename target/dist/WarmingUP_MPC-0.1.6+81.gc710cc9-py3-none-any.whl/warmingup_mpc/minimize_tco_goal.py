from rtctools.optimization.goal_programming_mixin_base import Goal

from rtctools_heat_network.heat_mixin import HeatMixin


class MinimizeTCO(Goal):
    order = 1

    def __init__(
        self,
        priority=2,
        number_of_years=25.,
    ):
        self.priority = priority
        self.number_of_years=number_of_years

    def function(self, optimization_problem: HeatMixin, ensemble_member):
        obj = 0.0

        parameters = optimization_problem.parameters(ensemble_member)

        for asset in [*optimization_problem.heat_network_components.get("source", []),
                      *optimization_problem.heat_network_components.get("ates", [])]:
            obj += optimization_problem.extra_variable(
                optimization_problem._asset_variable_operational_cost_map[asset]) * self.number_of_years

        for asset in [*optimization_problem.heat_network_components.get("source", []),
                      *optimization_problem.heat_network_components.get("ates", []),
                      *optimization_problem.heat_network_components.get("buffer", [])]:
            obj += optimization_problem.extra_variable(
                optimization_problem._asset_fixed_operational_cost_map[asset]) * self.number_of_years

        for asset in [*optimization_problem.heat_network_components.get("source", []),
                      *optimization_problem.heat_network_components.get("ates", []),
                      *optimization_problem.heat_network_components.get("buffer", []),
                      *optimization_problem.heat_network_components.get("demand", []),
                      *optimization_problem.heat_network_components.get("heat_exchanger", []),
                      *optimization_problem.heat_network_components.get("heat_pump", []),
                      *optimization_problem.heat_network_components.get("pipe", [])]:
            obj += optimization_problem.extra_variable(
                optimization_problem._asset_investment_cost_map[asset])

        for asset in [*optimization_problem.heat_network_components.get("source", []),
                      *optimization_problem.heat_network_components.get("ates", []),
                      *optimization_problem.heat_network_components.get("buffer", []),
                      *optimization_problem.heat_network_components.get("demand", []),
                      *optimization_problem.heat_network_components.get("heat_exchanger", []),
                      *optimization_problem.heat_network_components.get("heat_pump", []),
                      *optimization_problem.heat_network_components.get("pipe", [])]:
            obj += optimization_problem.extra_variable(
                optimization_problem._asset_installation_cost_map[asset])

            # try:
            #     obj += optimization_problem.extra_variable(
            #         f"{asset}__number_of_doublets") * parameters[f"{asset}.installation_cost"]
            # except:
            #     try:
            #         obj += optimization_problem.extra_variable(
            #         f"{asset}__placed") * parameters[f"{asset}.installation_cost"]
            #     except:
            #         obj += parameters[f"{asset}.installation_cost"]

        return obj / 1.e6