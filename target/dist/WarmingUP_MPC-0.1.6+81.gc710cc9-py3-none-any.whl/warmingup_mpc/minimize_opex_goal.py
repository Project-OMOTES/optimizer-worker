import logging

from esdl.esdl import Asset, TimeUnitEnum, UnitEnum

from rtctools.optimization.single_pass_goal_programming_mixin import Goal

from warmingup_mpc._helpers import get_cost_value_and_unit

logger = logging.getLogger("WarmingUP-MPC")
logger.setLevel(logging.INFO)


class MinimizeOPEX(Goal):
    order = 1

    def __init__(self, hourly_steps=24, years=25, priority=None):
        self.priority = priority
        self.year_steps = years
        self.hourly_steps = hourly_steps

    def function(self, optimization_problem, ensemble_member):
        # TODO: change the OPEX problem to use the variable time steps for optimization
        obj = 0
        parameters = optimization_problem.parameters(ensemble_member)
        bounds = optimization_problem.bounds()

        for source in optimization_problem.heat_network_components.get("source", []):
            asset = optimization_problem.get_asset_from_asset_name(source)

            # If size source is not optimized we use the bound
            max_power = bounds[f"{source}.Heat_source"][1]
            if source in optimization_problem._optional_sources:
                # If size source is optimized we use the symbol
                max_power = optimization_problem.extra_variable(f"{source}__max_size")
            # If the source is a geothermal well we set the max power based on the wells.
            # again depending on whether the amount of wells are optimized.
            if asset.asset_type == "GeothermalSource":
                if source in optimization_problem._optional_sources:
                    doublets = optimization_problem.extra_variable(
                        f"{source}__number_of_wells", ensemble_member
                    )
                else:
                    doublets = parameters[f"{source}.nr_of_doublets"]
                single_well_power = parameters[f"{source}.single_doublet_power"]
                max_power = doublets * single_well_power
            cost_dict = get_fixed_opex_costs(asset)
            for _, info in cost_dict.items():
                fixed_operational_cost = info["value"]
                per_unit = info["per_unit"]
                per_time = info["per_time"]
                multiplier = 1.
                if per_unit == UnitEnum.WATT:
                    multiplier *= max_power
                elif per_unit != UnitEnum.NONE:
                    logger.error(f"{asset.name} has {per_unit} specified that we cannot handle must be per unit of power")
                if per_time == TimeUnitEnum.YEAR:
                     multiplier *= self.year_steps
                elif per_time != TimeUnitEnum.NONE:
                    logger.error(f"{asset.name} has {per_time} specified that we cannot handle must be per year")
                else:
                    # if people do not specify the year we inherently assume that they did
                    logger.warning(
                        f"For asset {asset.name} it is assumed that the fixed operational costs are per year")
                    multiplier *= self.year_steps
                obj += fixed_operational_cost * multiplier

        for ates in optimization_problem.heat_network_components.get("ates", []):
            asset = optimization_problem.get_asset_from_asset_name(ates)
            if ates in optimization_problem._optional_ates:
                doublets = optimization_problem.extra_variable(
                    f"{ates}__number_of_doublets", ensemble_member
                )
            else:
                doublets = parameters[f"{ates}.nr_of_doublets"]
            single_well_power = parameters[f"{ates}.single_doublet_power"]
            max_power = doublets * single_well_power
            cost_dict = get_fixed_opex_costs(asset)
            for _, info in cost_dict.items():
                fixed_operational_cost = info["value"]
                per_unit = info["per_unit"]
                per_time = info["per_time"]
                multiplier = 1.
                if per_unit == UnitEnum.WATT:
                    multiplier *= max_power
                elif per_unit != UnitEnum.NONE:
                    logger.error(
                        f"{asset.name} has {per_unit} specified that we cannot handle must be per unit of power")
                if per_time == TimeUnitEnum.YEAR:
                    multiplier *= self.year_steps
                elif per_time != TimeUnitEnum.NONE:
                    logger.error(
                        f"{asset.name} has {per_time} specified that we cannot handle must be per year")
                else:
                    # if people do not specify the year we inherently assume that they did
                    logger.warning(f"For asset {asset.name} it is assumed that the fixed operational costs are per year")
                    multiplier *= self.year_steps

                obj += fixed_operational_cost * multiplier

        return obj / 1.0e6

def get_variable_opex_costs(asset: Asset):
    """
    Returns the variable opex costs of an asset in Euros per Wh
    """
    cost_infos = dict()
    cost_infos["variableOperationalAndMaintenanceCosts"] = asset.attributes[
        "costInformation"
    ].variableOperationalAndMaintenanceCosts
    if asset.attributes["costInformation"].variableOperationalAndMaintenanceCosts is None:
        cost_infos["variableOperationalCosts"] = asset.attributes[
            "costInformation"
        ].variableOperationalCosts
        cost_infos["variableMaintenanceCosts"] = asset.attributes[
            "costInformation"
        ].variableMaintenanceCosts

    if all(cost_info is None for cost_info in cost_infos.values()):
        raise RuntimeError(f"No variable OPEX cost information specified for asset {asset}")

    value = 0.0
    for cost_info in cost_infos.values():
        if cost_info is None:
            continue
        cost_value, unit, per_unit, per_time = get_cost_value_and_unit(cost_info)
        value += cost_value
        if unit != UnitEnum.EURO:
            raise RuntimeError(
                f"Expected cost information {cost_info} to provide a cost in euros."
            )
        if per_time != TimeUnitEnum.NONE:
            raise RuntimeError(
                f"Specified OPEX for asset {asset.name} include a "
                f"component per time, which we cannot handle."
            )
        if per_unit != UnitEnum.WATTHOUR:
            raise RuntimeError(
                f"Expected the specified OPEX for asset "
                f"{asset.name} to be per Wh, but they are provided "
                f"in {per_unit} instead."
            )

    return value

def get_fixed_opex_costs(asset: Asset):
    """
    Returns the fixed opex costs of an asset in Euros per W
    """
    cost_infos = dict()
    cost_infos["fixedOperationalAndMaintenanceCosts"] = asset.attributes[
        "costInformation"
    ].fixedOperationalAndMaintenanceCosts
    if asset.attributes["costInformation"].fixedOperationalAndMaintenanceCosts is None:
        cost_infos["fixedOperationalCosts"] = asset.attributes[
            "costInformation"
        ].fixedOperationalCosts
        cost_infos["fixedMaintenanceCosts"] = asset.attributes[
            "costInformation"
        ].fixedMaintenanceCosts

    if all(cost_info is None for cost_info in cost_infos.values()):
        logger.warning(f"No fixed OPEX cost information specified for asset {asset.name}")
        cost_dict = {}
    else:
        cost_dict = {}
        value = 0.0
        for cost_info in cost_infos.values():
            if cost_info is None:
                continue
            cost_value, unit, per_unit, per_time = get_cost_value_and_unit(cost_info)
            cost_dict[cost_info.id] = {}
            cost_dict[cost_info.id]["value"] = cost_value
            cost_dict[cost_info.id]["per_unit"] = per_unit
            cost_dict[cost_info.id]["per_time"] = per_time
            if unit != UnitEnum.EURO:
                raise RuntimeError(
                    f"Expected cost information {cost_info} to " f"provide a cost in euros."
                )
            # if per_time != TimeUnitEnum.NONE:
            #     raise RuntimeError(
            #         f"Specified OPEX for asset {asset.name} include a "
            #         f"component per time, which we cannot handle."
            #     )
            # if per_unit != UnitEnum.WATT:
            #     raise RuntimeError(
            #         f"Expected the specified OPEX for asset "
            #         f"{asset.name} to be per W, but they are provided "
            #         f"in {per_unit} instead."
            #     )
    return cost_dict
