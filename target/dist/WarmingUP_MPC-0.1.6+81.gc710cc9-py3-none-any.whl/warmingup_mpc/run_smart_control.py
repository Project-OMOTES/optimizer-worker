import logging
import math
import os
import time
import xml.etree.ElementTree as ET  # noqa: N817
from abc import ABC
from enum import Enum
from pathlib import Path

import esdl

import numpy as np

import pandas as pd

from rtctools.optimization.collocated_integrated_optimization_problem import (
    CollocatedIntegratedOptimizationProblem,
)
from rtctools.optimization.goal_programming_mixin import Goal, GoalProgrammingMixin
from rtctools.optimization.goal_programming_mixin_base import _GoalProgrammingMixinBase
from rtctools.optimization.homotopy_mixin import HomotopyMixin
from rtctools.optimization.linearized_order_goal_programming_mixin import (
    LinearizedOrderGoalProgrammingMixin,
)
from rtctools.optimization.timeseries import Timeseries

from rtctools_heat_network.base_component_type_mixin import BaseComponentTypeMixin
from rtctools_heat_network.esdl.esdl_mixin import ESDLMixin
from rtctools_heat_network.heat_mixin import HeatMixin
from rtctools_heat_network.qth_mixin import DemandTemperatureOption, QTHMixin
from rtctools_heat_network.util import run_heat_network_optimization

from warmingup_mpc._helpers import _main_decorator, _sort_numbered


logger = logging.getLogger("WarmingUP-MPC")
logger.setLevel(logging.INFO)

ns = {"fews": "http://www.wldelft.nl/fews", "pi": "http://www.wldelft.nl/fews/PI"}


class CFObjective(Enum):
    MINIMIZE_SUPPLY_TEMPERATURE = 0
    MINIMIZE_COSTS = 1


class TargetHeatGoal(Goal):
    priority = 1

    order = 2

    def __init__(self, state, target):
        self.state = state

        self.target_min = target
        self.target_max = target
        self.function_range = (0.0, 2.0 * max(target.values))
        self.function_nominal = np.median(target.values)

    def function(self, optimization_problem, ensemble_member):
        return optimization_problem.state(self.state)


class ConstantGeothermalSource(Goal):
    priority = 2

    order = 2

    def __init__(self, optimization_problem, source, target, lower_fac=0.9, upper_fac=1.1):
        self.target_min = lower_fac * target
        self.target_max = upper_fac * target
        self.function_range = (0.0, 2.0 * target)
        self.state = f"{source}.Q"
        self.function_nominal = optimization_problem.variable_nominal(self.state)

    def function(self, optimization_problem, ensemble_member):
        return optimization_problem.state(self.state)


class MinimizeSourceTemperature(Goal):
    priority = 3

    order = 1

    def __init__(self, source):
        self.state = f"{source}.QTHOut.T"

    def function(self, optimization_problem, ensemble_member):
        return optimization_problem.state(self.state) / optimization_problem.variable_nominal(
            self.state
        )


class MinimizeSourceCost(Goal):
    priority = 3

    order = 1

    function_nominal = 1.0

    def __init__(self, state, price, nominal, bias=0.0):
        self.state = state
        self.price = price
        self._nominal = nominal
        self._bias = bias

    def function(self, optimization_problem, ensemble_member):
        return (optimization_problem.state(self.state) * self.price - self._bias) / self._nominal


class CFOptions(ESDLMixin):
    def __init__(self, *args, esdl_run_info_path, **kwargs):
        self.esdl_run_info_path = esdl_run_info_path

        self._cf_override_hn_options = {}
        self._cf_override_source_demand_temperatures = {}
        self._cf_demand_minimum_return_temperatures = {}

        self._cf_objective = None

        self._cf_output_folder = None

        # FIXME: Workaround CF UI bug where <inputParameterFile> is always
        # present. This will trip up ESDLMixin when it tries to interpret it,
        # so we remove that line.
        runinfo_path = Path(self.esdl_run_info_path).resolve()
        tree = ET.parse(runinfo_path)
        root = tree.getroot()

        xml_input_parameter_files = root.findall("pi:inputParameterFile", namespaces=ns)
        for f in xml_input_parameter_files:
            root.remove(f)

        runinfo_path.replace(runinfo_path.with_suffix(".xml.old"))
        tree.write(runinfo_path, xml_declaration=True, encoding="utf-8", method="xml")

        work_dir = Path(root.findtext("pi:workDir", namespaces=ns))
        if not work_dir.is_absolute():
            work_dir = runinfo_path.parent / work_dir

        # Get the output folder to store the HTML results in
        output_ref_path = root.findtext("pi:outputTimeSeriesFile", namespaces=ns)
        if output_ref_path is None:
            output_ref_path = self.esdl_run_info_path

        self._cf_html_output_dir = Path(output_ref_path).parent
        if not Path(self._cf_html_output_dir).is_absolute():
            self._cf_html_output_dir = work_dir / self._cf_html_output_dir

        # Now we parse all the options and overrides in the CSV files, and
        # store them as internal variables to be used by the optimization
        # problem class.
        csv_input_parameter_files = root.findall("pi:inputLocationAttributeCsvFile", namespaces=ns)

        csv_input_global_constraints = None
        csv_input_global_goal = None
        csv_input_nodes = None

        self._cf_csv_input_parameter_files = []

        for node in csv_input_parameter_files:
            f = node.text
            if not Path(f).is_absolute():
                f = str(work_dir / f)
            self._cf_csv_input_parameter_files.append(f)

            # Figure out what CSV file it is, and parse it accordingly
            if f.endswith("mpc_global_constraints.csv"):
                csv_input_global_constraints = f
            elif f.endswith("mpc_global_goal.csv"):
                csv_input_global_goal = f
            elif f.endswith("mpc_nodes.csv"):
                csv_input_nodes = f
            elif f.endswith("mpc_links.csv"):
                pass
            else:
                raise Exception(f"Unknown input parameters file '{f}'")

        # Global options/constraints
        for option, is_active, value_num, _ in pd.read_csv(
            csv_input_global_constraints, index_col=0
        ).itertuples(name=None):
            if not is_active:
                continue

            if option == "absolutePressure_min":
                self._cf_override_hn_options["pipe_minimum_pressure"] = float(value_num)
            if option == "absolutePressure_max":
                self._cf_override_hn_options["pipe_maximum_pressure"] = float(value_num)
            if option == "consumerPressureDrop":
                self._cf_override_hn_options["minimum_pressure_far_point"] = float(value_num)
            if option == "equalSourceTemperature":
                assert is_active
                self._cf_override_hn_options["sources_equal_output_temp"] = True
            if option == "velocity_max":
                self._cf_override_hn_options["maximum_velocity"] = float(value_num)

        # Global goal
        obj = pd.read_csv(csv_input_global_goal, index_col=0).index[0]
        self._cf_objective = CFObjective[obj.upper().replace(" ", "_")]

        # Sources/Demands options
        for n, options in pd.read_csv(csv_input_nodes, index_col=0).to_dict("index").items():
            # All but the minimum return temperature of demands we handle by
            # changing the ESDL asset attributes. The ESDL asset has no option
            # to specify the minimum return temperature, so we have to handle
            # it via bounds.
            self._cf_override_source_demand_temperatures[n] = {
                k: v for k, v in options.items() if k != "minReturn_Temperature"
            }

            if not np.isnan(options["minReturn_Temperature"]):
                self._cf_demand_minimum_return_temperatures[n] = options["minReturn_Temperature"]

        super().__init__(*args, esdl_run_info_path=esdl_run_info_path, **kwargs)

    @property
    def esdl_assets(self):
        assets = super().esdl_assets

        for n, options in self._cf_override_source_demand_temperatures.items():
            asset = next(a for a in assets.values() if a.name == n)

            for k, v in options.items():
                if k == "variableOperationalCostsUnit" or np.isnan(v):
                    continue

                # Sources
                if k == "minOutgoing_Temperature":
                    asset.attributes["minTemperature"] = v
                elif k == "maxOutgoing_Temperature":
                    asset.attributes["maxTemperature"] = v
                elif k == "variableOperationalCosts":
                    asset.attributes["costInformation"] = esdl.CostInformation()
                    asset.attributes[
                        "costInformation"
                    ].variableOperationalCosts = esdl.SingleValue()
                    asset.attributes["costInformation"].variableOperationalCosts.value = float(v)
                # Demands
                elif k == "minSupply_Temperature":
                    asset.attributes["minTemperature"] = v
                else:
                    raise Exception(f"Unknown option {k}")

        return assets

    def heat_network_options(self):
        options = super().heat_network_options()
        options.update(self._cf_override_hn_options)
        return options

    def read(self):
        super().read()

        # Workaround for CF not always forcing the system time (=forecast
        # datetime) to be within the start - end datetime range.
        datetimes = self.io.datetimes
        ref_datetime = self.io.reference_datetime

        if ref_datetime < datetimes[0]:
            logger.info(
                f"Reference datetime '{ref_datetime}' before earliest data point '{datetimes[0]}'. "
                f"Setting reference datetime to '{datetimes[0]}'."
            )
            self.io.reference_datetime = datetimes[0]
            self._ESDLMixin__timeseries_import.forecast_datetime = datetimes[0]


class _GoalsAndOptions(BaseComponentTypeMixin, _GoalProgrammingMixinBase, ABC):
    """
    Priority 1: Match target demands (order 2, nominal differs per demand)
    Priority 2: Meet target flow rate of geothermal source
    Priority 3: Minimize temperature sources / Minimize costs (depends on CF objective)
    """

    def __init__(self, *args, esdl_run_info_path=None, **kwargs):
        self.esdl_run_info_path = esdl_run_info_path
        super().__init__(*args, **kwargs)

        # Store (time taken, success, objective values, solver stats) per priority
        self._priorities_output = {}
        self.__priority = None
        self.__priority_timer = None

    def pre(self):
        super().pre()

        # Make sure that all demands have a Timeseries set
        for demand in self.heat_network_components["demand"]:
            try:
                _ = self.get_timeseries(f"{demand}.target_heat_demand")
            except KeyError:
                raise KeyError(f"Could not find a Timeseries for '{demand}.Heat_demand'")

    def path_goals(self):
        goals = super().path_goals().copy()

        total_demand = None
        times = self.times()
        parameters = self.parameters(0)

        for demand in self.heat_network_components["demand"]:
            target = self.get_timeseries(f"{demand}.target_heat_demand")
            state = f"{demand}.Heat_demand"

            goals.append(TargetHeatGoal(state, target))

        for source in self.heat_network_components["source"]:
            try:
                target = self.get_timeseries(f"{source}.target_heat_source")
                state = f"{source}.Heat_source"

                goals.append(TargetHeatGoal(state, target, priority=1))
            except KeyError:
                pass

            interp_demand = self.interpolate(times, target.times, target.values)
            if total_demand is None:
                total_demand = interp_demand
            else:
                total_demand = np.sum([total_demand, interp_demand], axis=0)

        # If there are any geothermal sources with a target flow rate set, try
        # to stay close to this target.
        for s in self.heat_network_components["source"]:
            try:
                target_flow_rate = parameters[f"{s}.target_flow_rate"]
                goals.append(ConstantGeothermalSource(self, s, target_flow_rate))
            except KeyError:
                pass

        if self._cf_objective == CFObjective.MINIMIZE_COSTS:
            # We assume we are minimizing about 10% of the total demand as a nominal value
            total_source_nominal = 0.1 * np.median(
                [
                    self.variable_nominal(f"{s}.Heat_source") * parameters[f"{s}.price"]
                    for s in self.heat_network_components["source"]
                ]
            )
            median_total_demand = np.median(total_demand)

            for s in self.heat_network_components["source"]:
                price = parameters[f"{s}.price"]
                goals.append(
                    MinimizeSourceCost(
                        f"{s}.Heat_source", price, total_source_nominal, median_total_demand
                    )
                )

        return goals

    def priority_started(self, priority):
        self.__priority = priority
        self.__priority_timer = time.time()

        super().priority_started(priority)

    def priority_completed(self, priority):
        super().priority_completed(priority)

        time_taken = time.time() - self.__priority_timer
        self._priorities_output[priority] = (
            time_taken,
            True,
            self.objective_value,
            self.solver_stats,
        )

    def post(self):
        # In case the solver fails, we do not get in priority_completed(). We
        # append this last priority's statistics here in post().
        success, _ = self.solver_success(self.solver_stats, False)
        if not success:
            time_taken = time.time() - self.__priority_timer
            self._priorities_output[self.__priority] = (
                time_taken,
                False,
                self.objective_value,
                self.solver_stats,
            )

        super().post()


class HeatProblem(
    CFOptions,
    _GoalsAndOptions,
    HeatMixin,
    LinearizedOrderGoalProgrammingMixin,
    GoalProgrammingMixin,
    ESDLMixin,
    CollocatedIntegratedOptimizationProblem,
):
    def heat_network_options(self):
        options = super().heat_network_options()
        options["maximum_temperature_der"] = np.nan
        return options

    def write(self):
        # We do not want to write anything out in the Heat problem
        pass

    def solver_options(self):
        options = super().solver_options()

        cbc_options = options["cbc"] = {}
        cbc_options["seconds"] = 100.0

        return options

    def solver_success(self, solver_stats, log_solver_failure_as_error):
        success, log_level = super().solver_success(solver_stats, log_solver_failure_as_error)

        # Allow time-outs for CPLEX and CBC
        if (
            solver_stats["return_status"] == "time limit exceeded"
            or solver_stats["return_status"] == "stopped - on maxnodes, maxsols, maxtime"
        ):
            if self.objective_value > 1e10:
                # Quick check on the objective value. If no solution was
                # found, this is typically something like 1E50.
                return success, log_level

            return True, logging.INFO
        else:
            return success, log_level


class QTHProblem(
    CFOptions,
    _GoalsAndOptions,
    QTHMixin,
    HomotopyMixin,
    GoalProgrammingMixin,
    ESDLMixin,
    CollocatedIntegratedOptimizationProblem,
):
    def heat_network_options(self):
        options = super().heat_network_options()
        options["maximum_temperature_der"] = np.nan
        options["demand_temperature_option"] = DemandTemperatureOption.MIN_RETURN_MAX_DT
        return options

    # Store the homotopy parameter
    @property
    def homotopy_theta(self):
        return self.parameters(0)["theta"]

    def path_goals(self):
        goals = super().path_goals().copy()

        if self._cf_objective == CFObjective.MINIMIZE_SUPPLY_TEMPERATURE:
            # Minimize outgoing temperature of sources
            # Note that all sources will operate at the same temperature
            if self.homotopy_theta > 0.0:
                goals.append(MinimizeSourceTemperature(self.heat_network_components["source"][0]))

        return goals

    def bounds(self):
        bounds = super().bounds()

        for demand, temperature in self._cf_demand_minimum_return_temperatures.items():
            existing_bounds = bounds[f"{demand}.QTHOut.T"]
            _, ub = self.merge_bounds((temperature, np.inf), existing_bounds)
            bounds[f"{demand}.QTHOut.T"] = (temperature, ub)

        return bounds

    def post(self):
        # Calculate some additional results required/wanted by the CF
        times = self.times()

        for ensemble_member in range(self.ensemble_size):
            results = self.extract_results(ensemble_member)
            parameters = self.parameters(ensemble_member)

            # dH for demand and sources
            for demand in self.heat_network_components["demand"]:
                dh = results[f"{demand}.QTHOut.H"] - results[f"{demand}.QTHIn.H"]
                self.set_timeseries(f"{demand}.dH", Timeseries(times, dh), ensemble_member)

            for source in self.heat_network_components["source"]:
                dh = results[f"{source}.QTHOut.H"] - results[f"{source}.QTHIn.H"]
                self.set_timeseries(f"{source}.dH", Timeseries(times, dh), ensemble_member)

            # velocity in pipes
            for pipe in self.heat_network_components["pipe"]:
                diameter = parameters[f"{pipe}.diameter"]
                area = math.pi * diameter**2 / 4

                q = results[f"{pipe}.Q"]
                self.set_timeseries(
                    f"{pipe}.velocity", Timeseries(times, q / area), ensemble_member
                )

            for buffer in self.heat_network_components.get("buffer", []):
                q = results[f"{buffer}.Q_hot_pipe"]
                rho = parameters[f"{buffer}.rho"]
                cp = parameters[f"{buffer}.cp"]
                delta_temperature = results[f"{buffer}.QTHIn.T"] - results[f"{buffer}.QTHOut.T"]
                self.set_timeseries(
                    f"{buffer}.Heat_buffer",
                    Timeseries(times, q * rho * cp * delta_temperature),
                    ensemble_member,
                )

            sum_all = 0.0

            for pipe in self.heat_network_components["pipe"]:
                q = results[f"{pipe}.Q"]
                rho = parameters[f"{pipe}.rho"]
                cp = parameters[f"{pipe}.cp"]
                delta_temperature = results[f"{pipe}.QTHIn.T"] - results[f"{pipe}.QTHOut.T"]
                self.set_timeseries(
                    f"{pipe}.Heat_loss",
                    Timeseries(times, q * rho * cp * delta_temperature),
                    ensemble_member,
                )

                sum_all += q * rho * cp * delta_temperature

        super().post()


def _write_html_output(heat_problem, qth_problem):
    from jinja2 import Environment, FileSystemLoader

    assert qth_problem.ensemble_size == 1

    results = qth_problem.extract_results()

    # Format the priority results
    priority_results = [
        dict(
            number=number,
            success=success,
            pretty_time=f"{int(seconds // 60):02d}:{seconds  % 60:06.3f}",
            objective_value=objective_value,
            return_status=stats["return_status"],
            secondary_return_status=stats.get("secondary_return_status", ""),
        )
        for number, (
            seconds,
            success,
            objective_value,
            stats,
        ) in [*heat_problem._priorities_output.items(), *qth_problem._priorities_output.items()]
    ]

    # Format the source results
    d = qth_problem._cf_override_source_demand_temperatures

    source_results = [
        dict(
            name=source,
            user_minimum_temperature=d[source]["minOutgoing_Temperature"],
            user_maximum_temperature=d[source]["maxOutgoing_Temperature"],
            result_minimum_temperature=min(results[f"{source}.QTHOut.T"]),
            result_maximum_temperature=max(results[f"{source}.QTHOut.T"]),
        )
        for source in _sort_numbered(qth_problem.heat_network_components["source"])
    ]

    # Format the demand results
    d_supply = qth_problem._cf_override_source_demand_temperatures
    d_return = qth_problem._cf_demand_minimum_return_temperatures

    demand_results = [
        dict(
            name=demand,
            user_minimum_supply=d_supply[demand]["minSupply_Temperature"],
            user_minimum_return=d_return[demand],
            result_min_supply_temperature=min(results[f"{demand}.QTHIn.T"]),
            result_max_supply_temperature=max(results[f"{demand}.QTHIn.T"]),
            result_min_return_temperature=max(results[f"{demand}.QTHOut.T"]),
            result_max_return_temperature=max(results[f"{demand}.QTHOut.T"]),
        )
        for demand in _sort_numbered(qth_problem.heat_network_components["demand"])
    ]

    input_csv_tables = {
        os.path.basename(x): pd.read_csv(x).to_dict("records")
        for x in qth_problem._cf_csv_input_parameter_files
    }

    # Actually write out the html file based on the template
    templates_dir = Path(__file__).parent / "templates"

    env = Environment(loader=FileSystemLoader(templates_dir))
    template = env.get_template("mpc_smart_control_output.html")

    os.makedirs(qth_problem._cf_html_output_dir, exist_ok=True)

    filename = qth_problem._cf_html_output_dir / "mpc_smart_control_output.html"

    with open(filename, "w", encoding="utf-8") as fh:
        fh.write(
            template.render(
                source_results=source_results,
                demand_results=demand_results,
                priority_results=priority_results,
                input_csv_tables=input_csv_tables,
            )
        )


@_main_decorator
def main(runinfo_path, log_level):
    heat_problem, qth_problem = run_heat_network_optimization(
        HeatProblem, QTHProblem, esdl_run_info_path=runinfo_path, log_level=log_level
    )

    _write_html_output(heat_problem, qth_problem)


if __name__ == "__main__":
    main()
