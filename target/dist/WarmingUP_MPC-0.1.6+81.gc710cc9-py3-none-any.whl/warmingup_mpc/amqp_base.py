import base64
import logging
import os
import ssl
import tempfile
import time
import xml.etree.ElementTree as ET  # noqa: N817
from pathlib import Path
from typing import Dict

import pika


logger = logging.getLogger("warmingup-mpc")

ns = {"fews": "http://www.wldelft.nl/fews", "pi": "http://www.wldelft.nl/fews/PI"}


class AMQPBase:
    EXCHANGE = "mpc_exchange"
    COMMAND_QUEUE = "mpc_command"

    def __init__(self):
        self.host = os.getenv("RABBITMQ_HOST", "localhost")
        self.port = os.getenv("RABBITMQ_PORT", "5672")
        self.user = os.getenv("RABBITMQ_USER", "guest")
        self.password = os.getenv("RABBITMQ_PASSWORD", "guest")
        use_ssl = os.getenv("USE_SSL", "False").lower() == "true"

        logger.debug("Connecting to MPC using AMQP @{}:{}".format(self.host, self.port))

        credentials = pika.PlainCredentials(self.user, self.password)
        conn_params = pika.ConnectionParameters(
            host=self.host, port=int(self.port), credentials=credentials, heartbeat=10
        )

        if use_ssl:
            logger.debug("Using SSL")
            cert_path = Path(__file__).parent / "ssl_certs"
            context = ssl.create_default_context(cafile=cert_path / "ca_certificate.pem")
            context.load_cert_chain(
                cert_path / "client_certificate.pem",
                cert_path / "client_key.pem",
                password="W@rm1ngUp!",
            )
            context.check_hostname = False
            ssl_options = pika.SSLOptions(context, self.host)
            conn_params.ssl_options = ssl_options

        while True:
            try:
                self.connection = pika.BlockingConnection(parameters=conn_params)
            except Exception as e:
                logger.error(
                    f"Unable to connect to RabbitMQ server with error '{str(e)}'.\n"
                    f"Trying again in 5 seconds..."
                )
                time.sleep(5.0)
            else:
                break

        self.channel = self.connection.channel()

        self.channel.exchange_declare(exchange=self.EXCHANGE, exchange_type="topic")
        self.channel.queue_declare(queue=self.COMMAND_QUEUE, exclusive=False)
        self.channel.queue_bind(exchange=self.EXCHANGE, queue=self.COMMAND_QUEUE)

        self.channel.basic_qos(prefetch_count=1)

        logger.debug("Done!")

    @staticmethod
    def _serialize_runinfo(runinfo_path: Path, *additional_paths: Path) -> Dict[str, str]:
        """
        We want to serialize the RunInfo.xml file. To this end, we:
        1. Set pi:workDir to the folder containing the RunInfo file
        2. Relativize file paths in the RunInfo.xml file relative to the workDir
        3. Map (relative) paths to their base64 encoded file contents

        We then return a mapping of the relative file paths (including the
        modified runinfo.xml) to its base-64-encoded contents.

        This way we have a self-containted folder with all files as we are used to
        which should make for easy debugging. It does impose a few constraints on
        what type of RunInfo files we support:

        - All paths in the RunInfo.xml file need to be relative to the folder in
          which it resides.
        - All additional paths/files/folders need to be relative to the same
          RunInfo.xml folder
        - All file paths already need to be relative.
        """

        runinfo_path = runinfo_path.resolve()
        tree = ET.parse(runinfo_path)
        root = tree.getroot()

        base_path = runinfo_path.parent

        # Keep track of what the original workDir was, as we will overwrite it
        # later.
        work_dir = Path(root.findtext("pi:workDir", namespaces=ns))
        if not work_dir.is_absolute():
            work_dir = base_path / work_dir

        b64_file_contents = {}

        def _serialize_path(p: Path):
            if not p.is_absolute():
                p = work_dir / p

            try:
                relative_path = p.relative_to(base_path)
            except ValueError:
                raise ValueError(
                    f"We require paths to be relative to the folder in which RunInfo.xml resides. "
                    f"'{str(p)}' is not relative to '{str(base_path)}'"
                )
            else:
                if not p.exists():
                    # File does not exist (yet)
                    pass
                elif p.is_file():
                    file_contents = open(p, "rb").read()
                    b64_file_contents[str(relative_path)] = base64.b64encode(file_contents).decode(
                        "utf-8"
                    )
                else:
                    for child_path in p.iterdir():
                        _serialize_path(child_path)

                return relative_path

        for item in root:
            if item.text:
                if not item.tag.endswith(("File", "Dir")):
                    continue
                elif item.tag.endswith("workDir"):
                    # Override to make sure relative paths will work correctly.
                    item.text = str(base_path)

                relative_path = _serialize_path(Path(item.text))
                item.text = str(relative_path)

        # The ESDL path is separate
        esdl_node = root.find("pi:properties", ns)[0]
        p = Path(esdl_node.attrib["value"])

        relative_path = _serialize_path(p)
        esdl_node.attrib["value"] = str(relative_path)

        for p in additional_paths:
            if not p.is_absolute():
                raise ValueError(
                    f"Additional paths need to be absolute, and '{str(p)}' is relative."
                )

            _serialize_path(p)

        # Contents of the runinfo file itself
        runinfo_string = ET.tostring(root, xml_declaration=True, encoding="utf-8", method="xml")
        b64_file_contents["runinfo.xml"] = base64.b64encode(runinfo_string).decode("utf-8")

        return b64_file_contents

    @staticmethod
    def _deserialize_runinfo(b64_file_contents: Dict[str, str]) -> tempfile.TemporaryDirectory:
        tmp_dir = tempfile.TemporaryDirectory()

        tmp_dir_path = Path(tmp_dir.name)
        for filename, contents in b64_file_contents.items():
            file_path = tmp_dir_path / filename

            os.makedirs(file_path.parent, exist_ok=True)

            with open(tmp_dir_path / filename, "wb") as o:
                o.write(base64.b64decode(contents.encode("utf-8")))

        return tmp_dir
