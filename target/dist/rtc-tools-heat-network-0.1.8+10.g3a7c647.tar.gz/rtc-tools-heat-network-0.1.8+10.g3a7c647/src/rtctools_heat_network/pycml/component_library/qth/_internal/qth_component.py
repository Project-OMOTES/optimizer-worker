from rtctools_heat_network.pycml import Component


class QTHComponent(Component):
    pass
