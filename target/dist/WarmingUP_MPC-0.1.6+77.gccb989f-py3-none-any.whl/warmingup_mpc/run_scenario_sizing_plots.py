import json

import matplotlib.lines
import numpy as np

import matplotlib.pyplot as plt
from esdl import esdl
from rtctools_heat_network.esdl.esdl_mixin import _esdl_to_assets
from pathlib import Path
import os
from datetime import datetime

import pandas as pd

# workdir = Path(r"C:\Users\rojerj\Documents\Git\RTC-tools\PijnackerNootdorp\model")
workdir = Path(r"C:\Source_codes\WarmingUp\warmingup-mpc\src\warmingup_mpc")

# geo = pd.read_excel(r"C:\Users\rojerj\Documents\Git\RTC-tools\integraal\Beeld2\Information\Geothermie_.xlsx")
geo = pd.read_excel(r"C:\Source_codes\WarmingUp\integraal\Beeld2\Information\Geothermie_.xlsx")
# insu_cost = pd.read_csv(
#         r"C:\Users\rojerj\Documents\Git\RTC-tools\integraal\Beeld2\Information\Renovation_costs_curr.csv")
insu_cost = pd.read_csv(
         r"C:\Source_codes\WarmingUp\integraal\Beeld2\Information\Renovation_costs_curr.csv")

BACKGROUND_IMAGE = r"C:\Source_codes\WarmingUp\integraal\Beeld2\Information\SS_network.PNG"

# esdl_assets, profiles = _esdl_to_assets(r'C:\Users\rojerj\Documents\Git\RTC-tools\PijnackerNootdorp\model\Rondom Ypenburg scenario geen koppeling Bleizo D1_single pipes basis_KPI_double.esdl')
# esdl_assets, profiles = _esdl_to_assets(None, r'C:\Users\rojerj\Documents\Git\RTC-tools\integraal\Beeld2\optimization\model\network_new_adj_incl_GEM_HDemands_2_ATES_source_accurate_inclGEO_double.esdl')
esdl_assets, profiles = _esdl_to_assets(r'C:\Source_codes\WarmingUp\integraal\Beeld2\optimization\model\network_new_adj_incl_GEM_HDemands_2_ATES_source_accurate_inclGEO_double.esdl')
ipnut_path = os.path.join(workdir, "results.json")
with open(ipnut_path) as file:
    results = json.load(file)
ipnut_path = os.path.join(workdir, "parameters.json")
with open(ipnut_path) as file:
    parameters = json.load(file)
ipnut_path = os.path.join(workdir, "bounds.json")
with open(ipnut_path) as file:
    bounds = json.load(file)


a=1

# timesteps = profiles[list(profiles.keys())[0]].index.tz_convert(None).to_pydatetime()
day_steps = parameters["time_step_days"]
max_day = int(parameters["peak_day_index"] * day_steps)
nr_of_days = 365
new_date_times = list()

new_date_times = [datetime.fromtimestamp(x) for x in parameters["times"]]
__indx_max_peak = int(parameters["peak_day_index"])
timesteps = np.asarray([])
for i in range(1,len(new_date_times)):
    timesteps = np.append(timesteps, new_date_times[i].timestamp() - new_date_times[i-1].timestamp())

peak_day_total_demand = None
year_total_demand = None
data_peak = {}
data_year = {}

data_sizing_optimized = {}
data_sizing_static = {}
data_sizing_optimized_capex = {}
data_sizing_static_capex = {}
data_sizing_utilization_static = {}
data_sizing_utilization_optimized = {}
data_opex = {}
data_energy = {}
demands = []

for id, asset in esdl_assets.items():
    if asset.asset_type == "HeatingDemand":
        if not "Heatloss" in asset.name and all(np.asarray(results[f"{asset.name}.Heat_demand"]) > 1.0):
            demands.append(asset.name)
        if year_total_demand is None:
            year_total_demand = np.asarray(results[f"{asset.name}.Heat_demand"])
        else:
            year_total_demand += np.asarray(results[f"{asset.name}.Heat_demand"])
        if peak_day_total_demand is None:
            peak_day_total_demand = np.asarray(results[f"{asset.name}.Heat_demand"][__indx_max_peak:__indx_max_peak+24])
        else:
            peak_day_total_demand += np.asarray(results[f"{asset.name}.Heat_demand"][__indx_max_peak:__indx_max_peak+24])
    elif asset.asset_type in ["HeatProducer", "GenericProducer", "GeothermalSource", "GasHeater", "ResidualHeatSource"]:
        type = asset.asset_type
        if type not in data_year.keys():
            data_year[type] = np.asarray(results[f"{asset.name}.Heat_source"])
            data_energy[type] = np.sum(np.asarray(results[f"{asset.name}.Heat_source"][1:]) * timesteps)
            data_opex[type] = results[f"{asset.name}__fixed_operational_cost"] + results[f"{asset.name}__variable_operational_cost"]

            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] = results[f"{asset.name}__max_size"]
                data_sizing_utilization_optimized[type] = bounds[f"{asset.name}.Heat_source"][1]
                data_sizing_static_capex[type] = 0.
                data_sizing_static[type] = 0.
                data_sizing_utilization_static[type] = 0.
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_optimized_capex[type] = 0.
                data_sizing_optimized[type] = 0.
                data_sizing_utilization_optimized[type] = 0.
                data_sizing_static_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_static[type] = bounds[f"{asset.name}.Heat_source"][1]
                data_sizing_utilization_static[type] = results[f"{asset.name}__max_size"]
        else:
            data_year[type] += np.asarray(results[f"{asset.name}.Heat_source"])
            data_energy[type] += np.sum(np.asarray(results[f"{asset.name}.Heat_source"][1:]) * timesteps)
            data_opex[type] += results[f"{asset.name}__fixed_operational_cost"] + results[f"{asset.name}__variable_operational_cost"]
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] += (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] += results[f"{asset.name}__max_size"]
                data_sizing_utilization_optimized[type] += bounds[f"{asset.name}.Heat_source"][1]
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_static_capex[type] += (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_static[type] += bounds[f"{asset.name}.Heat_source"][1]
                data_sizing_utilization_static[type] += results[f"{asset.name}__max_size"]
        if type not in data_peak.keys():
            data_peak[type] = np.asarray(results[f"{asset.name}.Heat_source"][__indx_max_peak:__indx_max_peak+24])
        else:
            data_peak[type] += np.asarray(results[f"{asset.name}.Heat_source"][__indx_max_peak:__indx_max_peak+24])
    elif asset.asset_type in ["ATES"]:
        type = asset.asset_type
        if type not in data_year.keys():
            data_year[type] = np.asarray(results[f"{asset.name}.Heat_ates"])
            data_energy[type] = np.sum(np.clip(np.asarray(results[f"{asset.name}.Heat_ates"][1:]),0.,np.inf) * timesteps)
            data_opex[type] = results[f"{asset.name}__fixed_operational_cost"] + results[f"{asset.name}__variable_operational_cost"]
            if round(parameters[f"{asset.name}.state"]) == 2:
                data_sizing_optimized_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] = results[f"{asset.name}__max_size"]
                data_sizing_utilization_optimized[type] = bounds[f"{asset.name}.Heat_ates"][1]
                data_sizing_static_capex[type] = 0.
                data_sizing_static[type] = 0.
                data_sizing_utilization_static[type] = 0.
            elif round(parameters[f"{asset.name}.state"]) == 1:
                data_sizing_static_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_static[type] = bounds[f"{asset.name}.Heat_ates"][1]
                data_sizing_utilization_static[type] = results[f"{asset.name}__max_size"]
                data_sizing_optimized_capex[type] = 0.
                data_sizing_optimized[type] = 0.
                data_sizing_utilization_optimized[type] = 0.
        else:
            data_year[type] += np.asarray(results[f"{asset.name}.Heat_ates"])
            data_energy[type] += np.sum(
                np.clip(np.asarray(results[f"{asset.name}.Heat_ates"])[1:], 0., np.inf) * timesteps)
            data_opex[type] += results[f"{asset.name}__fixed_operational_cost"] + results[
                f"{asset.name}__variable_operational_cost"]
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] += (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] += results[f"{asset.name}__max_size"]
                data_sizing_utilization_optimized[type] += bounds[f"{asset.name}.Heat_ates"][1]
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_static_capex[type] += (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_static[type] += bounds[f"{asset.name}.Heat_ates"][1]
                data_sizing_utilization_static[type] += results[f"{asset.name}__max_size"]
        if type not in data_peak.keys():
            data_peak[type] = np.asarray(
                results[f"{asset.name}.Heat_ates"][__indx_max_peak:__indx_max_peak + 24])
        else:
            data_peak[type] += np.asarray(
                results[f"{asset.name}.Heat_ates"][__indx_max_peak:__indx_max_peak + 24])
    elif asset.asset_type in ["HeatStorage"]:
        type = asset.asset_type
        data_opex[type] = 0.
        if type not in data_year.keys():
            data_year[type] = np.asarray(results[f"{asset.name}.Heat_buffer"])
        else:
            data_year[type] += np.asarray(results[f"{asset.name}.Heat_buffer"])
        if type not in data_peak.keys():
            data_peak[type] = np.asarray(
                results[f"{asset.name}.Heat_buffer"][__indx_max_peak:__indx_max_peak + 24])
            if round(parameters[f"{asset.name}.state"]) == 2:
                data_sizing_optimized_capex[type] = (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] = max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
                data_sizing_utilization_optimized[type] = bounds[f"{asset.name}.Heat_buffer"][1]
                data_sizing_static_capex[type] = 0.
                data_sizing_static[type] = 0.
                data_sizing_utilization_static[type] = 0.
            elif round(parameters[f"{asset.name}.state"]) == 1:
                data_sizing_static_capex[type] = (
                            results[f"{asset.name}__investment_cost"] + results[
                        f"{asset.name}__installation_cost"])
                data_sizing_static[type] = bounds[f"{asset.name}.Heat_buffer"][1]
                data_sizing_utilization_static[type] = max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
                data_sizing_optimized_capex[type] = 0.
                data_sizing_optimized[type] = 0.
                data_sizing_utilization_optimized[type] = 0.
        else:
            data_peak[type] += np.asarray(
                results[f"{asset.name}.Heat_buffer"][__indx_max_peak:__indx_max_peak + 24])
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] += (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_optimized[type] += max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
                data_sizing_utilization_optimized[type] += bounds[f"{asset.name}.Heat_buffer"][1]
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_static_capex[type] += (
                        results[f"{asset.name}__investment_cost"] + results[
                    f"{asset.name}__installation_cost"])
                data_sizing_static[type] += bounds[f"{asset.name}.Heat_buffer"][1]
                data_sizing_utilization_static[type] += max(np.asarray(results[f"{asset.name}.Heat_buffer"]))
    elif asset.asset_type in ["Pipe"]:
        type = asset.asset_type
        if "_ret" in asset.name:
            continue
        else:
            pipe_name = asset.name

        if type not in data_opex.keys():
            data_opex[type] = 0.
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] = (
                            results[f"{pipe_name}__investment_cost"] + results[
                        f"{pipe_name}__installation_cost"])
                data_sizing_static_capex[type] = 0.
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_optimized_capex[type] = 0.
                data_sizing_static_capex[type] = (
                            results[f"{pipe_name}__investment_cost"] + results[
                        f"{pipe_name}__installation_cost"])
        else:
            if parameters[f"{asset.name}.state"] == 2:
                data_sizing_optimized_capex[type] += (
                            results[f"{pipe_name}__investment_cost"] + results[
                        f"{pipe_name}__installation_cost"])
            elif parameters[f"{asset.name}.state"] == 1:
                data_sizing_static_capex[type] += (
                            results[f"{pipe_name}__investment_cost"] + results[
                        f"{pipe_name}__installation_cost"])





def plot_year_timeseries(date_times, max_indx, demand, source_data, path):
    new_date_times = np.hstack((date_times[:max_indx + 1], date_times[max_indx + 24:]))
    new_demand = np.hstack((demand[:max_indx], np.mean(demand[max_indx:max_indx+24]), demand[max_indx+24:]))
    plt.figure().set_size_inches(10, 6)
    plt.title("Year")
    plt.plot(new_date_times, new_demand / 1.e6, label="realized demand")
    for key, data in source_data.items():
        new_data = np.hstack((data[:max_indx], np.mean(data[max_indx:max_indx+24]), data[max_indx+24:]))
        plt.plot(new_date_times, new_data / 1.e6, label=key)
    plt.legend()
    plt.ylabel("Power [MW]")
    plt.savefig(path)

def plot_source_mix_per_demand(demands, results, LCOE_regional, insu_cost, path1, path2):
    energy = {}
    cost = {}
    source_types = ["Residual", "Peakprod", "GEO", "HEX"]


    total_energy ={}
    total_cost = {}
    plot_demands = []
    for demand in demands:
        if demand in ["RD_Pendrecht", "RD_MaasstadMC", "RD_Carnisse", "RD_KopVanZuid"]:
            ds = "RotterdamZuid"
            if ds not in plot_demands:
                plot_demands.append(ds)
                total_energy[ds] = 0.
                total_cost[ds] = 0.
        elif demand in ["RD_WSG", "RD_ErasmusMC", "RD_Schiehaven", "RD_Bleekerstraat", "RD_Mariniersweg"]:
            ds = "RotterdamNoord"
            if ds not in plot_demands:
                plot_demands.append(ds)
                total_energy[ds] = 0.
                total_cost[ds] = 0.
        elif demand in ["DH_CRplein", "DH_DenHaag_Z"]:
            ds = "DenHaag"
            if ds not in plot_demands:
                plot_demands.append(ds)
                total_energy[ds] = 0.
                total_cost[ds] = 0.
        else:
            ds = demand
            plot_demands.append(ds)
            total_energy[ds] = 0.
            total_cost[ds] = 0.
        for source in source_types:
            value = (results[f"{source}_{demand}__investment_cost"]
                     + results[f"{source}_{demand}__installation_cost"]
                     + results[f"{source}_{demand}__fixed_operational_cost"] * 30.
                     + results[f"{source}_{demand}__variable_operational_cost"] * 30.)
            total_cost[ds] += value
            if source == "HEX":
                value = np.sum(np.asarray(results[f"{source}_{demand}.Secondary_heat"])[1:] * timesteps / 1.e9)
                total_energy[ds] += value
            elif source == "GEO":
                value = np.sum(
                    np.asarray(results[f"{source}_{demand}.Heat_source"])[1:] * timesteps / 1.e9)
                total_energy[ds] += value
                for x in geo.loc[geo["HD_connec"] == demand]["Naam"]:
                    value = np.sum(
                        np.asarray(results[f"{x}.Heat_source"])[
                        1:] * timesteps / 1.e9)
                    total_energy[ds] += value
                    value = (+ results[f"{source}_{demand}__fixed_operational_cost"] * 30.
                             + results[f"{source}_{demand}__variable_operational_cost"] * 30.)
                    total_cost[ds] += value
            else:
                value = np.sum(np.asarray(results[f"{source}_{demand}.Heat_source"])[1:] * timesteps / 1.e9)
                total_energy[ds]+= value


    cost["insulation"] = [0.] * len(plot_demands)
    for source in source_types:
        roffazuid = True
        roffanoord = True
        denhaag = True
        energy[source] = []
        cost[source] = []
        for demand in demands:
            value = (results[f"{source}_{demand}__investment_cost"]
                     + results[f"{source}_{demand}__installation_cost"]
                     + results[f"{source}_{demand}__fixed_operational_cost"] * 30.
                     + results[f"{source}_{demand}__variable_operational_cost"] * 30.)

            if demand in plot_demands:
                try:
                    cost["insulation"][plot_demands.index(demand)] = (insu_cost[demand].values[0])
                except:
                    pass
                if source == "HEX":
                    energy[source].append(np.sum(np.asarray(results[f"{source}_{demand}.Secondary_heat"])[1:] * timesteps / 1.e9) / total_energy[demand] *100.)
                    value = (LCOE_regional
                             * np.sum(np.asarray(results[f"{source}_{demand}.Secondary_heat"])[1:] * timesteps / 3600.) * 30.)

                elif source == "GEO":
                    energy[source].append(np.sum(np.asarray(results[f"{source}_{demand}.Heat_source"])[1:] * timesteps / 1.e9) / total_energy[demand] * 100.)

                    for x in geo.loc[geo["HD_connec"] == demand]["Naam"]:
                        energy["GEO"][plot_demands.index(demand)] += np.sum(
                            np.asarray(results[f"{x}.Heat_source"])[
                            1:] * timesteps / 1.e9) / total_energy[demand] * 100.
                        value += (results[f"{source}_{demand}__fixed_operational_cost"]
                                 + results[f"{source}_{demand}__variable_operational_cost"])
                else:
                    energy[source].append(np.sum(
                        np.asarray(results[f"{source}_{demand}.Heat_source"])[
                        1:] * timesteps / 1.e9) / total_energy[demand] * 100.)
                cost[source].append(value)
            else:

                if demand in ["RD_Pendrecht", "RD_MaasstadMC", "RD_Carnisse", "RD_KopVanZuid"]:
                    sdd = "RotterdamZuid"
                    if roffazuid:
                        energy[source].append(0.)
                        cost[source].append(0.)
                        cost["insulation"][plot_demands.index(sdd)] += (
                        insu_cost[demand].values[0])
                        roffazuid = False
                elif demand in ["RD_WSG", "RD_ErasmusMC", "RD_Schiehaven", "RD_Bleekerstraat", "RD_Mariniersweg"]:
                    sdd = "RotterdamNoord"
                    if roffanoord:
                        energy[source].append(0.)
                        cost[source].append(0.)
                        cost["insulation"][plot_demands.index(sdd)] += (
                        insu_cost[demand].values[0])
                        roffanoord = False
                elif demand in ["DH_CRplein", "DH_DenHaag_Z"]:
                    sdd = "DenHaag"
                    if denhaag:
                        energy[source].append(0.)
                        cost[source].append(0.)
                        cost["insulation"][plot_demands.index(sdd)] += (
                        insu_cost[demand].values[0])
                        denhaag = False
                value = (results[f"{source}_{demand}__investment_cost"]
                         + results[f"{source}_{demand}__installation_cost"]
                         + results[f"{source}_{demand}__fixed_operational_cost"] * 30.
                         + results[f"{source}_{demand}__variable_operational_cost"] * 30.)

                if source == "HEX":
                    energy[source][plot_demands.index(sdd)]+= np.sum(
                        np.asarray(results[f"{source}_{demand}.Secondary_heat"])[
                        1:] * timesteps / 1.e9) / total_energy[sdd] * 100.
                    value = (LCOE_regional
                             * np.sum(np.asarray(results[f"{source}_{demand}.Secondary_heat"])[
                                      1:] * timesteps / 3600.) * 30.)
                elif source == "GEO":
                    energy[source][plot_demands.index(sdd)]+= np.sum(
                        np.asarray(results[f"{source}_{demand}.Heat_source"])[
                        1:] * timesteps / 1.e9) / total_energy[sdd] * 100.

                    for x in geo.loc[geo["HD_connec"] == demand]["Naam"]:
                        energy["GEO"][plot_demands.index(sdd)] += np.sum(
                            np.asarray(results[f"{x}.Heat_source"])[
                            1:] * timesteps / 1.e9) / total_energy[sdd] * 100.
                        value += (results[f"{source}_{demand}__fixed_operational_cost"] * 30.
                                  + results[f"{source}_{demand}__variable_operational_cost"] * 30.)
                else:
                    energy[source][plot_demands.index(sdd)] += np.sum(
                        np.asarray(results[f"{source}_{demand}.Heat_source"])[
                        1:] * timesteps / 1.e9) / total_energy[sdd] * 100.

                cost[source][plot_demands.index(sdd)] += value

    plt.figure().set_size_inches(10, 6)
    bottom = np.asarray([0.] * len(plot_demands))
    for source in source_types:
        plt.bar(plot_demands, energy[source], 0.25, bottom=bottom, label=source, tick_label=plot_demands)
        bottom += np.asarray(energy[source])
    plt.legend()
    plt.xlabel("Vraag Cluster")
    plt.ylabel("%")
    plt.xticks(rotation=90)
    plt.savefig(path1)

    plt.figure().set_size_inches(10, 6)
    bottom = np.asarray([0.] * len(plot_demands))
    for key, data in cost.items():
        data = np.asarray(data)/1.e6
        plt.bar(plot_demands, data, 0.25, bottom=bottom, label=key,
                tick_label=plot_demands)
        bottom += np.asarray(data)
    plt.legend()
    plt.xlabel("Vraag Cluster")
    plt.ylabel("MEUR")
    plt.xticks(rotation=90)
    plt.savefig(path2)

    return energy, total_energy, plot_demands


regional_sources = ['MV_Petroleumhavens', 'MV_Darcyweg', 'Pernis', 'Vondelingenplaat_NWW', 'Botlek', 'Rozenburg_LoN', 'Rozenburg_NWW']
heat_regional = None
cost_regional = 0.
for source in regional_sources:
    cost_regional += (results[f"{source}__investment_cost"]
             + results[f"{source}__installation_cost"]
             + results[f"{source}__fixed_operational_cost"]
             + results[f"{source}__variable_operational_cost"])
    if heat_regional is None:
        heat_regional = np.asarray(results[f"{source}.Heat_source"])
    else:
        heat_regional += np.asarray(results[f"{source}.Heat_source"])

for pipe, asset in esdl_assets.items():
    if asset.asset_type == "Pipe":
        if asset.attributes["length"] > 25.0:
            if "_ret" in pipe:
                continue
            cost_regional += (results[f"{pipe}__investment_cost"]
                              + results[f"{pipe}__installation_cost"]
                              + results[f"{pipe}__fixed_operational_cost"]
                              + results[f"{pipe}__variable_operational_cost"])

LCOE_regional = cost_regional / np.sum(np.asarray(heat_regional[1:] * timesteps / 3600.) * 30.)

data_year["Regional"] = heat_regional
data_year["ResidualHeatSource"] = data_year["ResidualHeatSource"] - data_year["Regional"]
data_peak["Regional"] = heat_regional[__indx_max_peak:__indx_max_peak+24]
data_peak["ResidualHeatSource"] = data_peak["ResidualHeatSource"] - data_peak["Regional"]

for d in demands:
    realized_demand = results[f"{d}.Heat_demand"]
    target = parameters[f"{d}.target_heat_demand"]
    delta_energy = np.sum((np.asarray(realized_demand) - np.asarray(target))[1:] * timesteps / 1.0e9)
    mismatch = delta_energy / np.sum(np.asarray(target)[1:] * timesteps / 1.0e9) * 100.
    if abs(delta_energy) >= 1.0:
        print(f"For demand {d} the target is not matched by {mismatch} %")

results_path = os.path.join(workdir, "sourcemix.svg")
results_path2 = os.path.join(workdir, "TCOmix.svg")
energy, total_energy, plot_demands = plot_source_mix_per_demand(demands, results, LCOE_regional, insu_cost, results_path, results_path2)
results_path = os.path.join(workdir, "year.svg")
plot_year_timeseries(new_date_times, __indx_max_peak, year_total_demand, data_year, results_path)

def draw_pie(ax, ratios, xpos, ypos, size, colors):
    cumsum = np.cumsum(ratios)
    cumsum = cumsum / cumsum[-1]
    pie = [0] + cumsum.tolist()

    for i, (r1, r2) in enumerate(zip(pie[:-1], pie[1:])):
        angles = np.linspace(2 * np.pi * (-r1 + 0.25), 2 * np.pi * (-r2 + 0.25))
        x = [0] + np.cos(angles).tolist()
        y = [0] + np.sin(angles).tolist()

        xy = np.column_stack([x, y])
        ax.scatter([xpos], [ypos], marker=xy, s=size, color=colors[i])


AGGREGATED_DEMANDS = {
    "RotterdamZuid": ["RD_Pendrecht", "RD_MaasstadMC", "RD_Carnisse", "RD_KopVanZuid"],
    "RotterdamNoord": ["RD_WSG", "RD_ErasmusMC", "RD_Schiehaven", "RD_Bleekerstraat",
                "RD_Mariniersweg"],
    "DenHaag": ["DH_CRplein", "DH_DenHaag_Z"]
}

def get_joint_asset_coords(demand_name, esdl_assets):

    if demand_name in AGGREGATED_DEMANDS:
        xpos = float(np.mean(
            [[a for a in esdl_assets.values() if a.name == "Joint_" + cluster_name][0]
             .attributes["geometry"].lon for cluster_name in AGGREGATED_DEMANDS[demand_name]]
        ))
        ypos = float(np.mean(
            [[a for a in esdl_assets.values() if a.name == "Joint_" + cluster_name][0]
             .attributes["geometry"].lat for cluster_name in AGGREGATED_DEMANDS[demand_name]]
        ))
    else:
        xpos = [a for a in esdl_assets.values() if a.name == "Joint_" + demand_name][0]\
            .attributes["geometry"].lon
        ypos = [a for a in esdl_assets.values() if a.name == "Joint_" + demand_name][0] \
            .attributes["geometry"].lat
    return xpos, ypos

EXTENT = (4.04297, 4.63898, 51.82432, 52.18235)
RATIO = 1 / np.cos((EXTENT[-1] + EXTENT[-2]) / 2 / 360 * 2 * np.pi)

def plot_pie_charts(energy, total_energy, plot_demands, esdl_assets, background_image, path):
    fig, ax = plt.subplots()
    fig.set_size_inches(10 * RATIO, 10)
    im = plt.imread(background_image)
    plt.imshow(im, extent=EXTENT)
    colors = ["red", "blue", "green", "yellow"]
    max_demand = sorted(total_energy.values())[-4]

    for idx, plot_demand in enumerate(plot_demands):
        data = [energy["HEX"][idx], energy["GEO"][idx], energy["Peakprod"][idx], energy["Residual"][idx]]
        total_demand = total_energy[plot_demand]

        xpos, ypos = get_joint_asset_coords(plot_demand, esdl_assets)
        size = min(total_demand / max_demand * 2000, 2000)
        draw_pie(ax, ratios=data, xpos=xpos, ypos=ypos, size=size, colors=colors)

    plt.gca().set_aspect(RATIO)
    lines = [
        matplotlib.lines.Line2D([0], [0], color="red"),
        matplotlib.lines.Line2D([0], [0], color="blue"),
        matplotlib.lines.Line2D([0], [0], color="green"),
        matplotlib.lines.Line2D([0], [0], color="yellow"),
    ]
    plt.legend(lines, ["Regionaal", "Geo", "Peak", "Restwarmte"])
    ax.set_xticks([])
    ax.set_yticks([])
    plt.savefig(path)

results_path = os.path.join(workdir, "pie_chart.svg")
plot_pie_charts(energy, total_energy, plot_demands, esdl_assets, BACKGROUND_IMAGE, results_path)



def plot_peak_timeseries(demand, source_data, path):
    plt.figure().set_size_inches(10, 6)
    plt.title("Peak")
    plt.plot(demand / 1.e6, label="realized demand")
    for key, data in source_data.items():
        plt.plot(data / 1.e6, label=key)
    plt.legend()
    plt.ylabel("Power [MW]")
    plt.savefig(path)
results_path = os.path.join(workdir, "peak.svg")
plot_peak_timeseries(peak_day_total_demand, data_peak, results_path)

a = 1

names = list(data_sizing_static.keys())
plt.figure().set_size_inches(10,6)
plt.title("Asset Sizes")
plt.bar(np.arange(len(data_sizing_utilization_optimized)),
                    np.asarray(list(data_sizing_utilization_optimized.values()))/1.e6,
                    color="g", tick_label=names, width=0.25, label = "Optimization upper bound")
plt.bar(np.arange(len(data_sizing_optimized)), np.asarray(list(data_sizing_optimized.values()))/1.e6, color="b", alpha=.5, hatch='/', tick_label=names, width=0.25, label="Optimized")
plt.bar(np.arange(len(data_sizing_static))+ 0.25, np.asarray(list(data_sizing_static.values()))/1.e6, color="g", tick_label=names, width=0.25, label="Existing capacity")
plt.bar(np.arange(len(data_sizing_utilization_static)) + 0.25,
        np.asarray(list(data_sizing_utilization_static.values()))/1.e6,
        color="r", tick_label=names, alpha=.5, hatch='/', width=0.25, label="Power utilized")
plt.legend()
plt.ylabel("Size [MW]")
results_path = os.path.join(workdir, "sizes.svg")
plt.savefig(results_path)

names = list(data_opex.keys())
plt.figure().set_size_inches(10,6)
plt.title("Asset OPEX")
plt.bar(np.arange(len(data_opex)),
        np.asarray(list(data_opex.values()))/1.e6,
        color="b", tick_label=names, width=0.25)
plt.legend()
plt.ylabel("OPEX [M€]")
results_path = os.path.join(workdir, "opex.svg")
plt.savefig(results_path)

names = list(data_energy.keys())
plt.figure().set_size_inches(10,6)
plt.title("Asset energy")
plt.bar(np.arange(len(data_energy)),
        np.asarray(list(data_energy.values()))/1.e15,
        color="b", tick_label=names, width=0.25)
plt.legend()
plt.ylabel("Energy [PJ]")
results_path = os.path.join(workdir, "energy.svg")
plt.savefig(results_path)

names = list(data_sizing_static_capex.keys())
plt.figure().set_size_inches(10,6)
plt.title("Asset CAPEX")
plt.bar(np.arange(len(data_sizing_optimized_capex)), np.asarray(list(data_sizing_optimized_capex.values()))/1.e6,
        color="b", tick_label=names, width=0.25, label="Optimized")
plt.bar(np.arange(len(data_sizing_static_capex)) + 0.25, np.asarray(list(data_sizing_static_capex.values()))/1.e6,
        color="g", tick_label=names, width=0.25, label="existing")
plt.legend()
plt.ylabel("CAPEX [M€]")
results_path = os.path.join(workdir, "capex.svg")
plt.savefig(results_path)

TCO = 0.
energy = 0.
years = parameters["number_of_years"]
for key, value in data_energy.items():
    if key != "ATES":
        energy += value / 1.e9 * years
for key, value in data_opex.items():
    TCO += value * years
for key, value in data_sizing_static_capex.items():
    TCO += value
for key, value in data_sizing_optimized_capex.items():
    TCO += value
for key, value in insu_cost.items():
    TCO += value[0]

LCOE = TCO / energy


plt.figure().set_size_inches(10, 6)
plt.title("TCO breakdown")
names = list(data_opex.keys())
plt.bar(np.arange(len(data_opex)),
        np.fromiter(data_opex.values(), dtype=float) * years / 1.e6,
        color="b", tick_label=names, width=0.25, label="opex")
plt.bar(np.arange(len(data_sizing_static_capex)) + 0.25,
        list((np.fromiter(data_sizing_static_capex.values(), dtype=float) + np.fromiter(
            data_sizing_optimized_capex.values(), dtype=float)) / 1.e6),
        color="g", tick_label=names, width=0.25, label="capex")
max_value = max(np.max(np.fromiter(data_sizing_static_capex.values(), dtype=float) + np.fromiter(
    data_sizing_optimized_capex.values(), dtype=float)) / 1.e6, np.max(np.fromiter(data_opex.values(), dtype=float)/ 1.e6) )
plt.text(0.65 * len(data_opex), 0.85 * max_value, f"LCOE [€/GJ]: {round(LCOE, 2)}", fontsize=14,
         verticalalignment='top')
# plt.text(0.65 * len(data_opex), 0.9 * max_value, f"Emission [kg/GJ]: {round(CO2_per_kg, 2)}",
#          fontsize=14,
#          verticalalignment='top')
plt.legend()
plt.ylabel("M€")
results_path = os.path.join(workdir, "tco.svg")
plt.savefig(results_path)

# plt.show()


## Here we make the regional results
# opex = 0.
# capex = 0.
#
# regional_sources = ['MV_Petroleumhavens', 'MV_Darcyweg', 'Pernis', 'Vondelingenplaat_NWW', 'Botlek', 'Rozenburg_LoN', 'Rozenburg_NWW']
# energy = 0.
# heat_regional = None
# for source in regional_sources:
#     if heat_regional is None:
#         heat_regional = np.asarray(results[f"{source}.Heat_source"])
#     else:
#         heat_regional += np.asarray(results[f"{source}.Heat_source"])
#     opex += results[f"{source}__variable_operational_cost"] + results[f"{source}__fixed_operational_cost"]
#     capex += results[f"{source}__investment_cost"] + results[f"{source}__installation_cost"]
#     energy += np.sum(np.asarray(results[f"{source}.Heat_source"][1:]) * timesteps)
#
#
# capex_pipe_optimized = 0.
#
# for pipe, asset in esdl_assets.items():
#     if asset.asset_type == "Pipe":
#         if "_ret" in asset.name:
#             pipe_name = asset.name[:-4]
#         else:
#             pipe_name = asset.name
#         if "Prim" in asset.global_properties["carriers"][asset.in_ports[0].carrier.id]["name"]:
#             capex += results[f"{pipe_name}__investment_cost"] + results[f"{pipe_name}__installation_cost"]
#         try:
#             results[f"{pipe_name}__hn_pipe_class_DN150"]
#             capex_pipe_optimized += results[f"{pipe_name}__investment_cost"] + results[
#                 f"{pipe_name}__installation_cost"]
#         except:
#             capex_pipe_optimized += 0.
#
# energy = energy / 1.e9
# regional_tco = capex + opex * years
# regional_lcoe = regional_tco / (energy * years)
#
#
# ## Here we make the local results
# asset_types = ["Residual", "Peakprod", "GEO", "ATES"]
#
# local_lcoe = {}
# local_tco = {}
#
# data_sizing_optimized = {}
# data_sizing_static = {}
# data_sizing_optimized_capex = {}
# data_sizing_static_capex = {}
# data_sizing_utilization_static = {}
# data_sizing_utilization_optimized = {}
# data_opex = {}
# data_energy = {}
# local_energy = {}
# data_peak = {}
# data_year = {}
#
# for demand in demands:
#     data_peak[demand] = {}
#     data_year[demand] = {}
#
#     data_sizing_optimized[demand] = {}
#     data_sizing_static[demand] = {}
#     data_sizing_optimized_capex[demand] = {}
#     data_sizing_static_capex[demand] = {}
#     data_sizing_utilization_static[demand] = {}
#     data_sizing_utilization_optimized[demand] = {}
#     data_opex[demand] = {}
#     data_energy[demand] = {}
#     data_energy[demand]["HEX"] = np.sum(np.asarray(results[f"HEX_{demand}.Secondary_heat"][1:]) * timesteps)
#     data_opex[demand]["HEX"] = data_energy[demand]["HEX"] / 1.e9 * regional_lcoe
#     data_year[demand]["WL"] = np.asarray(results[f"HEX_{demand}.Secondary_heat"])
#     data_peak[demand]["WL"] = np.asarray(
#         results[f"HEX_{demand}.Secondary_heat"][__indx_max_peak:__indx_max_peak + 24])
#     for type in asset_types:
#         try:
#             data_year[demand][type] = np.asarray(results[f"{type}_{demand}.Heat_source"])
#             data_peak[demand][type] = np.asarray(results[f"{type}_{demand}.Heat_source"][__indx_max_peak:__indx_max_peak + 24])
#         except:
#             data_year[demand][type] = np.asarray(results[f"{type}_{demand}.Heat_ates"])
#             data_peak[demand][type] = np.asarray(
#                 results[f"{type}_{demand}.Heat_ates"][__indx_max_peak:__indx_max_peak + 24])
#         try:
#             data_opex[demand][type] = results[f"{type}_{demand}__variable_operational_cost"] + results[f"{type}_{demand}__fixed_operational_cost"]
#         except:
#             try:
#                 data_opex[demand][type] += results[f"{type}_{demand}__variable_operational_cost"]
#             except:
#                 data_opex[demand][type] += 0.
#         try:
#             data_energy[demand][type] = np.sum(np.asarray(results[f"{type}_{demand}.Heat_source"][1:]) * timesteps)
#         except:
#             data_energy[demand][type] = 0.
#         try:
#             results[f"{type}_{demand}__placed"]
#             data_sizing_utilization_optimized[demand][type] = results[f"{type}_{demand}__max_size"]
#             data_sizing_utilization_static[demand][type] = 0.
#             if type == "ATES":
#                 data_sizing_optimized[demand][type] = bounds[f"{type}_{demand}.Heat_ates"][1]
#             elif type == "HeatStorage":
#                 data_sizing_optimized[demand][type] = bounds[f"{type}_{demand}.Heat_buffer"][1]
#             else:
#                 data_sizing_optimized[demand][type] = bounds[f"{type}_{demand}.Heat_source"][1]
#             data_sizing_optimized_capex[demand][type] = results[f"{type}_{demand}__investment_cost"] + results[f"{type}_{demand}__installation_cost"]
#             data_sizing_static_capex[demand][type] = 0.
#             data_sizing_static[demand][type] = 0.
#         except:
#             data_sizing_optimized[demand][type] = 0.
#             data_sizing_optimized_capex[demand][type] = 0.
#             data_sizing_static_capex[demand][type] = results[f"{type}_{demand}__investment_cost"] + \
#                                                 results[f"{type}_{demand}__installation_cost"]
#             data_sizing_utilization_static[demand][type] = results[f"{type}_{demand}__max_size"]
#             data_sizing_utilization_optimized[demand][type] = 0.
#             if type == "ATES":
#                 data_sizing_static[demand][type] = bounds[f"{type}_{demand}.Heat_ates"][1]
#             elif type == "HeatStorage":
#                 data_sizing_static[demand][type] = bounds[f"{type}_{demand}.Heat_buffer"][1]
#             else:
#                 data_sizing_static[demand][type] = bounds[f"{type}_{demand}.Heat_source"][1]
#     year_total_demand = np.asarray(results[f"{demand}.Heat_demand"])
#     peak_day_total_demand = np.asarray(
#             results[f"{demand}.Heat_demand"][__indx_max_peak:__indx_max_peak + 24])
#     if demand == "Rijswijk":
#         results_path = os.path.join(workdir, f"{demand}_year.svg")
#         plot_year_timeseries(new_date_times, year_total_demand, data_year[demand] , results_path)
#         results_path = os.path.join(workdir, f"{demand}_peak.svg")
#         plot_peak_timeseries(peak_day_total_demand, data_peak[demand] , results_path)
#
#     local_tco[demand] = 0.
#     local_energy[demand] = 0.
#     years = parameters["number_of_years"]
#     for key, value in data_energy[demand].items():
#         if key != "ATES" and np.sum(np.asarray(results[f"{demand}.Heat_demand"])) > 1.:
#             local_energy[demand] += value / 1.e9 * years
#     for key, value in data_opex[demand].items():
#         local_tco[demand] += value * years
#     for key, value in data_sizing_static_capex[demand].items():
#         local_tco[demand] += value
#     for key, value in data_sizing_optimized_capex[demand].items():
#         local_tco[demand] += value
#
#     if local_energy[demand] > 0.:
#         local_lcoe[demand] = local_tco[demand] / local_energy[demand]
#     else:
#         local_lcoe[demand] = 0.
#     print(f"{demand}: {local_lcoe[demand]}")
#     a=1
#
#
#
#
# # make plot of sizing per demand
#
# # make plot of TCO breakdown per demand
#
# # Make plot of LCOE for all demands
#
# plt.figure().set_size_inches(20, 9)
# plt.title("LCOE division")
# names = list(local_lcoe.keys())
# plt.bar(np.arange(len(local_lcoe)),
#         np.fromiter(local_lcoe.values(), dtype=float),
#         color="b", tick_label=names, width=0.25)
# plt.ylabel("€/GJ")
# results_path = os.path.join(workdir, "LCOE.svg")
# plt.xticks(rotation=45)
# plt.xticks(fontsize=8)
# plt.savefig(results_path)
# # plt.show()
#
# a=1
# # for key, value in results.items():
