from esdl.esdl import Asset, TimeUnitEnum, UnitEnum

from rtctools.optimization.single_pass_goal_programming_mixin import Goal

from rtctools_heat_network.heat_mixin import HeatMixin

from warmingup_mpc._helpers import get_cost_value_and_unit


HEAT_STORAGE_M3_WATER_PER_DEGREE_CELCIUS = 4200 * 998
WATTHOUR_TO_JOULE = 3600


class MinimizeCAPEX(Goal):
    order = 1

    def __init__(
        self,
        max_source_heat_vars,
        source_placement_vars,
        max_buffer_heat_vars,
        buffer_placement_vars,
        priority=None,
    ):
        self.priority = priority
        self.max_source_heat_vars = max_source_heat_vars
        self.source_placement_vars = source_placement_vars
        self.max_buffer_heat_vars = max_buffer_heat_vars
        self.buffer_placement_vars = buffer_placement_vars

    def function(self, optimization_problem: HeatMixin, ensemble_member):
        obj = 0.0
        obj += self.capex_pipes(optimization_problem, ensemble_member)
        obj += self.capex_sources(optimization_problem, ensemble_member)
        # Stage 1 is only one timestep therefore buffers cannot be sized and thus are excluded
        # for the costs
        if optimization_problem._stage > 1:
            obj += self.capex_buffers(optimization_problem, ensemble_member)

        return obj

    def capex_pipes(self, optimization_problem: HeatMixin, ensemble_member):
        obj = 0.0
        parameters = optimization_problem.parameters(ensemble_member)

        for p in optimization_problem.hot_pipes:
            pipe_classes = optimization_problem.pipe_classes(p)
            if len(pipe_classes) == 0 or len({pc.inner_diameter for pc in pipe_classes}) == 1:
                # Nothing to optimize for this pipe
                continue

            length = parameters[f"{p}.length"]
            var_name = optimization_problem.pipe_cost_symbol_name(p)

            obj += optimization_problem.extra_variable(var_name, ensemble_member) * length * 2.0
        return obj / 10**6

    def capex_buffers(self, optimization_problem, ensemble_member):
        obj = 0.0

        for var_name in self.max_buffer_heat_vars:
            asset_name = var_name.split("__")[0]
            asset = optimization_problem.get_asset_from_asset_name(asset_name)
            if asset.asset_type == "ATES":
                continue
            investment_costs = get_investment_costs(asset, UnitEnum.JOULE)
            opt_var = optimization_problem.extra_variable(var_name, ensemble_member)
            obj += opt_var * investment_costs

        for placement_var_name in self.buffer_placement_vars:
            asset_name = placement_var_name.split("__")[0]
            asset = optimization_problem.get_asset_from_asset_name(asset_name)
            if asset.asset_type == "ATES":
                installation_costs = get_installation_costs(asset)  # costs per doublet
                opt_var = optimization_problem.extra_variable(
                    f"{asset_name}__number_of_doublets", ensemble_member
                )
            else:
                installation_costs = get_installation_costs(asset)
                opt_var = optimization_problem.extra_variable(placement_var_name, ensemble_member)
            obj += opt_var * installation_costs

        return obj / 10**6

    def capex_sources(self, optimization_problem, ensemble_member):
        obj = 0.0
        parameters = optimization_problem.parameters(ensemble_member)

        for var_name in self.max_source_heat_vars:
            asset_name = var_name.split("__")[0]
            asset = optimization_problem.get_asset_from_asset_name(asset_name)
            investment_costs = get_investment_costs(asset, UnitEnum.WATT)
            if asset.asset_type == "GeothermalSource":
                opt_var = optimization_problem.extra_variable(
                    optimization_problem._geo_wells_map[asset_name], ensemble_member
                )
                single_well_power = parameters[f"{asset_name}.single_doublet_power"]
                obj += opt_var * investment_costs * single_well_power
            else:
                opt_var = optimization_problem.extra_variable(var_name, ensemble_member)
                obj += opt_var * investment_costs

        for var_name in self.source_placement_vars:
            asset_name = var_name.split("__")[0]
            asset = optimization_problem.get_asset_from_asset_name(asset_name)
            installation_costs = get_installation_costs(asset)
            opt_var = optimization_problem.extra_variable(var_name, ensemble_member)
            obj += opt_var * installation_costs

        return obj / 10**6

def get_installation_costs(asset: Asset):
    cost_info = asset.attributes["costInformation"].installationCosts
    if cost_info is None:
        RuntimeWarning(f"No installation cost info provided for asset " f"{asset.name}.")
        return 0.
    cost_value, unit, per_unit, per_time = get_cost_value_and_unit(cost_info)
    if unit != UnitEnum.EURO:
        raise RuntimeError(
            f"Expect cost information {cost_info} to " f"provide a cost in euros"
        )
    if not per_time == TimeUnitEnum.NONE:
        raise RuntimeError(
            f"Specified installation costs of asset {asset.name}"
            f" include a component per time, which we "
            f"cannot handle."
        )
    if not per_unit == UnitEnum.NONE:
        raise RuntimeError(
            f"Specified installation costs of asset {asset.name}"
            f" include a component per unit {per_unit}, which we "
            f"cannot handle."
        )
    return cost_value

def get_investment_costs(asset: Asset, per_unit: UnitEnum = UnitEnum.WATT):
    """
    Returns the investment costs of an asset in Euros per W.
    """
    cost_info = asset.attributes["costInformation"].investmentCosts
    if cost_info is None:
        RuntimeWarning(f"No investment costs provided for asset " f"{asset.name}.")
        return 0.
    cost_value, unit_provided, per_unit_provided, per_time_provided = get_cost_value_and_unit(
        cost_info
    )
    if unit_provided != UnitEnum.EURO:
        raise RuntimeError(
            f"Expect cost information {cost_info} to " f"provide a cost in euros"
        )
    if not per_time_provided == TimeUnitEnum.NONE:
        raise RuntimeError(
            f"Specified investment costs for asset {asset.name}"
            f" include a component per time, which we "
            f"cannot handle."
        )
    if per_unit == UnitEnum.WATT:
        if not per_unit_provided == UnitEnum.WATT:
            raise RuntimeError(
                f"Expected the specified investment costs "
                f"of asset {asset.name} to be per W, but they "
                f"are provided in {per_unit_provided} "
                f"instead."
            )
        return cost_value
    elif per_unit == UnitEnum.WATTHOUR:
        if not per_unit_provided == UnitEnum.WATTHOUR:
            raise RuntimeError(
                f"Expected the specified investment costs "
                f"of asset {asset.name} to be per Wh, but they "
                f"are provided in {per_unit_provided} "
                f"instead."
            )
        return cost_value
    elif per_unit == UnitEnum.METRE:
        return cost_value
    elif per_unit == UnitEnum.JOULE:
        if per_unit_provided == UnitEnum.WATTHOUR:
            return cost_value / WATTHOUR_TO_JOULE
        elif per_unit_provided == UnitEnum.CUBIC_METRE:
            # index is 0 because buffers only have one in out port
            supply_temp = asset.global_properties["carriers"][asset.in_ports[0].carrier.id][
                "supplyTemperature"
            ]
            return_temp = asset.global_properties["carriers"][asset.in_ports[0].carrier.id][
                "returnTemperature"
            ]
            delta_temp = supply_temp - return_temp
            m3_to_joule_factor = delta_temp * HEAT_STORAGE_M3_WATER_PER_DEGREE_CELCIUS
            return cost_value / m3_to_joule_factor
        else:
            raise RuntimeError(
                f"Expected the specified investment costs "
                f"of asset {asset.name} to be per Wh or m3, but "
                f"they are provided in {per_unit_provided} "
                f"instead."
            )
    else:
        raise RuntimeError(
            f"Cannot provide investment costs for asset " f"{asset.name} per {per_unit}"
        )
