import json
import logging
import math
import os
import time
import xml.etree.ElementTree as ET  # noqa: N817
from pathlib import Path

import casadi as ca

import esdl

import matplotlib.pyplot as plt

import numpy as np

import pandas as pd

from rtctools._internal.alias_tools import AliasDict
from rtctools.optimization.collocated_integrated_optimization_problem import (
    CollocatedIntegratedOptimizationProblem,
)
from rtctools.optimization.linearized_order_goal_programming_mixin import (
    LinearizedOrderGoalProgrammingMixin,
)
from rtctools.optimization.single_pass_goal_programming_mixin import (
    CachingQPSol,
    SinglePassGoalProgrammingMixin,
)
from rtctools.util import run_optimization_problem

from rtctools_heat_network._heat_loss_u_values_pipe import heat_loss_u_values_pipe
from rtctools_heat_network.esdl.asset_to_component_base import _AssetToComponentBase
from rtctools_heat_network.esdl.edr_pipe_class import EDRPipeClass
from rtctools_heat_network.esdl.esdl_mixin import ESDLMixin
from rtctools_heat_network.head_loss_mixin import HeadLossOption
from rtctools_heat_network.heat_mixin import HeatMixin
from rtctools_heat_network.pipe_class import PipeClass

from warmingup_mpc._helpers import _main_decorator
from warmingup_mpc.minimize_capex_goal import MinimizeCAPEX
from warmingup_mpc.minimize_opex_daily_goal import MinimizeOPEXDaily
from warmingup_mpc.minimize_opex_goal import MinimizeOPEX
from warmingup_mpc.write_output import ScenarioOutput


logger = logging.getLogger("WarmingUP-MPC")
logger.setLevel(logging.INFO)


ns = {"fews": "http://www.wldelft.nl/fews", "pi": "http://www.wldelft.nl/fews/PI"}

WATT_TO_MEGA_WATT = 1.0e6
WATT_TO_KILO_WATT = 1.0e3


class CFOptions(ESDLMixin):
    def __init__(self, *args, esdl_run_info_path, **kwargs):
        self.esdl_run_info_path = esdl_run_info_path

        self._cf_override_hn_options = {}
        self._cf_override_return_temperature = None
        self._cf_override_supply_temperature = None

        self._cf_source_priority_map = {}
        self._cf_override_max_power = {}
        self._cf_override_number_of_units = {}

        self._cf_max_placed_buffers = None
        self._cf_minimize_size_buffers = []
        self._cf_override_buffer_size = {}
        self._cf_optional_buffers = []

        self._cf_minimize_size_sources = []
        self._cf_optional_sources = []
        self._cf_setpoint_constraints_sources = []

        self._cf_override_ates_efficiency = {}
        self._cf_override_installationcosts_perdoublet_ates = {}
        self._cf_optional_ates = []
        self._cf_minimize_size_ates = []

        self._cf_override_pipe_classes = {}

        self._cf_objective = None

        self._cf_output_folder = None

        self._source_profiles_year = {}

        # FIXME: Workaround CF UI bug where <inputParameterFile> is always
        #  present. This will trip up ESDLMixin when it tries to interpret it,
        #  so we remove that line.
        runinfo_path = Path(self.esdl_run_info_path).resolve()
        tree = ET.parse(runinfo_path)
        root = tree.getroot()

        xml_input_parameter_files = root.findall("pi:inputParameterFile", namespaces=ns)
        for f in xml_input_parameter_files:
            root.remove(f)

        work_dir = Path(root.findtext("pi:workDir", namespaces=ns))
        if not work_dir.is_absolute():
            work_dir = runinfo_path.parent / work_dir

        # Get the output folder to store the HTML results in
        output_ref_path = root.findtext("pi:outputTimeSeriesFile", namespaces=ns)
        if output_ref_path is None:
            output_ref_path = self.esdl_run_info_path

        self._cf_html_output_dir = Path(output_ref_path).parent
        if not Path(self._cf_html_output_dir).is_absolute():
            self._cf_html_output_dir = work_dir / self._cf_html_output_dir

        # Now we parse all the options and overrides in the CSV files, and
        # store them as internal variables to be used by the optimization
        # problem class.
        csv_input_parameter_files = root.findall("pi:inputLocationAttributeCsvFile", namespaces=ns)

        csv_input_global_constraints = None
        csv_input_global_goal = None
        csv_input_producers = None
        csv_input_ates = None
        csv_input_storages = None
        csv_input_pipes = None
        csv_input_daily_demands = None
        csv_input_daily_source_profiles = None

        self._cf_csv_input_parameter_files = []

        for node in csv_input_parameter_files:
            f = node.text
            if not Path(f).is_absolute():
                f = str(work_dir / f)
            self._cf_csv_input_parameter_files.append(f)

            # Figure out what CSV file it is, and parse it accordingly
            if f.endswith("mpc_global_constraints.csv"):
                csv_input_global_constraints = f
            elif f.endswith("mpc_global_goal.csv"):
                csv_input_global_goal = f
            elif f.endswith("mpc_producers.csv"):
                csv_input_producers = f
            elif f.endswith("mpc_storages.csv"):
                csv_input_storages = f
            elif f.endswith("mpc_ates.csv"):
                csv_input_ates = f
            elif f.endswith("mpc_pipes.csv"):
                csv_input_pipes = f
            elif f.endswith("daily_avg_demands.csv"):
                csv_input_daily_demands = f
            elif f.endswith("daily_source_profiles.csv"):
                csv_input_daily_source_profiles = f
            elif f.endswith("nodes_kpi_factors.csv"):
                pass
            else:
                logger.info(f"Unknown input parameters file '{f}'")

        # Global options/constraints
        for option, is_active, value in pd.read_csv(
            csv_input_global_constraints, index_col=0
        ).itertuples(name=None):
            if not is_active:
                continue

            if option == "absolutePressure_min":
                self._cf_override_hn_options["pipe_minimum_pressure"] = float(value)
            if option == "absolutePressure_max":
                self._cf_override_hn_options["pipe_maximum_pressure"] = float(value)
            if option == "consumerPressureDrop":
                self._cf_override_hn_options["minimum_pressure_far_point"] = float(value)
            if option == "maxPlacedBuffers":
                self._cf_max_placed_buffers = int(value)
            if option == "returnTemperature":
                self._cf_override_return_temperature = float(value)
            if option == "supplyTemperature":
                self._cf_override_supply_temperature = float(value)
            if option == "velocity_max":
                self._cf_override_hn_options["maximum_velocity"] = float(value)
            if option == "no_head_loss":
                if value:
                    self._cf_override_hn_options["head_loss_option"] = HeadLossOption.NO_HEADLOSS
                    logger.warning(
                        "No head loss constraints are applied dimensioning of pipes is not logical"
                    )

        # Global goal
        self._cf_objective = pd.read_csv(csv_input_global_goal, index_col=0).index[0]

        # Source/producers options
        for s, options in pd.read_csv(csv_input_producers, index_col=0).to_dict("index").items():
            self._cf_override_number_of_units[s] = options["numberOfUnits"]
            self._cf_override_max_power[s] = options["maxPower"]
            if options["tuneSize"]:
                self._cf_minimize_size_sources.append(s)
                self._cf_optional_sources.append(s)
            if options["constantSupply"]:
                self._cf_setpoint_constraints_sources.append(s)

        # ATES options
        for ates, options in pd.read_csv(csv_input_ates, index_col=0).to_dict("index").items():
            self._cf_override_number_of_units[ates] = options["numberOfUnits"]
            self._cf_override_max_power[ates] = options["maxPower"]
            self._cf_override_ates_efficiency[ates] = options["efficiency"]
            self._cf_override_installationcosts_perdoublet_ates[ates] = options[
                "installationCostsPerDoublet"
            ]
            if options["tuneSize"]:
                self._cf_optional_ates.append(ates)
                self._cf_minimize_size_ates.append(ates)

        # Buffer/storage options
        for b, options in pd.read_csv(csv_input_storages, index_col=0).to_dict("index").items():
            assert not np.isnan(options["maxVolume"])

            self._cf_override_buffer_size[b] = options["maxVolume"]

            if options["tuneSize"]:
                self._cf_minimize_size_buffers.append(b)
                self._cf_optional_buffers.append(b)

        # Pipe classes
        maximum_velocity = self._cf_override_hn_options["maximum_velocity"]

        no_pipe_class = PipeClass("None", 0.0, 0.0, (0.0, 0.0), 0.0)
        pipe_classes = [
            EDRPipeClass.from_edr_class(name, edr_class_name, maximum_velocity)
            for name, edr_class_name in _AssetToComponentBase.STEEL_S1_PIPE_EDR_ASSETS.items()
        ]

        # We assert the pipe classes are monotonically increasing in size
        assert np.all(np.diff([pc.inner_diameter for pc in pipe_classes]) > 0)

        for p, options in pd.read_csv(csv_input_pipes, index_col=0).to_dict("index").items():
            if self.is_cold_pipe(p):
                continue

            if options["optimizePipeSize"]:
                c = self._cf_override_pipe_classes[p] = []

                if options["optimizePipeRouting"]:
                    c.append(no_pipe_class)

                min_size = options["pipeDiameterMin"]
                max_size = options["pipeDiameterMax"]

                indices = sorted(
                    [i for i, pc in enumerate(pipe_classes) if pc.name in {min_size, max_size}]
                )
                c.extend(pipe_classes[indices[0] : indices[1]])
            else:
                if options["optimizePipeRouting"]:
                    # Note: we will resolve the "existing pipe class" _after_
                    # the super().__init__() statement when  the ESDLMixin has
                    # parsed and converted the assets to a PyCML model.
                    self._cf_override_pipe_classes[p] = [no_pipe_class, "existing pipe class"]

        profile_year = pd.read_csv(csv_input_daily_demands)
        self._daily_avg_demands = (
            profile_year.loc[:, profile_year.columns != "time"]
            .sum(axis=1, numeric_only=True)
            .to_numpy()
        )

        if csv_input_daily_source_profiles is not None:
            self._source_profiles_year = pd.read_csv(csv_input_daily_source_profiles)

        super().__init__(*args, esdl_run_info_path=esdl_run_info_path, **kwargs)

        # Replace "existing pipe class" with the actual existing pipe class
        assets = self.esdl_assets
        for p, pipe_classes in self._cf_override_pipe_classes.items():
            if "existing pipe class" in pipe_classes:
                assert len(pipe_classes) == 2
                assert pipe_classes[0] == no_pipe_class

                asset = next(a for a in assets.values() if a.name == p)

                # Insulation properties
                material = asset.attributes["material"]
                # NaN means the default values will be used
                insulation_thicknesses = math.nan
                conductivies_insulation = math.nan

                if material is not None:
                    if isinstance(material, esdl.esdl.MatterReference):
                        material = material.reference

                    assert isinstance(material, esdl.esdl.CompoundMatter)
                    components = material.component.items
                    if components:
                        insulation_thicknesses = [x.layerWidth for x in components]
                        conductivies_insulation = [x.matter.thermalConductivity for x in components]

                diameter = asset.attributes["innerDiameter"]
                u_kwargs = {
                    "inner_diameter": diameter,
                    "insulation_thicknesses": insulation_thicknesses,
                    "conductivities_insulation": conductivies_insulation,
                }

                # NaN values mean we use the function default
                u_kwargs = {k: v for k, v in u_kwargs.items() if not np.all(np.isnan(v))}

                pipe_classes[1] = PipeClass(
                    f"{asset.name}_orig",
                    diameter,
                    maximum_velocity,
                    heat_loss_u_values_pipe(**u_kwargs),
                )

    def esdl_heat_model_options(self):
        """Overwrites the fraction of the minimum tank volume"""
        options = super().esdl_heat_model_options()
        options["min_fraction_tank_volume"] = 0.0
        return options

    @property
    def esdl_assets(self):
        assets = super().esdl_assets

        # Override buffer sizes
        for b, size in self._cf_override_buffer_size.items():
            asset = next(a for a in assets.values() if a.name == b)
            asset.attributes["volume"] = size

        # Override source maxPower, CF gives power in kW
        for s, max_power in self._cf_override_max_power.items():
            asset = next(a for a in assets.values() if a.name == s)
            asset.attributes["power"] = max_power * 1.0e3 * self._cf_override_number_of_units[s]
            if asset.asset_type == "GeothermalSource":
                asset.attributes["single_doublet_power"] = max_power * 1.0e3
            if asset.asset_type == "ATES":
                asset.attributes["single_doublet_power"] = max_power * 1.0e3
                asset.attributes["efficiency"] = self._cf_override_ates_efficiency[s]
                instalcosts = asset.attributes["costInformation"].installationCosts
                instalcosts.value = float(self._cf_override_installationcosts_perdoublet_ates[s])
                instalcosts.profileQuantityAndUnit.unit = esdl.UnitEnum.from_string("EURO")
                instalcosts.profileQuantityAndUnit.multiplier = esdl.MultiplierEnum.from_string(
                    "NONE"
                )
                instalcosts.profileQuantityAndUnit.perUnit = esdl.UnitEnum.from_string("NONE")
                # instalcosts.profileQuantityAndUnit.perTime = esdl.UnitEnum.from_string('NONE')
                instalcosts.profileQuantityAndUnit.description = "Cost in EURO"

        # Override supply/return temperature
        for a in assets.values():
            for c in a.global_properties["carriers"].values():
                c["supplyTemperature"] = self._cf_override_supply_temperature
                c["returnTemperature"] = self._cf_override_return_temperature

        return assets

    def heat_network_options(self):
        options = super().heat_network_options()
        options.update(self._cf_override_hn_options)
        return options

    def pipe_classes(self, p):
        return self._cf_override_pipe_classes.get(p, [])

    def read(self):
        super().read()

        # Workaround for CF not always forcing the system time (=forecast
        # datetime) to be within the start - end datetime range.
        datetimes = self.io.datetimes
        ref_datetime = self.io.reference_datetime

        if ref_datetime < datetimes[0]:
            logger.info(
                f"Reference datetime '{ref_datetime}' before earliest data point '{datetimes[0]}'. "
                f"Setting reference datetime to '{datetimes[0]}'."
            )
            self.io.reference_datetime = datetimes[0]
            self._ESDLMixin__timeseries_import.forecast_datetime = datetimes[0]

    def pre(self):
        super().pre()
        for s in self._cf_setpoint_constraints_sources:
            # Here we enforce that over the full time horizon no setpoint changes can be done
            self._timed_setpoints[s] = (len(self.times()), 0)

        # Mixed-interger formulation of component setpoint
        for component_name in self._timed_setpoints.keys():
            # Make 1 variable per component (so not per control
            # variable) which represents if the setpoint of the component
            # is changed (1) is not changed (0) in a timestep
            change_setpoint_var = f"{component_name}._change_setpoint_var"
            self._component_to_change_setpoint_map[component_name] = change_setpoint_var
            self._change_setpoint_var[change_setpoint_var] = ca.MX.sym(change_setpoint_var)
            self._change_setpoint_bounds[change_setpoint_var] = (0, 1.0)


class HeatProblem(
    CFOptions,
    ScenarioOutput,
    HeatMixin,
    LinearizedOrderGoalProgrammingMixin,
    SinglePassGoalProgrammingMixin,
    ESDLMixin,
    CollocatedIntegratedOptimizationProblem,
):
    """
    Goal priorities are:
    1. minimize TCO = Capex + Opex*lifetime
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        assert self._cf_objective == "TCO minimization of the network"

        # Additional variables and their properties
        # Minimizing buffer size
        self.__max_buffer_heat_var = {}
        self._max_buffer_heat_map = {}
        self.__max_buffer_heat_nominals = {}

        # Optional placement of buffers
        self.__buffer_placement_var = {}
        self.__buffer_placement_var_bounds = {}
        self._buffer_placement_map = {}

        # daily avg
        self._days = 365
        self._source_daily_avg_map = {}
        self._ates_daily_avg_map = {}
        self.__daily_avg_var = {}
        self.__daily_avg_bounds = {}

        # Additional variables and their properties
        # Minimizing source size
        self.__max_source_heat_var = {}
        self._max_source_heat_map = {}
        self.__max_source_heat_nominals = {}

        # Optional placement of buffers
        self.__source_placement_var = {}
        self.__source_placement_var_bounds = {}
        self._source_placement_map = {}

        # ates wells
        self._ates_doublets_map = {}
        self.__ates_doublets_var = {}
        self.__ates_doublets_var_bounds = {}

        # geo wells
        self._geo_wells_map = {}
        self.__geo_wells_var = {}
        self.__geo_wells_var_bounds = {}

        self._ates_is_charging_map = {}
        self.__ates_is_charging_var = {}
        self.__ates_is_charging_var_bounds = {}

        self._ates_charge_amount_map = {}
        self.__ates_charge_amount_var = {}
        self.__ates_charge_amount_var_bounds = {}

        self._ates_discharge_amount_map = {}
        self.__ates_discharge_amount_var = {}
        self.__ates_discharge_amount_var_bounds = {}

        # variables for solver settings
        self._qpsol = None

        self._hot_start = False

        # Store (time taken, success, objective values, solver stats) per priority
        self._priorities_output = []
        self.__priority = None
        self.__priority_timer = None

    def pre(self):
        self._qpsol = CachingQPSol()

        super().pre()
        bounds = self.bounds()

        # We want a symbol per buffer that indicates the maximum size that was
        # reached for that particular buffer.
        for b in self._cf_minimize_size_buffers:
            buffer_max_heat_var = f"{b}__max_size"

            self._max_buffer_heat_map[b] = buffer_max_heat_var
            self.__max_buffer_heat_var[buffer_max_heat_var] = ca.MX.sym(buffer_max_heat_var)
            self.__max_buffer_heat_nominals[buffer_max_heat_var] = self.variable_nominal(
                f"{b}.Stored_heat"
            )

        # For every buffer that can be _optionally_ placed, we add a boolean
        # symbol.
        for b in self._cf_optional_buffers:
            buffer_placement_var = f"{b}__buffer_placed"

            self._buffer_placement_map[b] = buffer_placement_var
            self.__buffer_placement_var[buffer_placement_var] = ca.MX.sym(buffer_placement_var)
            self.__buffer_placement_var_bounds[buffer_placement_var] = (0.0, 1.0)

        # We want a symbol per source that indicates the maximum size that was
        # reached for that particular source.
        for s in self._cf_minimize_size_sources:
            source_max_heat_var = f"{s}__max_size"

            self._max_source_heat_map[s] = source_max_heat_var
            self.__max_source_heat_var[source_max_heat_var] = ca.MX.sym(source_max_heat_var)
            self.__max_source_heat_nominals[source_max_heat_var] = self.variable_nominal(
                f"{s}.Heat_source"
            )

        # For every source that can be _optionally_ placed, we add a boolean
        # symbol.
        for s in self._cf_optional_sources:
            source_placement_var = f"{s}__source_placed"

            self._source_placement_map[s] = source_placement_var
            self.__source_placement_var[source_placement_var] = ca.MX.sym(source_placement_var)
            self.__source_placement_var_bounds[source_placement_var] = (0.0, 1.0)

        # Specifically for Geothermal sources we use an additional variable that determines the
        # amount of wells as most cost are related to that.
        for sources in self.heat_network_components.get("source", []):
            for geo_full in self.heat_network_components.get("geothermal", []):
                if sources in geo_full:
                    geo = sources
                    geothermal_wells_var = f"{geo}__number_of_wells"

                    self._geo_wells_map[geo] = geothermal_wells_var
                    self.__geo_wells_var[geothermal_wells_var] = ca.MX.sym(geothermal_wells_var)
                    self.__geo_wells_var_bounds[geothermal_wells_var] = (
                        0.0,
                        self._cf_override_number_of_units[geo],
                    )

        # For every source and ATES we make a __daily_avg variable to be used for energy balance
        # in the year problem
        for s in self.heat_network_components.get("source", []):
            for i in range(self._days):
                source_daily_avg_var = f"{s}__daily_avg" + f"_{i}"
                self._source_daily_avg_map[s] = f"{s}__daily_avg"
                self.__daily_avg_var[source_daily_avg_var] = ca.MX.sym(source_daily_avg_var)
                self.__daily_avg_bounds[source_daily_avg_var] = tuple(
                    x / WATT_TO_MEGA_WATT for x in bounds[f"{s}.Heat_source"]
                )

        for a in self._cf_optional_ates:
            # Hardcode the placement of the ATES variable
            ates_placed_var = f"{a}__placed"
            self._buffer_placement_map[a] = ates_placed_var
            self.__buffer_placement_var[ates_placed_var] = ca.MX.sym(ates_placed_var)
            self.__buffer_placement_var_bounds[ates_placed_var] = (0.0, 1.0)

        for a in self._cf_minimize_size_ates:
            ates_wells_var = f"{a}__number_of_doublets"
            self._ates_doublets_map[a] = ates_wells_var
            self.__ates_doublets_var[ates_wells_var] = ca.MX.sym(ates_wells_var)
            self.__ates_doublets_var_bounds[ates_wells_var] = (
                0.0,
                self._cf_override_number_of_units[a],
            )

        for a in self.heat_network_components.get("ates", []):
            # These variables are needed for the energy balance in the year problem. The additional
            # (dis)charge and boolean are used to include an efficiency factor for the ATES
            self._ates_daily_avg_map[a] = f"{a}__daily_avg"
            self._ates_is_charging_map[a] = f"{a}__is_charging"
            self._ates_charge_amount_map[a] = f"{a}__charge_amount"
            self._ates_discharge_amount_map[a] = f"{a}__discharge_amount"
            for i in range(self._days):
                ates_daily_avg_var = f"{a}__daily_avg" + f"_{i}"
                self.__daily_avg_var[ates_daily_avg_var] = ca.MX.sym(ates_daily_avg_var)
                self.__daily_avg_bounds[ates_daily_avg_var] = tuple(
                    x / WATT_TO_MEGA_WATT for x in bounds[f"{a}.Heat_ates"]
                )

                ates_is_charging_var = f"{a}__is_charging" + f"_{i}"
                self.__ates_is_charging_var[ates_is_charging_var] = ca.MX.sym(ates_is_charging_var)
                self.__ates_is_charging_var_bounds[ates_is_charging_var] = (0.0, 1.0)

                ates_charge_amount_var = f"{a}__charge_amount" + f"_{i}"
                self.__ates_charge_amount_var[ates_charge_amount_var] = ca.MX.sym(
                    ates_charge_amount_var
                )
                self.__ates_charge_amount_var_bounds[ates_charge_amount_var] = (
                    0.0,
                    bounds[f"{a}.Heat_ates"][1] / WATT_TO_MEGA_WATT,
                )

                ates_discharge_amount_var = f"{a}__discharge_amount" + f"_{i}"
                self.__ates_discharge_amount_var[ates_discharge_amount_var] = ca.MX.sym(
                    ates_discharge_amount_var
                )
                self.__ates_charge_amount_var_bounds[ates_discharge_amount_var] = (
                    0.0,
                    -bounds[f"{a}.Heat_ates"][0] / WATT_TO_MEGA_WATT,
                )

    def goals(self):
        goals = super().goals().copy()
        # We do a minization of TCO consisting of CAPEX and OPEX over 25 years
        # CAPEX is based upon the boolean placement variables and the optimized maximum sizes
        # Note that CAPEX for geothermal and ATES is also dependent on the amount of doublets
        # In practice this means that the CAPEX is mainly driven by the peak day problem
        # The OPEX is based on the Source strategy which is computed on the __daily_avg variables
        # The OPEX thus is based on an avg strategy and discrepancies due to fluctuations intra-day
        # are possible.
        # The idea behind the two timelines is that the optimizer can make the OPEX vs CAPEX
        # trade-offs
        goals.append(MinimizeOPEX(priority=1))
        goals.append(
            MinimizeCAPEX(
                self._max_source_heat_map.values(),
                self._source_placement_map.values(),
                self._max_buffer_heat_map.values(),
                self._buffer_placement_map.values(),
                priority=1,
            )
        )

        return goals

    def constraints(self, ensemble_member):
        constraints = super().constraints(ensemble_member)

        bounds = self.bounds()

        # This constraint ensures that the max_size variable for the buffer >= the maximum
        # stored heat. The objective will drag it down to equal the max stored heat by minimizing
        # cost.
        for b, max_var in self._max_buffer_heat_map.items():
            max_heat = self.extra_variable(max_var, ensemble_member)
            stored_heat = self.__state_vector_scaled(f"{b}.Stored_heat", ensemble_member)
            constraint_nominal = self.__max_buffer_heat_nominals[max_var]

            constraints.append(((max_heat - stored_heat) / constraint_nominal, 0.0, np.inf))

        # Same as for the buffer but now for the source
        for s, max_var in self._max_source_heat_map.items():
            max_heat = self.extra_variable(max_var, ensemble_member)
            heat_source = self.__state_vector_scaled(f"{s}.Heat_source", ensemble_member)
            constraint_nominal = bounds[f"{s}.Heat_source"][1]

            constraints.append(((max_heat - heat_source) / constraint_nominal, 0.0, np.inf))

        # Here we make the variables for the energy balance in the year problem
        daily_demand = self._daily_avg_demands / WATT_TO_MEGA_WATT
        # Get the estimated heat loss as a constant out of the peak day problem
        heatloss = 0.0
        for pipe in self.hot_pipes:
            heat_loss_parameter = self._HeatMixin__pipe_topo_heat_loss_parameters[0][
                f"{pipe}.Heat_loss"
            ]
            # If the heat_loss parameter is a value then the DN sizes are not optimized and the heat
            # losses are estimated with a constant value. If the parameter is nan then the DN
            # sizes are optimized and we use the variable instead.
            if math.isnan(heat_loss_parameter):
                pipe_heat_loss = self.extra_variable(
                    self._HeatMixin__pipe_topo_heat_loss_map[pipe], ensemble_member
                )
            else:
                pipe_heat_loss = heat_loss_parameter
            heatloss = pipe_heat_loss / WATT_TO_MEGA_WATT

        # All the supply for each day
        summed_source_symbols = [0.0] * self._days
        for s in self.heat_network_components.get("source", []):
            max_heat = None
            if s in self._cf_minimize_size_sources:
                max_heat = (
                    self.extra_variable(self._max_source_heat_map[s], ensemble_member)
                    / WATT_TO_MEGA_WATT
                )
            source_daily_heat = self.get_source_daily(s, ensemble_member)

            for idx, symbol in enumerate(source_daily_heat):
                summed_source_symbols[idx] += symbol
                # Match the profile in the year problem if provided
                try:
                    source_profile = self._source_profiles_year[s].to_numpy() / WATT_TO_MEGA_WATT
                    constraints.append(
                        ((symbol - source_profile[idx]) / np.median(source_profile), 0.0, 0.0)
                    )
                    if max_heat is not None:
                        logger.warning(
                            f"You cannot optimize the size of a source ({s}) "
                            f"and match a profile at the same time"
                        )
                except KeyError:
                    # no source profiles to match
                    pass
                if max_heat is not None:
                    # If the maxPower of the source is optimized this constraints ensures that the
                    # maximum supply in the year problem obeys the optimized size
                    nominal = bounds[f"{s}.Heat_source"][1] / WATT_TO_MEGA_WATT
                    constraints.append(((max_heat - symbol) / nominal, 0.0, np.inf))

        # We add the ATES to the summed source symbol, the ATES can also consume, naming could be
        # better
        for s in self.heat_network_components.get("ates", []):
            ates_daily_heat = self.get_ates_daily(s, ensemble_member)
            for idx, symbol in enumerate(ates_daily_heat):
                summed_source_symbols[idx] += symbol

            ates_doublets = self.extra_variable(f"{s}__number_of_doublets")
            symbols_is_charging = self.get_ates_is_charging(s, ensemble_member)
            big_m = 2.0 * max(abs(x / WATT_TO_MEGA_WATT) for x in bounds[f"{s}.Heat_ates"])
            for ates_heat_sym, ates_is_charging_sym in zip(ates_daily_heat, symbols_is_charging):
                # Make the maximum ATES heat a function of the number of doublets
                single_doublet_power = (
                    self.parameters(ensemble_member)[f"{s}.single_doublet_power"] / 1.0e6
                )
                constraints.append(
                    ((ates_doublets * single_doublet_power - ates_heat_sym) / big_m, 0.0, np.inf)
                )
                constraints.append(
                    ((-ates_doublets * single_doublet_power - ates_heat_sym) / big_m, -np.inf, 0.0)
                )
                # force ates_is_charging to 1 if daily ATES heat is positive
                constraints.append(
                    ((ates_heat_sym - big_m * (1 - ates_is_charging_sym)) / big_m, -np.inf, 0.0)
                )
                constraints.append(
                    ((ates_heat_sym + big_m * ates_is_charging_sym) / big_m, 0.0, np.inf)
                )

            # Constraints to have to a variable with the total charge and total discharge
            # of the ATES
            symbols_charge_amount = self.get_ates_charge_amount(s, ensemble_member)
            for ates_heat_sym, ates_is_charging_sym, ates_charge_amount_sym in zip(
                ates_daily_heat, symbols_is_charging, symbols_charge_amount
            ):
                # if daily ATES heat is positive, force ates_charge_amount to be equal to it
                constraints.append(
                    ((ates_charge_amount_sym - ates_is_charging_sym * big_m) / big_m, -np.inf, 0.0)
                )
                constraints.append(
                    (
                        (
                            ates_charge_amount_sym
                            + ates_heat_sym
                            - (1 - ates_is_charging_sym) * big_m
                        )
                        / big_m,
                        -np.inf,
                        0.0,
                    )
                )
                constraints.append(((ates_charge_amount_sym + ates_heat_sym) / big_m, 0.0, np.inf))

            symbols_discharge_amount = self.get_ates_discharging_amount(s, ensemble_member)
            for ates_heat_sym, ates_is_charging_sym, ates_discharge_amount_sym in zip(
                ates_daily_heat, symbols_is_charging, symbols_discharge_amount
            ):
                # if daily ATES is negative, force ates_discharge_amount to be equal to it * -1
                constraints.append(
                    (
                        (ates_discharge_amount_sym - (1 - ates_is_charging_sym) * big_m) / big_m,
                        -np.inf,
                        0.0,
                    )
                )
                constraints.append(
                    ((ates_discharge_amount_sym - ates_heat_sym) / big_m, 0.0, np.inf)
                )
                constraints.append(
                    (
                        (ates_discharge_amount_sym - ates_heat_sym - ates_is_charging_sym * big_m)
                        / big_m,
                        -np.inf,
                        0.0,
                    )
                )

            summed_charge = sum(symbols_charge_amount)
            summed_discharge = sum(symbols_discharge_amount)
            ates_efficiency = self.parameters(ensemble_member)[f"{s}.efficiency"]
            constraints.append(
                (
                    (summed_charge * ates_efficiency - summed_discharge) / (big_m * self._days),
                    0.0,
                    0.0,
                )
            )

        # Constraint to enforce energy balance (meeting of demands) in the yearly problem
        for i in range(self._days):
            constraints.append(
                (
                    (daily_demand[i] + heatloss - summed_source_symbols[i]) / np.mean(daily_demand),
                    0.0,
                    0.0,
                )
            )

            # Constraint to enforce matching demands in peak day problem
            for d in self.heat_network_components.get("demand", []):
                heat_demand = self.__state_vector_scaled(f"{d}.Heat_demand", ensemble_member)
                target = self.get_timeseries(f"{d}.target_heat_demand")
                for i in range(len(self.times())):
                    constraints.append(
                        ((heat_demand[i] - target.values[i]) / np.median(target.values), 0.0, 0.0)
                    )

            # Constraint to enforce matching source profiles in peak day problem
            for s in self.heat_network_components.get("source", []):
                try:
                    heat_source = self.__state_vector_scaled(f"{s}.Heat_source", ensemble_member)
                    target = self.get_timeseries(f"{s}.target_heat_source")
                    for i in range(len(self.times())):
                        constraints.append(
                            (
                                (heat_source[i] - target.values[i]) / np.median(target.values),
                                0.0,
                                0.0,
                            )
                        )
                except KeyError:
                    # No profiles to match for this source
                    pass

        return constraints

    def path_constraints(self, ensemble_member):
        constraints = super().path_constraints(ensemble_member)

        parameters = self.parameters(ensemble_member)
        bounds = self.bounds()
        times = self.times()

        # TODO: Can we make a generic function for adding placement constraints
        # Force discharge of disconnected buffer to zero. The associated pipe
        # should be disconnectable, and disconnect as a result.
        for b in self._cf_optional_buffers:
            q_buffer = self.state(f"{b}.HeatIn.Q")
            is_used = self.__buffer_placement_var[self._buffer_placement_map[b]]

            big_m = parameters[f"{b}.volume"] / min(np.diff(times))

            constraint_nominal = (big_m * self.variable_nominal(f"{b}.HeatIn.Q")) ** 0.5

            constraints.append(((q_buffer - big_m * is_used) / constraint_nominal, -np.inf, 0.0))
            constraints.append(((q_buffer + big_m * is_used) / constraint_nominal, 0.0, np.inf))

        # Force Heat_source to zero is source in not placed.
        for s in self._cf_optional_sources:
            heat_source = self.state(f"{s}.Heat_source")
            is_used = self.__source_placement_var[self._source_placement_map[s]]

            big_m = 2.0 * bounds[f"{s}.Heat_source"][1]

            constraint_nominal = (big_m * self.variable_nominal(f"{s}.Heat_source")) ** 0.5

            constraints.append(((heat_source - big_m * is_used) / constraint_nominal, -np.inf, 0.0))
            constraints.append(((heat_source + big_m * is_used) / constraint_nominal, 0.0, np.inf))

        # Force Heat_ates to zero if the ATES is not placed
        for a in self._cf_optional_ates:
            ates_power = self.state(f"{a}.Heat_ates")
            is_used = self.__buffer_placement_var[self._buffer_placement_map[a]]

            big_m = 2.0 * bounds[f"{a}.Heat_ates"][1]

            constraint_nominal = (big_m * self.variable_nominal(f"{a}.Heat_ates")) ** 0.5

            constraints.append(((ates_power - big_m * is_used) / constraint_nominal, -np.inf, 0.0))
            constraints.append(((ates_power + big_m * is_used) / constraint_nominal, 0.0, np.inf))

        # Make the maximum power of the geothermal source a direct function of the optimized amount
        # of wells/doublets
        for a in self.heat_network_components.get("geothermal", []):
            a = a[:-3]
            geo_power = self.state(f"{a}.Heat_source")
            single_well_power = parameters[f"{a}.single_doublet_power"]
            wells = self.__geo_wells_var[self._geo_wells_map[a]]

            big_m = 1.5 * bounds[f"{a}.Heat_source"][1]

            constraint_nominal = (big_m * self.variable_nominal(f"{a}.Heat_source")) ** 0.5

            constraints.append(
                ((single_well_power * wells - geo_power) / constraint_nominal, 0.0, np.inf)
            )

        # Make the maximum power of the ATES a direct function of the optimized amount
        # of wells/doublets
        for a in self._cf_minimize_size_ates:
            ates_power = self.state(f"{a}.Heat_ates")
            single_well_power = parameters[f"{a}.single_doublet_power"]
            doublets = self.__ates_doublets_var[self._ates_doublets_map[a]]

            big_m = 1.5 * bounds[f"{a}.Heat_ates"][1]

            constraint_nominal = (big_m * self.variable_nominal(f"{a}.Heat_ates")) ** 0.5

            constraints.append(
                ((single_well_power * doublets - ates_power) / constraint_nominal, 0.0, np.inf)
            )
            constraints.append(
                ((-single_well_power * doublets - ates_power) / constraint_nominal, -np.inf, 0.0)
            )

        return constraints

    def history(self, ensemble_member):
        return AliasDict(self.alias_relation)

    def heat_network_options(self):
        options = super().heat_network_options()
        options["minimum_velocity"] = 0.0
        options["heat_loss_disconnected_pipe"] = False
        # options["neglect_pipe_heat_losses"] = True
        return options

    @property
    def extra_variables(self):
        variables = super().extra_variables.copy()
        variables.extend(self.__max_buffer_heat_var.values())
        variables.extend(self.__buffer_placement_var.values())
        variables.extend(self.__max_source_heat_var.values())
        variables.extend(self.__source_placement_var.values())
        variables.extend(self.__daily_avg_var.values())
        variables.extend(self.__geo_wells_var.values())
        variables.extend(self.__ates_is_charging_var.values())
        variables.extend(self.__ates_charge_amount_var.values())
        variables.extend(self.__ates_discharge_amount_var.values())
        variables.extend(self.__ates_doublets_var.values())
        return variables

    @property
    def path_variables(self):
        variables = super().path_variables.copy()
        return variables

    def variable_is_discrete(self, variable):
        if (
            variable in self.__buffer_placement_var
            or variable in self.__source_placement_var
            or variable in self.__geo_wells_var
            or variable in self.__ates_doublets_var
            or variable in self.__ates_is_charging_var
        ):
            return True
        else:
            return super().variable_is_discrete(variable)

    def variable_nominal(self, variable):
        if variable in self.__max_buffer_heat_nominals:
            return self.__max_buffer_heat_nominals[variable]
        elif variable in self.__max_source_heat_nominals:
            return self.__max_source_heat_nominals[variable]
        else:
            return super().variable_nominal(variable)

    def get_ates_daily(self, ates, ensemble_member):
        # provides values in MWh???
        symbols = []
        for i in range(self._days):
            symbols.append(
                self.extra_variable(self._ates_daily_avg_map[f"{ates}"] + f"_{i}", ensemble_member)
            )
        return symbols

    def get_ates_is_charging(self, ates, ensemble_member):
        symbols = []
        for i in range(self._days):
            var_name = self._ates_is_charging_map[f"{ates}"] + f"_{i}"
            symbols.append(self.extra_variable(var_name, ensemble_member))
        return symbols

    def get_ates_charge_amount(self, ates, ensemble_member):
        # provides values in MWh
        symbols = []
        for i in range(self._days):
            var_name = self._ates_charge_amount_map[f"{ates}"] + f"_{i}"
            symbols.append(self.extra_variable(var_name, ensemble_member))
        return symbols

    def get_ates_discharging_amount(self, ates, ensemble_member):
        # provides values in MWh
        symbols = []
        for i in range(self._days):
            var_name = self._ates_discharge_amount_map[f"{ates}"] + f"_{i}"
            symbols.append(self.extra_variable(var_name, ensemble_member))
        return symbols

    def get_source_daily(self, source, ensemble_member):
        # provides values in Wh
        symbols = []
        for i in range(self._days):
            symbols.append(
                self.extra_variable(
                    self._source_daily_avg_map[f"{source}"] + f"_{i}", ensemble_member
                )
            )
        return symbols

    def bounds(self):
        bounds = super().bounds()
        bounds.update(self.__buffer_placement_var_bounds)
        bounds.update(self.__source_placement_var_bounds)
        bounds.update(self.__geo_wells_var_bounds)
        bounds.update(self.__daily_avg_bounds)
        bounds.update(self.__ates_is_charging_var_bounds)
        bounds.update(self.__ates_charge_amount_var_bounds)
        bounds.update(self.__ates_discharge_amount_var_bounds)
        bounds.update(self.__ates_doublets_var_bounds)
        return bounds

    def __state_vector_scaled(self, variable, ensemble_member):
        canonical, sign = self.alias_relation.canonical_signed(variable)
        return (
            self.state_vector(canonical, ensemble_member) * self.variable_nominal(canonical) * sign
        )

    def solver_options(self):
        options = super().solver_options()
        options["casadi_solver"] = self._qpsol
        options["solver"] = "gurobi"
        gurobi_options = options["gurobi"] = {}
        gurobi_options["MIPgap"] = 0.1
        gurobi_options["threads"] = 4

        return options

    def solver_success(self, solver_stats, log_solver_failure_as_error):
        success, log_level = super().solver_success(solver_stats, log_solver_failure_as_error)

        # Allow time-outs for CPLEX and CBC
        if (
            solver_stats["return_status"] == "time limit exceeded"
            or solver_stats["return_status"] == "stopped - on maxnodes, maxsols, maxtime"
        ):
            if self.objective_value > 1e10:
                # Quick check on the objective value. If no solution was
                # found, this is typically something like 1E50.
                return success, log_level

            return True, logging.INFO
        else:
            return success, log_level

    def priority_started(self, priority):
        self.__priority = priority
        self.__priority_timer = time.time()

        super().priority_started(priority)

    def priority_completed(self, priority):
        super().priority_completed(priority)

        self._hot_start = True

        time_taken = time.time() - self.__priority_timer
        self._priorities_output.append(
            (
                priority,
                time_taken,
                True,
                self.objective_value,
                self.solver_stats,
            )
        )

    def post(self):
        # In case the solver fails, we do not get in priority_completed(). We
        # append this last priority's statistics here in post().
        success, _ = self.solver_success(self.solver_stats, False)
        if not success:
            time_taken = time.time() - self.__priority_timer
            self._priorities_output.append(
                (
                    self.__priority,
                    time_taken,
                    False,
                    self.objective_value,
                    self.solver_stats,
                )
            )

        super().post()


class HeatProblemStaged(HeatProblem):
    def __init__(
        self,
        *args,
        stage=None,
        boolean_bounds=None,
        stage_2_x=None,
        priorities_output=None,
        **kwargs,
    ):
        self._stage = stage
        self.__boolean_bounds = boolean_bounds
        self.__buffer_bounds = {}
        self.__stage_2_x = stage_2_x
        self.__idx_max_global_demand = None
        self.__write_html_output = False

        super().__init__(*args, **kwargs)

        if stage == 2:
            self._hot_start = True

        if priorities_output is not None:
            self._priorities_output = priorities_output

    def pre(self):
        super().pre()
        if self._stage == 1:
            self.__idx_max_global_demand = 0
        else:
            total_demand = None
            for d in self.heat_network_components.get("demand", []):
                _, values = self.io.get_timeseries(f"{d}.target_heat_demand")
                if total_demand is None:
                    total_demand = values.copy()
                else:
                    total_demand += values.copy()
            self.__idx_max_global_demand = int(total_demand.argmax())
            self.__total_demand = total_demand

    def read(self):
        super().read()

        # For stage 1 we only consider the peak demand, we do a trick by first making the entire
        # timeseries the max value and after that shortening the time steps
        if self._stage == 1:
            ts_names = [
                x for x in self.io.get_timeseries_names() if x.endswith(".target_heat_demand")
            ]

            for ts_name in ts_names:
                datetimes, values = self.io.get_timeseries(ts_name)
                self.io.set_timeseries(ts_name, datetimes, np.full_like(values, max(values)))
            # self.total_demand = np.array([max(self.total_demand), max(self.total_demand)])

    def solver_options(self):
        options = super().solver_options()
        return options

    def times(self, variable=None):
        times = super().times(variable)

        # Shortening the time series for stage 1 to solve for a single timestep with peak demand
        if self._stage == 1:
            return times[:2]
        else:
            return times

    def path_goals(self):
        goals = super().path_goals().copy()

        # This is to make the source strategy in the peak day problem more logical. The OPEX
        # minimization in priority one only applies to the year problem.
        if self._stage == 3:
            goals.append(MinimizeOPEXDaily(priority=2))

        return goals

    def constraints(self, ensemble_member):
        constraints = super().constraints(ensemble_member)

        # Force all the sources and ATES to thave their maximum supply moment at the peak demand
        # moment. This is a constraint to create a smaller search space for the optimizer.
        for s, max_var in self._max_source_heat_map.items():
            max_heat = self.extra_variable(max_var, ensemble_member)
            constraint_nominal = self.variable_nominal(f"{s}.Heat_source")
            heat_source = self.__state_vector_scaled(f"{s}.Heat_source", ensemble_member)
            constraints.append(
                (
                    (max_heat - heat_source[self.__idx_max_global_demand]) / constraint_nominal,
                    0.0,
                    0.0,
                )
            )

        for s in self.heat_network_components.get("ates", []):
            parameters = self.parameters(ensemble_member)
            max_heat = (
                self.extra_variable(f"{s}__number_of_doublets")
                * parameters[f"{s}.single_doublet_power"]
            )
            constraint_nominal = self.variable_nominal(f"{s}.Heat_ates")
            heat_ates = self.__state_vector_scaled(f"{s}.Heat_ates", ensemble_member)
            constraints.append(
                (
                    (max_heat - heat_ates[self.__idx_max_global_demand]) / constraint_nominal,
                    -np.inf,
                    0.0,
                )
            )
            constraints.append(
                (
                    (max_heat - heat_ates[self.__idx_max_global_demand]) / constraint_nominal,
                    0.0,
                    np.inf,
                )
            )
        return constraints

    def bounds(self):
        bounds = super().bounds().copy()

        # This constraint is to have heat in the buffer when solving for the peak demand in stage 1.
        # Otherwise all peak would have to be supplied be the sources and this would lead to far
        # larger pipe sizes than needed when solving for 24 hour timeseries.
        if self._stage == 1:
            for b in self.heat_network_components.get("buffer", []):
                upper_bound = bounds[f"{b}.Stored_heat"][1]
                self.__buffer_bounds[f"{b}.Stored_heat"] = (upper_bound / 2.0, upper_bound)

            bounds.update(self.__buffer_bounds)

        if self._stage > 1:
            bounds.update(self.__boolean_bounds)
        return bounds

    def __state_vector_scaled(self, variable, ensemble_member):
        canonical, sign = self.alias_relation.canonical_signed(variable)
        return (
            self.state_vector(canonical, ensemble_member) * self.variable_nominal(canonical) * sign
        )

    def transcribe(self):
        discrete, lbx, ubx, lbg, ubg, x0, nlp = super().transcribe()

        if self._stage == 3:
            x0 = self.__stage_2_x

        return discrete, lbx, ubx, lbg, ubg, x0, nlp

    def post(self):
        super().post()

        results = self.extract_results()
        parameters = self.parameters(0)

        if self._stage == 3:
            self._write_updated_esdl()
            if self.__write_html_output:
                self._write_html_output(template_name="mpc_scenario_sizing_output")

            sources = {}
            seasonal_storages = {}
            for source in self.heat_network_components.get("source", []):
                sources[source] = np.asarray(
                    [results[f"{source}__daily_avg_{i}"] for i in range(365)]
                )
            for ates in self.heat_network_components.get("ates", []):
                seasonal_storages[ates] = np.asarray(
                    [results[f"{ates}__daily_avg_{i}"] for i in range(365)]
                )

            plt.figure()
            plot_data_peak = None
            plot_data_geo = None
            plot_data = None
            for key, data in sources.items():
                if "Geo" in key:
                    if plot_data_geo is None:
                        plot_data_geo = data
                    else:
                        plot_data_geo += data
                elif "HeatProducer" in key:
                    if plot_data_peak is None:
                        plot_data_peak = data
                    else:
                        plot_data_peak += data
                else:
                    if plot_data is None:
                        plot_data = data
                    else:
                        plot_data += data
            plt.plot(plot_data, label="WL")
            plt.plot(plot_data_geo, label="Geo")
            plt.plot(plot_data_peak, label="peak")
            plot_data = None
            for _, data in seasonal_storages.items():
                if plot_data is None:
                    plot_data = data
                else:
                    plot_data += data
            plt.plot(plot_data, label="ates")
            plt.plot(
                self._daily_avg_demands / WATT_TO_MEGA_WATT, label="total_demand", color="black"
            )
            plt.legend()

            hourly_demand_target = None
            for demand in self.heat_network_components["demand"]:
                if hourly_demand_target is None:
                    hourly_demand_target = self.get_timeseries(
                        f"{demand}.target_heat_demand"
                    ).values
                else:
                    hourly_demand_target += self.get_timeseries(
                        f"{demand}.target_heat_demand"
                    ).values
            hourly_sources = {}
            for source in self.heat_network_components["source"]:
                hourly_sources[source] = results[f"{source}.Heat_source"].copy()
            hourly_demand = {}
            for demand in self.heat_network_components["demand"]:
                hourly_demand[demand] = results[f"{demand}.Heat_demand"].copy()
            hourly_buffer = {}
            for buffer in self.heat_network_components.get("buffer", []):
                hourly_buffer[buffer] = results[f"{buffer}.Heat_buffer"].copy()
            hourly_ates = {}
            for ates in self.heat_network_components.get("ates", []):
                hourly_ates[ates] = results[f"{ates}.Heat_ates"].copy()

            hourly_heatloss = None
            for pipe in self.hot_pipes:
                if hourly_heatloss is None:
                    hourly_heatloss = self._HeatMixin__pipe_topo_heat_loss_parameters[0][
                        f"{pipe}.Heat_loss"
                    ]
                else:
                    hourly_heatloss += self._HeatMixin__pipe_topo_heat_loss_parameters[0][
                        f"{pipe}.Heat_loss"
                    ]
            hourly_heatloss = np.asarray([hourly_heatloss] * len(self.times()))

            plt.figure()
            plot_data_peak = None
            plot_data_geo = None
            plot_data = None
            plot_data_total_demand = None
            for _, data in hourly_demand.items():
                if plot_data_total_demand is None:
                    plot_data_total_demand = data
                else:
                    plot_data_total_demand += data
            for key, data in hourly_sources.items():
                if "Geo" in key:
                    if plot_data_geo is None:
                        plot_data_geo = data
                    else:
                        plot_data_geo += data
                elif "HeatProducer" in key:
                    if plot_data_peak is None:
                        plot_data_peak = data
                    else:
                        plot_data_peak += data
                else:
                    if plot_data is None:
                        plot_data = data
                    else:
                        plot_data += data
            plt.plot(plot_data / 1.0e6, label="WL")
            plt.plot(plot_data_geo / 1.0e6, label="Geo")
            plt.plot(plot_data_peak / 1.0e6, label="peak")
            plot_data = None
            for _, data in hourly_buffer.items():
                if plot_data is None:
                    plot_data = data
                else:
                    plot_data += data
            plt.plot(plot_data / 1.0e6, label="buffer")
            plot_data = None
            for _, data in hourly_ates.items():
                if plot_data is None:
                    plot_data = data
                else:
                    plot_data += data
            plt.plot(plot_data / 1.0e6, label="ates")
            plt.plot(hourly_heatloss / 1.0e6, label="heatloss")
            plt.plot(
                (plot_data_total_demand + hourly_heatloss) / 1.0e6,
                label="total_demand",
                color="black",
            )
            plt.legend()
            plt.show()

            runinfo_path = Path(self.esdl_run_info_path).resolve()
            tree = ET.parse(runinfo_path)
            root = tree.getroot()
            parameters_dict = dict()
            parameter_path = root.findtext("pi:outputResultsFile", namespaces=ns)
            for key, value in parameters.items():
                new_value = value  # [x for x in value]
                # if len(new_value) == 1:
                #     new_value = new_value[0]
                parameters_dict[key] = new_value
            if parameter_path is None:
                workdir = root.findtext("pi:workDir", namespaces=ns)
                parameter_path = os.path.join(workdir, "parameters.json")
            with open(parameter_path, "w") as file:
                json.dump(parameters_dict, fp=file)

            runinfo_path = Path(self.esdl_run_info_path).resolve()
            tree = ET.parse(runinfo_path)
            root = tree.getroot()
            results_path = root.findtext("pi:outputResultsFile", namespaces=ns)
            results_dict = dict()

            for key, values in results.items():
                new_value = values.tolist()
                if len(new_value) == 1:
                    new_value = new_value[0]
                results_dict[key] = new_value

            if results_path is None:
                workdir = root.findtext("pi:workDir", namespaces=ns)
                results_path = os.path.join(workdir, "results.json")
            with open(results_path, "w") as file:
                json.dump(results_dict, fp=file)


@_main_decorator
def main(runinfo_path, log_level):
    # Run a single time step optimization, where the demands are set their
    # maximum observed values.
    logger.info("Stage 1")

    problem_s1 = run_optimization_problem(
        HeatProblemStaged,
        esdl_run_info_path=runinfo_path,
        log_level=log_level,
        stage=1,
    )

    results = problem_s1.extract_results()

    pc_map = problem_s1._HeatMixin__pipe_topo_pipe_class_map
    boolean_bounds = {}

    for pipe_classes in pc_map.values():
        for var_name in pipe_classes.values():
            v = results[var_name][0]
            boolean_bounds[var_name] = (v, v)
    boolean_bounds = {}
    # We give bounds for stage 2 by allowing up to 2 DN sizes larger than what was found in the
    # stage 1 optimization.
    for pipe_classes in pc_map.values():
        v_prev = 0.0
        for var_name in pipe_classes.values():
            boolean_bounds[var_name] = (0.0, 1.0)
            v = results[var_name][0]
            if v_prev == 0:
                boolean_bounds[var_name] = (0.0, 1.0)
                v_prev = v
            elif v_prev == 1.0:
                boolean_bounds[var_name] = (0.0, 1.0)
                v_prev = 2.0
            elif v_prev == 2.0:
                boolean_bounds[var_name] = (0.0, 1.0)
                v_prev = 3.0
            else:
                boolean_bounds[var_name] = (0.0, 0.0)
                v_prev = 3.0

    # Run a full horizon optimization to find the optimal sizes and placement variables
    logger.info("Stage 2")
    problem_s2 = run_optimization_problem(
        HeatProblemStaged,
        esdl_run_info_path=runinfo_path,
        log_level=log_level,
        stage=2,
        boolean_bounds=boolean_bounds,
        priorities_output=problem_s1._priorities_output,
    )

    results = problem_s2.extract_results()

    pc_map = problem_s2._HeatMixin__pipe_topo_pipe_class_map
    boolean_bounds = {}

    for pipe_classes in pc_map.values():
        for var_name in pipe_classes.values():
            v = results[var_name][0]
            boolean_bounds[var_name] = (v, v)

    stage_2_x = problem_s2.solver_output.copy()

    # Please note that stage 2 doesn't optimize the source strategy in the peak day problem. To
    # avoid long computation times we fix the optimize sizes (pipes) and then also optimize this
    # source strategy.
    logger.info("Stage 3")
    run_optimization_problem(
        HeatProblemStaged,
        esdl_run_info_path=runinfo_path,
        log_level=log_level,
        stage=3,
        boolean_bounds=boolean_bounds,
        stage_2_x=stage_2_x,
        priorities_output=problem_s2._priorities_output,
    )


if __name__ == "__main__":
    main()
