import itertools
import logging
import math
import os
import time
import xml.etree.ElementTree as ET  # noqa: N817
from dataclasses import dataclass
from pathlib import Path

import casadi as ca

import esdl

import numpy as np

import pandas as pd

from rtctools._internal.alias_tools import AliasDict
from rtctools.optimization.collocated_integrated_optimization_problem import (
    CollocatedIntegratedOptimizationProblem,
)
from rtctools.optimization.linearized_order_goal_programming_mixin import (
    LinearizedOrderGoalProgrammingMixin,
)
from rtctools.optimization.single_pass_goal_programming_mixin import (
    CachingQPSol,
    Goal,
    SinglePassGoalProgrammingMixin,
)
from rtctools.optimization.timeseries import Timeseries
from rtctools.util import run_optimization_problem

from rtctools_heat_network._heat_loss_u_values_pipe import heat_loss_u_values_pipe
from rtctools_heat_network.esdl.asset_to_component_base import _AssetToComponentBase
from rtctools_heat_network.esdl.esdl_mixin import ESDLMixin
from rtctools_heat_network.heat_mixin import HeatMixin
from rtctools_heat_network.pipe_class import PipeClass

from warmingup_mpc._helpers import _main_decorator, _sort_numbered


logger = logging.getLogger("WarmingUP-MPC")
logger.setLevel(logging.INFO)

ns = {"fews": "http://www.wldelft.nl/fews", "pi": "http://www.wldelft.nl/fews/PI"}


@dataclass(frozen=True)
class EDRPipeClass(PipeClass):
    xml_string: str

    @classmethod
    def from_edr_class(cls, name, edr_class_name, maximum_velocity):
        if not hasattr(EDRPipeClass, "._edr_pipes"):
            # TODO: Currently using private API of RTC-Tools Heat Network.
            # Make this functionality part of public API?
            EDRPipeClass._edr_pipes = _AssetToComponentBase()._edr_pipes

        edr_class = EDRPipeClass._edr_pipes[edr_class_name]
        diameter = edr_class["inner_diameter"]
        u_1 = edr_class["u_1"]
        u_2 = edr_class["u_2"]
        xml_string = edr_class["xml_string"]

        return EDRPipeClass(name, diameter, maximum_velocity, (u_1, u_2), xml_string)


class TargetHeatGoal(Goal):
    order = 1

    def __init__(self, state, target, priority=None):
        self.state = state
        self.target_min = target
        self.target_max = target
        self.function_range = (0.0, 2.0 * max(target.values))
        self.function_nominal = np.median(target.values)
        self.priority = priority

    def function(self, optimization_problem, ensemble_member):
        return optimization_problem.state(self.state)


class ConstantGeothermalSource(Goal):
    order = 2

    def __init__(
        self, optimization_problem, source, target, lower_fac=0.9, upper_fac=1.1, priority=2
    ):
        self.target_min = lower_fac * target
        self.target_max = upper_fac * target
        self.function_range = (0.0, 2.0 * target)
        self.state = f"{source}.Q"
        self.function_nominal = optimization_problem.variable_nominal(self.state)
        self.priority = priority

    def function(self, optimization_problem, ensemble_member):
        return optimization_problem.state(self.state)


class MinimizeSourcesHeatGoal(Goal):
    order = 1

    def __init__(self, source, nominal=1e6, priority=None):
        self.source = source
        self.function_nominal = nominal
        self.priority = priority

    def function(self, optimization_problem, ensemble_member):
        return optimization_problem.state(f"{self.source}.Heat_source")


class MinimizeLDGoal(Goal):
    order = 1

    def __init__(self, source, priority=None):
        self.source = source
        self.priority = priority

    def function(self, optimization_problem: HeatMixin, ensemble_member):
        obj = 0.0
        parameters = optimization_problem.parameters(ensemble_member)
        nominal = 0.0

        for p in optimization_problem.hot_pipes:
            pipe_classes = optimization_problem.pipe_classes(p)
            if len(pipe_classes) == 0 or len({pc.inner_diameter for pc in pipe_classes}) == 1:
                # Nothing to optimize for this pipe
                continue

            length = parameters[f"{p}.length"]
            var_name = optimization_problem.pipe_diameter_symbol_name(p)

            nominal += length * optimization_problem.variable_nominal(var_name)

            obj += optimization_problem.extra_variable(var_name, ensemble_member) * length

        return obj / nominal


class MinimizeTotalBufferSizeGoal(Goal):
    order = 1

    def __init__(self, max_buffer_heat_vars, priority=None):
        self.priority = priority
        self.max_buffer_heat_vars = max_buffer_heat_vars

    def function(self, optimization_problem, ensemble_member):
        obj = 0.0
        nominal = 0.0

        for m in self.max_buffer_heat_vars:
            obj += optimization_problem.extra_variable(m, ensemble_member)
            nominal += optimization_problem.variable_nominal(m)

        return obj / nominal


class CFOptions(ESDLMixin):
    def __init__(self, *args, esdl_run_info_path, **kwargs):
        self.esdl_run_info_path = esdl_run_info_path

        self._cf_override_hn_options = {}
        self._cf_override_return_temperature = None
        self._cf_override_supply_temperature = None

        self._cf_source_priority_map = {}
        self._cf_override_max_power = {}

        self._cf_max_placed_buffers = None
        self._cf_minimize_size_buffers = []
        self._cf_override_buffer_size = {}
        self._cf_optional_buffers = []

        self._cf_override_pipe_classes = {}

        self._cf_objective = None

        self._cf_output_folder = None

        # FIXME: Workaround CF UI bug where <inputParameterFile> is always
        # present. This will trip up ESDLMixin when it tries to interpret it,
        # so we remove that line.
        runinfo_path = Path(self.esdl_run_info_path).resolve()
        tree = ET.parse(runinfo_path)
        root = tree.getroot()

        xml_input_parameter_files = root.findall("pi:inputParameterFile", namespaces=ns)
        for f in xml_input_parameter_files:
            root.remove(f)

        runinfo_path.replace(runinfo_path.with_suffix(".xml.old"))
        tree.write(runinfo_path, xml_declaration=True, encoding="utf-8", method="xml")

        work_dir = Path(root.findtext("pi:workDir", namespaces=ns))
        if not work_dir.is_absolute():
            work_dir = runinfo_path.parent / work_dir

        # Get the output folder to store the HTML results in
        output_ref_path = root.findtext("pi:outputTimeSeriesFile", namespaces=ns)
        if output_ref_path is None:
            output_ref_path = self.esdl_run_info_path

        self._cf_html_output_dir = Path(output_ref_path).parent
        if not Path(self._cf_html_output_dir).is_absolute():
            self._cf_html_output_dir = work_dir / self._cf_html_output_dir

        # Now we parse all the options and overrides in the CSV files, and
        # store them as internal variables to be used by the optimization
        # problem class.
        csv_input_parameter_files = root.findall("pi:inputLocationAttributeCsvFile", namespaces=ns)

        csv_input_global_constraints = None
        csv_input_global_goal = None
        csv_input_producers = None
        csv_input_storages = None
        csv_input_pipes = None

        self._cf_csv_input_parameter_files = []

        for node in csv_input_parameter_files:
            f = node.text
            if not Path(f).is_absolute():
                f = str(work_dir / f)
            self._cf_csv_input_parameter_files.append(f)

            # Figure out what CSV file it is, and parse it accordingly
            if f.endswith("mpc_global_constraints.csv"):
                csv_input_global_constraints = f
            elif f.endswith("mpc_global_goal.csv"):
                csv_input_global_goal = f
            elif f.endswith("mpc_producers.csv"):
                csv_input_producers = f
            elif f.endswith("mpc_storages.csv"):
                csv_input_storages = f
            elif f.endswith("mpc_pipes.csv"):
                csv_input_pipes = f
            elif f.endswith("nodes_kpi_factors.csv"):
                pass
            else:
                raise Exception(f"Unknown input parameters file '{f}'")

        # Global options/constraints
        for option, is_active, value in pd.read_csv(
            csv_input_global_constraints, index_col=0
        ).itertuples(name=None):
            if not is_active:
                continue

            if option == "absolutePressure_min":
                self._cf_override_hn_options["pipe_minimum_pressure"] = float(value)
            if option == "absolutePressure_max":
                self._cf_override_hn_options["pipe_maximum_pressure"] = float(value)
            if option == "consumerPressureDrop":
                self._cf_override_hn_options["minimum_pressure_far_point"] = float(value)
            if option == "maxPlacedBuffers":
                self._cf_max_placed_buffers = int(value)
            if option == "returnTemperature":
                self._cf_override_return_temperature = float(value)
            if option == "supplyTemperature":
                self._cf_override_supply_temperature = float(value)
            if option == "velocity_max":
                self._cf_override_hn_options["maximum_velocity"] = float(value)

        # Global goal
        self._cf_objective = pd.read_csv(csv_input_global_goal, index_col=0).index[0]

        # Source/producers options
        for s, options in pd.read_csv(csv_input_producers, index_col=0).to_dict("index").items():
            assert not np.isnan(options["priority"])
            self._cf_source_priority_map[s] = options["priority"]
            self._cf_override_max_power[s] = options["maxPower"]

        # Buffer/storage options
        for b, options in pd.read_csv(csv_input_storages, index_col=0).to_dict("index").items():
            assert not np.isnan(options["maxVolume"])

            self._cf_override_buffer_size[b] = options["maxVolume"]

            if options["tuneSize"]:
                self._cf_minimize_size_buffers.append(b)

            if options["tunePlacement"]:
                self._cf_optional_buffers.append(b)

        # Pipe classes
        maximum_velocity = self._cf_override_hn_options["maximum_velocity"]

        no_pipe_class = PipeClass("None", 0.0, 0.0, (0.0, 0.0))
        pipe_classes = [
            EDRPipeClass.from_edr_class(name, edr_class_name, maximum_velocity)
            for name, edr_class_name in _AssetToComponentBase.STEEL_S1_PIPE_EDR_ASSETS.items()
        ]

        # We assert the pipe classes are monotonically increasing in size
        assert np.all(np.diff([pc.inner_diameter for pc in pipe_classes]) > 0)

        for p, options in pd.read_csv(csv_input_pipes, index_col=0).to_dict("index").items():
            if self.is_cold_pipe(p):
                continue

            if options["optimizePipeSize"]:
                c = self._cf_override_pipe_classes[p] = []

                if options["optimizePipeRouting"]:
                    c.append(no_pipe_class)

                min_size = options["pipeDiameterMin"]
                max_size = options["pipeDiameterMax"]

                indices = sorted(
                    [i for i, pc in enumerate(pipe_classes) if pc.name in {min_size, max_size}]
                )
                c.extend(pipe_classes[indices[0] : indices[1]])
            else:
                if options["optimizePipeRouting"]:
                    # Note: we will resolve the "existing pipe class" _after_
                    # the super().__init__() statement when  the ESDLMixin has
                    # parsed and converted the assets to a PyCML model.
                    self._cf_override_pipe_classes[p] = [no_pipe_class, "existing pipe class"]

        super().__init__(*args, esdl_run_info_path=esdl_run_info_path, **kwargs)

        # Replace "existing pipe class" with the actual existing pipe class
        assets = self.esdl_assets
        for p, pipe_classes in self._cf_override_pipe_classes.items():
            if "existing pipe class" in pipe_classes:
                assert len(pipe_classes) == 2
                assert pipe_classes[0] == no_pipe_class

                asset = next(a for a in assets.values() if a.name == p)

                # Insulation properties
                material = asset.attributes["material"]
                # NaN means the default values will be used
                insulation_thicknesses = math.nan
                conductivies_insulation = math.nan

                if material is not None:
                    if isinstance(material, esdl.esdl.MatterReference):
                        material = material.reference

                    assert isinstance(material, esdl.esdl.CompoundMatter)
                    components = material.component.items
                    if components:
                        insulation_thicknesses = [x.layerWidth for x in components]
                        conductivies_insulation = [x.matter.thermalConductivity for x in components]

                diameter = asset.attributes["innerDiameter"]
                u_kwargs = {
                    "inner_diameter": diameter,
                    "insulation_thicknesses": insulation_thicknesses,
                    "conductivities_insulation": conductivies_insulation,
                }

                # NaN values mean we use the function default
                u_kwargs = {k: v for k, v in u_kwargs.items() if not np.all(np.isnan(v))}

                pipe_classes[1] = PipeClass(
                    f"{asset.name}_orig",
                    diameter,
                    maximum_velocity,
                    heat_loss_u_values_pipe(**u_kwargs),
                )

    def esdl_heat_model_options(self):
        options = super().esdl_heat_model_options()
        options["min_fraction_tank_volume"] = 0.0
        return options

    @property
    def esdl_assets(self):
        assets = super().esdl_assets

        # Override buffer sizes
        for b, size in self._cf_override_buffer_size.items():
            asset = next(a for a in assets.values() if a.name == b)
            asset.attributes["volume"] = size

        # Override source maxPower, CF gives power in kW
        for s, max_power in self._cf_override_max_power.items():
            asset = next(a for a in assets.values() if a.name == s)
            asset.attributes["power"] = max_power * 1.0e3

        # Override supply/return temperature
        for a in assets.values():
            for c in a.global_properties["carriers"].values():
                c["supplyTemperature"] = self._cf_override_supply_temperature
                c["returnTemperature"] = self._cf_override_return_temperature

        return assets

    def heat_network_options(self):
        options = super().heat_network_options()
        options.update(self._cf_override_hn_options)
        return options

    def pipe_classes(self, p):
        return self._cf_override_pipe_classes.get(p, [])

    def read(self):
        super().read()

        # Workaround for CF not always forcing the system time (=forecast
        # datetime) to be within the start - end datetime range.
        datetimes = self.io.datetimes
        ref_datetime = self.io.reference_datetime

        if ref_datetime < datetimes[0]:
            logger.info(
                f"Reference datetime '{ref_datetime}' before earliest data point '{datetimes[0]}'. "
                f"Setting reference datetime to '{datetimes[0]}'."
            )
            self.io.reference_datetime = datetimes[0]
            self._ESDLMixin__timeseries_import.forecast_datetime = datetimes[0]


class HeatProblem(
    CFOptions,
    HeatMixin,
    LinearizedOrderGoalProgrammingMixin,
    SinglePassGoalProgrammingMixin,
    ESDLMixin,
    CollocatedIntegratedOptimizationProblem,
):
    """
    Goal priorities are:
    1. Match demands
    2. Geothermal sources flat (if any)
    3-9. Prioritization of sources (can be multiple goals)
    10. Minimize L*D of pipes (only if pipe has multiple diameter options)
    11. Minimize buffer size
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        assert self._cf_objective == "Minimize Buffer Size"

        # Additional variables and their properties
        # Minimizing buffer size
        self.__max_buffer_heat_var = {}
        self.__max_buffer_heat_map = {}
        self.__max_buffer_heat_nominals = {}

        # Optional placement of buffers
        self.__buffer_placement_var = {}
        self.__buffer_placement_var_bounds = {}
        self.__buffer_placement_map = {}

        self.__priority_offset = None

        self._qpsol = None

        self._hot_start = False

        # Store (time taken, success, objective values, solver stats) per priority
        self.__priorities_output = {}
        self.__priority = None
        self.__priority_timer = None

    def pre(self):
        self._qpsol = CachingQPSol()

        super().pre()

        # We want a symbol per buffer that indicates the maximum size that was
        # reached for that particular buffer. We minimize the _sum_ of these
        # symbols.
        for b in self._cf_minimize_size_buffers:
            buffer_max_heat_var = f"{b}__max_size"

            self.__max_buffer_heat_map[b] = buffer_max_heat_var
            self.__max_buffer_heat_var[buffer_max_heat_var] = ca.MX.sym(buffer_max_heat_var)
            self.__max_buffer_heat_nominals[buffer_max_heat_var] = self.variable_nominal(
                f"{b}.Stored_heat"
            )

        # For every buffer that can be _optionally_ placed, we add a boolean
        # symbol.
        for b in self._cf_optional_buffers:
            buffer_placement_var = f"{b}__buffer_placed"

            self.__buffer_placement_map[b] = buffer_placement_var
            self.__buffer_placement_var[buffer_placement_var] = ca.MX.sym(buffer_placement_var)
            self.__buffer_placement_var_bounds[buffer_placement_var] = (0.0, 1.0)

        # We need the number of sources to know how much to offset the
        # priorities of goals coming after.
        n_sources = len(self.heat_network_components["source"])
        self.__priority_offset = int(10 ** (1 + math.ceil(math.log10(max(2, n_sources)))))

    def path_goals(self):
        goals = super().path_goals().copy()
        parameters = self.parameters(0)

        # First we always try to match the demands
        for demand in self.heat_network_components["demand"]:
            target = self.get_timeseries(f"{demand}.target_heat_demand")
            state = f"{demand}.Heat_demand"

            goals.append(TargetHeatGoal(state, target, priority=1))

        for source in self.heat_network_components["source"]:
            try:
                target = self.get_timeseries(f"{source}.target_heat_source")
                state = f"{source}.Heat_source"

                goals.append(TargetHeatGoal(state, target, priority=1))
            except KeyError:
                pass

        # If there are any geothermal sources with a target flow rate set, try
        # to stay close to this target.
        for s in self.heat_network_components["source"]:
            try:
                target_flow_rate = parameters[f"{s}.target_flow_rate"]
                goals.append(ConstantGeothermalSource(self, s, target_flow_rate, priority=2))
            except KeyError:
                pass

        # Prioritize some sources over others. Note that we only have to do
        # N - 1 minimizations, with N the number of distinct source
        # priorities. In that way we do _not_ minimize total production, just
        # prefer some sources over others.
        sorted_source_priorities = sorted(self._cf_source_priority_map.items(), key=lambda x: x[1])
        sorted_priority_source_map = dict(
            sorted(
                (
                    (a, [x[0] for x in v])
                    for a, v in itertools.groupby(sorted_source_priorities, key=lambda x: x[1])
                ),
                reverse=True,
            )
        )

        for i, sources in enumerate(list(sorted_priority_source_map.values())[:-1]):
            nominal = float(np.mean([self.variable_nominal(f"{s}.Heat_source") for s in sources]))
            for s in sources:
                goals.append(MinimizeSourcesHeatGoal(s, nominal=nominal, priority=3 + i))

        return goals

    def goals(self):
        goals = super().goals().copy()

        # Minimize pipe options (if any)
        for p in self.hot_pipes:
            pipe_classes = self.pipe_classes(p)

            if len(pipe_classes) == 0 or len({pc.inner_diameter for pc in pipe_classes}) == 1:
                continue

            # We found at least _one_ pipe with variable diameter options. Add
            # a goal to minimize L*D.
            goals.append(MinimizeLDGoal(self, priority=self.__priority_offset))
            break

        # Minimize the total maximum volume of buffers
        if self._cf_minimize_size_buffers:
            goals.append(
                MinimizeTotalBufferSizeGoal(
                    self.__max_buffer_heat_map.values(), priority=self.__priority_offset + 1
                )
            )

        return goals

    def constraints(self, ensemble_member):
        constraints = super().constraints(ensemble_member)

        for b, max_var in self.__max_buffer_heat_map.items():
            max_heat = self.extra_variable(max_var, ensemble_member)
            stored_heat = self.__state_vector_scaled(f"{b}.Stored_heat", ensemble_member)
            constraint_nominal = self.__max_buffer_heat_nominals[max_var]

            constraints.append(((max_heat - stored_heat) / constraint_nominal, 0.0, np.inf))

        # Max number of optional buffers to place
        if self._cf_max_placed_buffers is not None and self._cf_optional_buffers:
            buffer_placement_vars = [
                self.extra_variable(k, ensemble_member) for k in self.__buffer_placement_var.keys()
            ]
            constraints.append((sum(buffer_placement_vars), 0.0, self._cf_max_placed_buffers))

        return constraints

    def path_constraints(self, ensemble_member):
        constraints = super().path_constraints(ensemble_member)

        parameters = self.parameters(ensemble_member)
        times = self.times()

        # Force discharge of disconnected buffer to zero. The associated pipe
        # should be disconnectable, and disconnect as a result.
        for b in self._cf_optional_buffers:
            q_buffer = self.state(f"{b}.HeatIn.Q")
            is_used = self.__buffer_placement_var[self.__buffer_placement_map[b]]

            big_m = parameters[f"{b}.volume"] / min(np.diff(times))

            constraint_nominal = (big_m * self.variable_nominal(f"{b}.HeatIn.Q")) ** 0.5

            constraints.append(((q_buffer - big_m * is_used) / constraint_nominal, -np.inf, 0.0))
            constraints.append(((q_buffer + big_m * is_used) / constraint_nominal, 0.0, np.inf))

        return constraints

    def history(self, ensemble_member):
        return AliasDict(self.alias_relation)

    def heat_network_options(self):
        options = super().heat_network_options()
        options["minimum_velocity"] = 0.0
        options["heat_loss_disconnected_pipe"] = False
        return options

    @property
    def extra_variables(self):
        variables = super().extra_variables.copy()
        variables.extend(self.__max_buffer_heat_var.values())
        variables.extend(self.__buffer_placement_var.values())
        return variables

    def variable_is_discrete(self, variable):
        if variable in self.__buffer_placement_var:
            return True
        else:
            return super().variable_is_discrete(variable)

    def variable_nominal(self, variable):
        if variable in self.__max_buffer_heat_nominals:
            return self.__max_buffer_heat_nominals[variable]
        else:
            return super().variable_nominal(variable)

    def bounds(self):
        bounds = super().bounds()
        bounds.update(self.__buffer_placement_var_bounds)
        return bounds

    def __state_vector_scaled(self, variable, ensemble_member):
        canonical, sign = self.alias_relation.canonical_signed(variable)
        return (
            self.state_vector(canonical, ensemble_member) * self.variable_nominal(canonical) * sign
        )

    def solver_options(self):
        options = super().solver_options()
        options["casadi_solver"] = self._qpsol
        # options["solver"] = "gurobi"

        if options["solver"] == "cbc":
            options["hot_start"] = self._hot_start
            cbc_options = options["cbc"] = {}
            cbc_options["seconds"] = 300.0

        return options

    def solver_success(self, solver_stats, log_solver_failure_as_error):
        success, log_level = super().solver_success(solver_stats, log_solver_failure_as_error)

        # Allow time-outs for CPLEX and CBC
        if (
            solver_stats["return_status"] == "time limit exceeded"
            or solver_stats["return_status"] == "stopped - on maxnodes, maxsols, maxtime"
        ):
            if self.objective_value > 1e10:
                # Quick check on the objective value. If no solution was
                # found, this is typically something like 1E50.
                return success, log_level

            return True, logging.INFO
        else:
            return success, log_level

    def priority_started(self, priority):
        self.__priority = priority
        self.__priority_timer = time.time()

        super().priority_started(priority)

    def priority_completed(self, priority):
        super().priority_completed(priority)

        self._hot_start = True

        time_taken = time.time() - self.__priority_timer
        self.__priorities_output[priority] = (
            time_taken,
            True,
            self.objective_value,
            self.solver_stats,
        )

    def __write_html_output(self):
        from jinja2 import Environment, FileSystemLoader

        assert self.ensemble_size == 1

        results = self.extract_results()
        parameters = self.parameters(0)

        # Format the priority results
        priority_results = [
            dict(
                number=number,
                success=success,
                pretty_time=f"{int(seconds // 60):02d}:{seconds  % 60:06.3f}",
                objective_value=objective_value,
                return_status=stats["return_status"],
                secondary_return_status=stats.get("secondary_return_status", ""),
            )
            for number, (
                seconds,
                success,
                objective_value,
                stats,
            ) in self.__priorities_output.items()
        ]

        # Format the buffer results
        results_buffers_placed = {}
        results_buffers_size = {}
        results_max_charging_rate = {}
        results_max_discharging_rate = {}

        for buffer in _sort_numbered(self.heat_network_components["buffer"]):
            if buffer in self._cf_minimize_size_buffers:
                max_size_var = self.__max_buffer_heat_map[buffer]
                results_buffers_size[buffer] = float(results[max_size_var][0]) / (
                    parameters[f"{buffer}.cp"]
                    * parameters[f"{buffer}.rho"]
                    * (parameters[f"{buffer}.T_supply"] - parameters[f"{buffer}.T_return"])
                )
            else:
                results_buffers_size[buffer] = "-"

            if buffer in self._cf_optional_buffers:
                buffer_placement_var = self.__buffer_placement_map[buffer]
                results_buffers_placed[buffer] = np.round(results[buffer_placement_var][0]) == 1.0
            else:
                results_buffers_placed[buffer] = "-"

            (_, hot_orient), _ = self.heat_network_topology.buffers[buffer]
            q = hot_orient * results[f"{buffer}.HeatIn.Q"]
            inds_charging = q > 0
            inds_discharging = q < 0

            results_max_charging_rate[buffer] = max(q[inds_charging]) if any(inds_charging) else 0.0
            results_max_discharging_rate[buffer] = (
                max(-1 * q[inds_discharging]) if any(inds_discharging) else 0.0
            )

        buffer_results = [
            dict(
                name=buffer,
                tune_size=buffer in self._cf_minimize_size_buffers,
                tune_placement=buffer in self._cf_optional_buffers,
                maximum_size=self._cf_override_buffer_size[buffer],
                result_placed=results_buffers_placed[buffer],
                result_size=results_buffers_size[buffer],
                max_charging_rate=results_max_charging_rate[buffer],
                max_discharging_rate=results_max_discharging_rate[buffer],
            )
            for buffer in self.heat_network_components["buffer"]
        ]

        # Format the pipe results
        # Note that we do not distinguish between routing and sizing
        # internally, but for the sake of the output we do.
        pipe_results = []

        for p in _sort_numbered(self.hot_pipes):
            pipe_classes = self.pipe_classes(p)
            tune_routing = len([pc for pc in pipe_classes if pc.inner_diameter == 0.0]) == 1
            inner_diameter = parameters[f"{p}.diameter"]
            asset = next(a for a in self.esdl_assets.values() if a.name == p)
            esdl_diameter = asset.attributes["innerDiameter"]

            if len(pipe_classes) <= 1:
                tune_size = False
                min_dn_size = "-"
                max_dn_size = "-"
                result_placed = "-"
                result_dn_size = "-"
            elif len(pipe_classes) == 2 and tune_routing:
                tune_size = False
                min_dn_size = "-"
                max_dn_size = "-"
                result_placed = "Yes" if inner_diameter > 0 else "No"
                result_dn_size = "-"
            else:
                sorted_pipe_classes = sorted(
                    [pc for pc in pipe_classes if pc.inner_diameter > 0],
                    key=lambda pc: pc.inner_diameter,
                )

                tune_size = True
                min_dn_size = sorted_pipe_classes[0].name
                max_dn_size = sorted_pipe_classes[-1].name
                result_placed = "Yes" if inner_diameter > 0 else "No"
                result_pipe_class = self.get_optimized_pipe_class(p)
                result_dn_size = (
                    result_pipe_class.name if result_pipe_class is not None else inner_diameter
                )

            pipe_results.append(
                dict(
                    name=p,
                    tune_size=tune_size,
                    tune_routing=tune_routing,
                    esdl_diameter=esdl_diameter,
                    min_dn_size=min_dn_size,
                    max_dn_size=max_dn_size,
                    result_placed=result_placed,
                    result_dn_size=result_dn_size,
                )
            )

        input_csv_tables = {
            os.path.basename(x): pd.read_csv(x).to_dict("records")
            for x in self._cf_csv_input_parameter_files
        }

        # Actually write out the html file based on the template
        templates_dir = Path(__file__).parent / "templates"

        env = Environment(loader=FileSystemLoader(templates_dir))
        template = env.get_template("mpc_buffer_sizing_output.html")

        os.makedirs(self._cf_html_output_dir, exist_ok=True)

        filename = self._cf_html_output_dir / "mpc_buffer_sizing_output.html"

        with open(filename, "w", encoding="utf-8") as fh:
            fh.write(
                template.render(
                    buffer_results=buffer_results,
                    pipe_results=pipe_results,
                    priority_results=priority_results,
                    input_csv_tables=input_csv_tables,
                )
            )

    def __write_updated_esdl(self):
        from esdl.esdl_handler import EnergySystemHandler
        from rtctools_heat_network.esdl.esdl_mixin import _RunInfoReader

        results = self.extract_results()
        parameters = self.parameters(0)

        run_info = _RunInfoReader(self.esdl_run_info_path)
        esh = EnergySystemHandler()
        energy_system = esh.load_file(str(run_info.esdl_file))

        def _name_to_asset(name):
            return next(
                (x for x in energy_system.eAllContents() if hasattr(x, "name") and x.name == name)
            )

        # First we write all the attributes that were overrided with the CSV
        # input files, and are not part of the optimization.
        # Supply/return temperature:
        for c in energy_system.energySystemInformation.carriers.carrier.items:
            if isinstance(c, esdl.esdl.HeatCommodity):
                if c.supplyTemperature != 0.0 and c.returnTemperature == 0.0:
                    c.supplyTemperature = self._cf_override_supply_temperature
                elif c.returnTemperature != 0.0 and c.supplyTemperature == 0.0:
                    c.returnTemperature = self._cf_override_return_temperature

        # Source max power (note that CF gives power in kW)
        for source, max_power in self._cf_override_max_power.items():
            asset = _name_to_asset(source)
            asset.power = max_power * 1.0e3

        # Update attributes that were part of the optimization.
        # Buffers:
        for buffer in _sort_numbered(self.heat_network_components["buffer"]):
            asset = _name_to_asset(buffer)

            # User override
            if buffer in self._cf_override_buffer_size:
                asset.capacity = float(self._cf_override_buffer_size[buffer])

            # Optimized size
            if buffer in self._cf_minimize_size_buffers:
                max_size_var = self.__max_buffer_heat_map[buffer]
                asset.capacity = float(results[max_size_var][0])

            # Placement
            if buffer in self._cf_optional_buffers:
                buffer_placement_var = self.__buffer_placement_map[buffer]
                placed = np.round(results[buffer_placement_var][0]) == 1.0

                if not placed:
                    asset.delete(recursive=True)

        # Pipes:
        edr_pipe_properties_to_copy = ["innerDiameter", "outerDiameter", "diameter", "material"]

        esh_edr = EnergySystemHandler()

        for pipe in self.hot_pipes:
            pipe_classes = self.pipe_classes(pipe)
            if not pipe_classes:
                # Nothing to change in the model
                continue

            pipe_class = self.get_optimized_pipe_class(pipe)
            cold_pipe = self.hot_to_cold_pipe(pipe)

            if parameters[f"{pipe}.diameter"] != 0.0:
                if not isinstance(pipe_class, EDRPipeClass):
                    assert pipe_class.name == f"{pipe}_orig"
                    continue

                assert isinstance(pipe_class, EDRPipeClass)

                asset_edr = esh_edr.load_from_string(pipe_class.xml_string)

                for p in [pipe, cold_pipe]:
                    asset = _name_to_asset(p)
                    for prop in edr_pipe_properties_to_copy:
                        setattr(asset, prop, getattr(asset_edr, prop))
            else:
                for p in [pipe, cold_pipe]:
                    asset = _name_to_asset(p)
                    asset.delete(recursive=True)

        filename = run_info.esdl_file.with_name(
            f"{run_info.esdl_file.stem}_SmartControlOptimized.esdl"
        )
        esh.save(str(filename))

    def post(self):
        # In case the solver fails, we do not get in priority_completed(). We
        # append this last priority's statistics here in post().
        success, _ = self.solver_success(self.solver_stats, False)
        if not success:
            time_taken = time.time() - self.__priority_timer
            self.__priorities_output[self.__priority] = (
                time_taken,
                False,
                self.objective_value,
                self.solver_stats,
            )

        # Calculate some additional results required/wanted by the CF
        times = self.times()

        for ensemble_member in range(self.ensemble_size):
            results = self.extract_results(ensemble_member)
            parameters = self.parameters(ensemble_member)

            # .dH for demands
            for demand in self.heat_network_components["demand"]:
                dh = results[f"{demand}.HeatOut.H"] - results[f"{demand}.HeatIn.H"]
                self.set_timeseries(f"{demand}.dH", Timeseries(times, dh), ensemble_member)

            # .Q for buffers
            for buffer in self.heat_network_components["buffer"]:
                q = results[f"{buffer}.HeatIn.Q"]
                self.set_timeseries(f"{buffer}.Q", Timeseries(times, q), ensemble_member)

            # .velocity for pipes
            for pipe in self.heat_network_components["pipe"]:
                area = parameters[f"{pipe}.area"]
                q = results[f"{pipe}.Q"]
                self.set_timeseries(
                    f"{pipe}.velocity", Timeseries(times, q / area), ensemble_member
                )

        super().post()

        self.__write_html_output()

        self.__write_updated_esdl()


@_main_decorator
def main(runinfo_path, log_level):
    _ = run_optimization_problem(HeatProblem, esdl_run_info_path=runinfo_path, log_level=log_level)


if __name__ == "__main__":
    main()
